import {
    ArrowLeftIcon,
    CheckCircleIcon,
    CheckIcon,
    FileTextIcon,
    PencilSimpleIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import DataTable, { DataTableColumn } from "../DataTable";
import { BOQRow } from "../quotations/NewQuotation";
import Select from "react-select";

// ============================================================
// TYPES
// ============================================================
interface ApprovedQuotation {
    id: string;
    quotationNo: string;
    projectTitle: string;
    vendor: string;
    contractValue: number;
    currency: string;
    status: string;
}

interface InvoiceGenerateLocationState {
    quotation?: ApprovedQuotation;
}

interface MilestoneOption {
    value: string;
    label: string;
    percentage: number;
}

interface Installment {
    id: number;
    name: string;
    amount: number;
    date: string;
}

type ModuleItem = {
    id: number;
    name: string;
    rate: number;
};

type InstallmentData = {
    id: number;
    name: string;
    days: number;
    netTotalAmount: number;
    moduleItems: ModuleItem[];
};

// ============================================================
// STATIC DATA
// ============================================================
const milestoneOptions: MilestoneOption[] = [
    {
        value: "initialization",
        label: "Initialization",
        percentage: 100,
    },
];

const moduleOptions = [
    { value: "Pole Installation", label: "Pole Installation" },
    { value: "Fiber Cable Installation", label: "Fiber Cable Installation" },
    { value: "Fiber Splicing", label: "Fiber Splicing" },
];

const boqRows: BOQRow[] = [
    {
        id: 1,
        section: 1,
        module: "Pole Installation",
        category: "Civil Works",
        description: "Pole Attachment Clamps & Supports",
        quantity: 120,
        uom: "Unit",
        materialCost: 25,
        serviceCost: 30,
        salesPrice: 95,
        gct: 15,
        totalInstallments: 0,
        pendingInstallments: 0,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 0
    },
    {
        id: 2,
        section: 2,
        module: "Fiber Cable Installation",
        category: "Fiber Optics",
        description: "96-Core ADSS Single Mode Fiber Cable",
        quantity: 10000,
        uom: "Meters",
        materialCost: 1.2,
        serviceCost: 1.5,
        salesPrice: 4.5,
        gct: 15,
        totalInstallments: 0,
        pendingInstallments: 0,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 0
    },
    {
        id: 3,
        section: 3,
        module: "Fiber Splicing",
        category: "Splicing & Testing",
        description: "Precision Core Fusion Splicing",
        quantity: 96,
        uom: "Unit",
        materialCost: 8,
        serviceCost: 20,
        salesPrice: 60,
        gct: 15,
        totalInstallments: 0,
        pendingInstallments: 0,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 0
    },
];

const currencyOptions = [
    { value: "JMD", label: "JMD" },
    { value: "USD", label: "USD" },
];

const verificationTasks = [
    {
        id: 1,
        name: "Requirement Gathering",
        description: "Identify all required sensor locations and data metrics.",
        estimatedHours: 12,
        status: "In Progress",
        progress: 40,
        priority: "High",
    },
    {
        id: 2,
        name: "Site Survey",
        description:
            "Conduct a complete site survey and document the required infrastructure.",
        estimatedHours: 18,
        status: "Completed",
        progress: 100,
        priority: "Medium",
    },
    {
        id: 3,
        name: "Network Design",
        description:
            "Prepare the network architecture, connectivity plan, and equipment requirements.",
        estimatedHours: 24,
        status: "Pending",
        progress: 0,
        priority: "Urgent",
    },
    {
        id: 4,
        name: "Equipment Installation",
        description:
            "Install and configure the required field equipment and network devices.",
        estimatedHours: 32,
        status: "On Hold",
        progress: 65,
        priority: "High",
    },
];

// ============================================================
// INSTALLMENT DATA
// ============================================================
const INSTALLMENTS: InstallmentData[] = [
    {
        id: 1,
        name: "Installment 1",
        days: 15,
        netTotalAmount: 12500,
        moduleItems: [
            { id: 101, name: "Pole Installation", rate: 5000 },
            { id: 102, name: "Fiber Splicing", rate: 3500 },
            { id: 103, name: "Fiber Cable Installation", rate: 4000 },
        ],
    },
    {
        id: 2,
        name: "Installment 2",
        days: 30,
        netTotalAmount: 15000,
        moduleItems: [
            { id: 201, name: "Pole Installation", rate: 6000 },
            { id: 202, name: "Fiber Splicing", rate: 4500 },
            { id: 203, name: "Fiber Cable Installation", rate: 4500 },
        ],
    },
    {
        id: 3,
        name: "Installment 3",
        days: 45,
        netTotalAmount: 18000,
        moduleItems: [
            { id: 301, name: "Pole Installation", rate: 7000 },
            { id: 302, name: "Fiber Splicing", rate: 5000 },
            { id: 303, name: "Fiber Cable Installation", rate: 6000 },
        ],
    },
    {
        id: 4,
        name: "Installment 4",
        days: 60,
        netTotalAmount: 20000,
        moduleItems: [
            { id: 401, name: "Pole Installation", rate: 8000 },
            { id: 402, name: "Fiber Splicing", rate: 5500 },
            { id: 403, name: "Fiber Cable Installation", rate: 6500 },
        ],
    },
];


const quotationInstallmentData = {
    "QT-2026-003": {
        projectName: "Downtown Office Renovation",
        quotationNo: "QT-2026-003",
        vendor: "City Council - Kingston & St. Andrew Corporation",
        currency: "USD",
        quotationAmount: 178500,
        status: "Approved",

        installments: {
            total: 4,
            pending: 2,
        },

        invoicesGenerated: 2,
        invoicesPaid: 1,
        balanceAmount: 89250,
    },

    "QT-2026-004": {
        projectName: "Spalding Fiber FTTx Network Deployment",
        quotationNo: "QT-2026-004",
        vendor: "Seiretsu JA Ltd",
        currency: "USD",
        quotationAmount: 425000,
        status: "Draft",

        installments: {
            total: 5,
            pending: 5,
        },

        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 425000,
    },

    "QT-2026-005": {
        projectName: "Smart City Infrastructure",
        quotationNo: "QT-2026-005",
        vendor: "Kingston Infrastructure Solutions",
        currency: "JMD",
        quotationAmount: 14500000,
        status: "Submitted",

        installments: {
            total: 6,
            pending: 4,
        },

        invoicesGenerated: 2,
        invoicesPaid: 2,
        balanceAmount: 9650000,
    },

    "QT-2026-006": {
        projectName: "Commercial Building Electrical Upgrade",
        quotationNo: "QT-2026-006",
        vendor: "Jamaica Power & Engineering Ltd",
        currency: "USD",
        quotationAmount: 265750,
        status: "Rejected",

        installments: {
            total: 3,
            pending: 3,
        },

        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 265750,
    },
};

// ============================================================
// COMPONENT
// ============================================================
const InvoiceGenerate = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const state = location.state as InvoiceGenerateLocationState | null;
    const quotation = state?.quotation;

    // ----- Invoice Config State -----
    const [invoiceNumber] = useState("INV-2026-162");
    const [currency, setCurrency] = useState("JMD");
    const [dueDate, setDueDate] = useState("2026-10-08");
    const [siteReference, setSiteReference] = useState("");
    const [tax, setTax] = useState(15);
    const [invoiceDocument, setInvoiceDocument] = useState<File | null>(null);




    // ----- Milestone / Modules -----
    const [selectedMilestone, setSelectedMilestone] = useState("initialization");
    const [selectedModules, setSelectedModules] = useState<string[]>([
        "Pole Installation",
    ]);
    const [billPercentage, setBillPercentage] = useState(100);

    // ----- Installment Selection State -----
    // Only additional selected installments (first is always checked + disabled)
    const [selectedInstallments, setSelectedInstallments] = useState<number[]>([]);

    // ----- Payments -----
    const [installments, setInstallments] = useState<Installment[]>([
        {
            id: 1,
            name: "Initial Payment",
            amount: 42500,
            date: "2026-08-15",
        },
        {
            id: 2,
            name: "Second Payment",
            amount: 25000,
            date: "2026-09-10",
        },
    ]);

    const netTotalAmount = 100000;
    const [remarks, setRemarks] = useState("");

    const totalPaid = installments.reduce(
        (sum, installment) => sum + installment.amount,
        0
    );


    const calculatedInvoiceAmount = INSTALLMENTS
        .filter((installment) =>
            selectedInstallments.includes(installment.id)
        )
        .reduce(
            (total, installment) =>
                total + installment.netTotalAmount,
            0
        );


    const [invoiceAmount, setInvoiceAmount] = useState<number>(0);
    useEffect(() => {
        setInvoiceAmount(calculatedInvoiceAmount);
    }, [calculatedInvoiceAmount]);
    // const [invoiceAmount, setInvoiceAmount] = useState<number>(
    //     calculatedInvoiceAmount
    // );

    const remainingAmount = Math.max(0, netTotalAmount - totalPaid);

    // ----- Add Installment (legacy modal) -----
    const [isAddingInstallment, setIsAddingInstallment] = useState(false);
    const [newInstallment, setNewInstallment] = useState({
        name: "",
        amount: "",
        date: "",
    });

    const [isEditingPayment, setIsEditingPayment] = useState(false);
    const [currentPayment, setCurrentPayment] = useState("42500");
    const [currentPaymentDate, setCurrentPaymentDate] = useState("2026-08-15");

    // ============================================================
    // MEMOS
    // ============================================================
    const selectedModuleRows = useMemo(() => {
        return boqRows.filter((row) => selectedModules.includes(row.module));
    }, [selectedModules]);

    const selectedMilestoneData = useMemo(
        () =>
            milestoneOptions.find(
                (milestone) => milestone.value === selectedMilestone
            ),
        [selectedMilestone]
    );

    const contractValue = quotation?.contractValue ?? 0;

    const totalValueToGenerate = installments.reduce(
        (total, installment) => total + Number(installment.amount || 0),
        0
    );

    const moduleTotal = useMemo(() => {
        return selectedModuleRows.reduce(
            (total, row) => total + row.quantity * row.salesPrice,
            0
        );
    }, [selectedModuleRows]);

    // ============================================================
    // HELPERS
    // ============================================================
    const formatCurrency = (value: number) =>
        value.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });

    const handleDocumentUpload = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];
        if (file) setInvoiceDocument(file);
    };

    const handleCancel = () => {
        navigate("/invoices", {
            state: { activeTab: "approvedQuotes" },
        });
    };

    // ----- Installment toggle -----
    const handleInstallmentChange = (installmentId: number) => {
        setSelectedInstallments((prev) => {
            if (prev.includes(installmentId)) {
                return prev.filter((id) => id !== installmentId);
            }

            return [...prev, installmentId];
        });
    };


    // ============================================================
    // SAVE / SUBMIT
    // ============================================================
    const handleSaveDraft = () => {
        if (!quotation) {
            navigate("/invoices");
            return;
        }

        const draftInvoice = {
            id: crypto.randomUUID(),
            invoiceNumber,
            quotationId: quotation.id,
            quotationNo: quotation.quotationNo,
            projectTitle: quotation.projectTitle,
            vendor: quotation.vendor,
            currency,
            dueDate,
            siteReference,
            milestone: selectedMilestoneData?.label ?? "",
            selectedModules,
            billPercentage,
            contractValue,
            amount: totalValueToGenerate,
            tax,
            invoiceDocument: invoiceDocument?.name ?? "",
            status: "Draft",
            createdDate: new Date().toISOString(),
        };

        const existingInvoices = JSON.parse(
            localStorage.getItem("invoices") || "[]"
        );

        localStorage.setItem(
            "invoices",
            JSON.stringify([...existingInvoices, draftInvoice])
        );

        navigate("/invoices");
    };

    const handleSubmitInvoice = () => {
        if (!quotation) {
            navigate("/invoices");
            return;
        }

        const invoice = {
            id: crypto.randomUUID(),
            invoiceNumber,
            quotationId: quotation.id,
            quotationNo: quotation.quotationNo,
            projectTitle: quotation.projectTitle,
            vendor: quotation.vendor,
            currency,
            dueDate,
            siteReference,
            milestone: selectedMilestoneData?.label ?? "",
            selectedModules,
            billPercentage,
            contractValue,
            totalValue: totalValueToGenerate,
            tax,
            invoiceAmount,
            invoiceDocument: invoiceDocument?.name ?? "",
            status: "Pending Admin Review",
            createdDate: new Date().toISOString(),
        };

        const existingInvoices = JSON.parse(
            localStorage.getItem("invoices") || "[]"
        );

        localStorage.setItem(
            "invoices",
            JSON.stringify([...existingInvoices, invoice])
        );

        navigate("/invoices", { state: { invoiceSubmitted: true } });
    };

    // ============================================================
    // EARLY RETURN: No Quotation
    // ============================================================
    if (!quotation) {
        return (
            <div className="flex min-h-[500px] items-center justify-center bg-slate-50">
                <div className="text-center">
                    <p className="text-sm font-semibold text-slate-700">
                        No quotation selected.
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                        Please select an approved quotation before generating an
                        invoice.
                    </p>
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="mb-3 mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 transition-colors hover:text-red-600"
                    >
                        <ArrowLeftIcon size={14} />
                        Back to Invoice List
                    </button>
                </div>
            </div>
        );
    }

    // ============================================================
    // DATATABLE COLUMNS
    // ============================================================




    const installmentColumns: DataTableColumn<Installment>[] = [
        {
            key: "name",
            label: "Installment",
            width: "40%",
            sortable: true,
            render: (installment) => (
                <div>
                    <p className="text-xs font-bold text-slate-800">
                        {installment.name}
                    </p>
                    <p className="mt-0.5 text-[9px] text-slate-400">
                        Installment {installment.id}
                    </p>
                </div>
            ),
        },
        {
            key: "amount",
            label: "Amount",
            width: "25%",
            sortable: true,
            render: (installment) => (
                <span className="text-xs font-bold text-slate-700">
                    $
                    {installment.amount.toLocaleString("en-US", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                    })}
                </span>
            ),
        },
        {
            key: "date",
            label: "Payment Date",
            width: "35%",
            sortable: true,
            render: (installment) => (
                <span className="text-xs font-medium text-slate-600">
                    {new Date(installment.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "2-digit",
                        year: "numeric",
                    })}
                </span>
            ),
        },
    ];

    // ============================================================
    // RENDER
    // ============================================================
    return (
        <div className="min-h-screen bg-slate-50">
            <div className="mx-auto px-2 py-3">
                {/* ================= HEADER ================= */}
                <div className="mb-6">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="mb-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-red-600"
                    >
                        <ArrowLeftIcon size={14} />
                        Back to Invoice List
                    </button>

                    <h1 className="text-xl font-bold text-slate-900">
                        Invoice Configuration
                    </h1>

                    <p className="mt-1 text-xs text-slate-500">
                        Generating invoice for{" "}
                        <span className="font-semibold text-slate-700">
                            {quotation.projectTitle}
                        </span>{" "}
                        ({quotation.quotationNo})
                    </p>
                </div>

                {/* ================= INVOICE CONFIG ================= */}
                <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    {/* Header */}
                    <div className="border-b border-slate-100 px-6 py-4">
                        <h2 className="text-sm font-bold text-slate-800">
                            Invoice Configuration
                        </h2>
                    </div>

                    {/* Form */}
                    <div className="grid grid-cols-1 gap-x-5 gap-y-5 p-6 md:grid-cols-3">

                        {/* Invoice Number */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Invoice Number
                            </label>

                            <input
                                type="text"
                                value={invoiceNumber}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>

                        {/* Vendor */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Vendor
                            </label>

                            <input
                                type="text"
                                value="City Council - Kingston & St. Andrew Corporation"
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>

                        {/* Currency */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Currency
                            </label>

                            <Select
                                value={
                                    currencyOptions.find(
                                        (option) => option.value === currency
                                    ) ?? null
                                }
                                onChange={(option) =>
                                    setCurrency(option?.value ?? "JMD")
                                }
                                options={currencyOptions}
                                isSearchable={false}
                                className="text-sm"
                                classNamePrefix="currency-select"
                                styles={{
                                    control: (base, state) => ({
                                        ...base,
                                        minHeight: "42px",
                                        height: "42px",
                                        borderRadius: "8px",
                                        borderColor: state.isFocused
                                            ? "#fca5a5"
                                            : "#e2e8f0",
                                        backgroundColor: state.isFocused
                                            ? "#ffffff"
                                            : "#f8fafc",
                                        boxShadow: "none",
                                        "&:hover": {
                                            borderColor: "#fca5a5",
                                        },
                                    }),
                                    valueContainer: (base) => ({
                                        ...base,
                                        height: "42px",
                                        padding: "0 12px",
                                    }),
                                    indicatorsContainer: (base) => ({
                                        ...base,
                                        height: "42px",
                                    }),
                                    singleValue: (base) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#334155",
                                    }),
                                    placeholder: (base) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#94a3b8",
                                    }),
                                    option: (base, state) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#334155",
                                        backgroundColor: state.isSelected
                                            ? "#fee2e2"
                                            : state.isFocused
                                                ? "#fef2f2"
                                                : "#ffffff",
                                        cursor: "pointer",
                                    }),
                                    menu: (base) => ({
                                        ...base,
                                        zIndex: 50,
                                    }),
                                }}
                            />
                        </div>

                        {/* Due Date */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Due Date
                            </label>

                            <input
                                type="date"
                                value={dueDate}
                                onChange={(event) =>
                                    setDueDate(event.target.value)
                                }
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>

                        {/* Site Reference */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Site Reference
                            </label>

                            <input
                                type="text"
                                value="Spalding to Christiana Corridor, Manchester"
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>


                        {/* Invoice Amount */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Invoice Amount
                            </label>

                            <div className="relative">
                                <span className="absolute left-3 top-1/2 z-10 -translate-y-1/2 text-xs font-semibold text-slate-400">
                                    USD
                                </span>

                                <input
                                    type="number"
                                    value={invoiceAmount}
                                    onChange={(event) =>
                                        setInvoiceAmount(
                                            event.target.value === ""
                                                ? 0
                                                : Number(event.target.value)
                                        )
                                    }
                                    placeholder="Enter amount"
                                    className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-12 pr-3 text-sm font-semibold text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                />
                            </div>
                        </div>

                        {/* Tax */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Tax (%)
                            </label>

                            <input
                                type="number"
                                min={0}
                                max={100}
                                value={tax}
                                onChange={(event) =>
                                    setTax(Number(event.target.value))
                                }
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>

                        {/* Supporting Document */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Supporting Document
                            </label>

                            <input
                                type="file"
                                onChange={handleDocumentUpload}
                                className="block h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-red-50 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-red-600"
                            />

                            {invoiceDocument && (
                                <p className="mt-2 text-[10px] font-medium text-emerald-600">
                                    Selected: {invoiceDocument.name}
                                </p>
                            )}
                        </div>

                        {/* Remarks */}
                        <div className="min-w-0">
                            <label
                                htmlFor="remarks"
                                className="mb-1.5 block text-xs font-semibold text-slate-700"
                            >
                                Remarks
                            </label>

                            <textarea
                                id="remarks"
                                rows={3}
                                value={remarks}
                                onChange={(e) => setRemarks(e.target.value)}
                                placeholder="Enter remarks..."
                                className="w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 outline-none transition focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>


                    </div>
                </section>


                {/* ================= MILESTONE ALLOCATION ================= */}
                <section className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="border-b border-slate-100 px-6 py-4">
                        <h2 className="text-sm font-bold text-slate-800">
                            Overall Milestone Allocation
                        </h2>
                        <p className="mt-1 text-xs text-slate-500">
                            Select the project phase, module, and percentage of
                            the approved contract value to invoice.
                        </p>
                    </div>



                    {/* ============================================================
                        INSTALLMENT ITEMS
                    ============================================================ */}
                    <div className="border-t border-slate-200">
                        <div className="border-b border-slate-100 px-6 py-4">
                            <h2 className="text-sm font-bold text-slate-800">
                                Installment Items
                            </h2>
                            <p className="mt-1 text-xs text-slate-500">
                                The first installment has already been paid.
                                Select an installment to view its details.
                            </p>
                        </div>

                        <div className="p-6">
                            {/* Installment List Table */}
                            <div className="overflow-hidden rounded-lg border border-slate-200">
                                {/* Header */}
                                <div className="grid grid-cols-[50px_1.5fr_1fr_1.5fr_1.5fr_2fr] items-center gap-4 bg-slate-50 px-4 py-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                    <div></div>
                                    <div>Installment Name</div>
                                    <div>Days</div>
                                    <div>Total Amount</div>
                                    <div>Action</div>
                                    <div>Module Items</div>
                                </div>

                                {/* Rows */}
                                {INSTALLMENTS.map((installment, index) => {
                                    const isFirstInstallment = index === 0;
                                    const isChecked =
                                        isFirstInstallment ||
                                        selectedInstallments.includes(
                                            installment.id
                                        );

                                    return (
                                        <div
                                            key={installment.id}
                                            className={`grid grid-cols-[50px_1.5fr_1fr_1.5fr_1.5fr_2fr] items-center gap-4 border-t border-slate-100 px-4 py-4 transition-colors ${isChecked
                                                ? "bg-primary/5"
                                                : "bg-white hover:bg-slate-50"
                                                }`}
                                        >
                                            {/* Checkbox */}
                                            <div>
                                                <input
                                                    type="checkbox"
                                                    checked={isChecked}
                                                    disabled={isFirstInstallment}
                                                    onChange={() => {
                                                        if (
                                                            !isFirstInstallment
                                                        ) {
                                                            handleInstallmentChange(
                                                                installment.id
                                                            );
                                                        }
                                                    }}
                                                    className={`h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary ${isFirstInstallment
                                                        ? "cursor-not-allowed opacity-60"
                                                        : "cursor-pointer"
                                                        }`}
                                                />
                                            </div>

                                            {/* Name */}
                                            <div>
                                                <p className="text-sm font-semibold text-slate-800">
                                                    {installment.name}
                                                </p>
                                                {isFirstInstallment && (
                                                    <span className="mt-1 inline-flex rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-semibold text-green-700">
                                                        Mandatory
                                                    </span>
                                                )}
                                            </div>

                                            {/* Days */}
                                            <div className="text-sm text-slate-600">
                                                {installment.days} Days
                                            </div>

                                            {/* Net Total */}
                                            <div className="text-sm font-bold text-red-600">
                                                USD{" "}
                                                {formatCurrency(
                                                    installment.netTotalAmount
                                                )}
                                            </div>

                                            {/* Action */}
                                            <div>
                                                {isFirstInstallment ? (
                                                    <span className="inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
                                                        Paid
                                                    </span>
                                                ) : (
                                                    <span
                                                        className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${isChecked
                                                            ? "bg-primary/10 text-primary"
                                                            : "bg-slate-100 text-slate-500"
                                                            }`}
                                                    >
                                                        {isChecked
                                                            ? "Selected"
                                                            : "Pending"}
                                                    </span>
                                                )}
                                            </div>

                                            {/* Module Items */}
                                            <div className="flex flex-wrap gap-2">
                                                {installment.moduleItems.map(
                                                    (item) => (
                                                        <span
                                                            key={item.id}
                                                            className="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600"
                                                        >
                                                            {item.name}
                                                        </span>
                                                    )
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            {/* ============================================================
                                SELECTED INSTALLMENTS (SEPARATE)
                            ============================================================ */}
                            {selectedInstallments.length > 0 && (
                                <div className="mt-6">
                                    <div className="mb-4">
                                        <h3 className="text-sm font-bold text-slate-800">
                                            Selected Installments
                                        </h3>
                                        <p className="mt-1 text-xs text-slate-500">
                                            Details of the selected installments
                                            are displayed separately below.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        {INSTALLMENTS.filter((installment) =>
                                            selectedInstallments.includes(
                                                installment.id
                                            )
                                        ).map((installment) => (
                                            <div
                                                key={installment.id}
                                                className="overflow-hidden rounded-lg border border-slate-200 bg-white"
                                            >
                                                {/* Header */}
                                                <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-5 py-4">
                                                    <div>
                                                        <div className="flex items-center gap-2">
                                                            <h4 className="text-sm font-bold text-slate-800">
                                                                {
                                                                    installment.name
                                                                }
                                                            </h4>
                                                            <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-semibold text-primary">
                                                                Selected
                                                            </span>
                                                        </div>
                                                        <p className="mt-1 text-xs text-slate-500">
                                                            {installment.days}{" "}
                                                            Days
                                                        </p>
                                                    </div>

                                                    <div className="text-right">
                                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                                            Total
                                                        </p>
                                                        <p className="text-sm font-bold text-red-600">
                                                            USD{" "}
                                                            {formatCurrency(
                                                                installment.netTotalAmount
                                                            )}
                                                        </p>
                                                    </div>
                                                </div>

                                                {/* Module Items */}
                                                <div className="p-5">
                                                    <h5 className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                                        Module Items
                                                    </h5>

                                                    <div className="overflow-hidden rounded-lg border border-slate-200">
                                                        {installment.moduleItems.map(
                                                            (item) => (
                                                                <div
                                                                    key={item.id}
                                                                    className="flex items-center justify-between border-b border-slate-100 px-4 py-3 last:border-b-0"
                                                                >
                                                                    <div>
                                                                        <p className="text-sm font-medium text-slate-700">
                                                                            {
                                                                                item.name
                                                                            }
                                                                        </p>
                                                                        <p className="mt-0.5 text-xs text-slate-400">
                                                                            Module
                                                                            Item
                                                                        </p>
                                                                    </div>
                                                                    <div className="text-sm font-bold text-slate-700">
                                                                        USD{" "}
                                                                        {formatCurrency(
                                                                            item.rate
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            )
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </section>

                {/* ================= TASKS VERIFICATION ================= */}
                <section className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
                        <div>
                            <h2 className="text-sm font-bold text-slate-800">
                                Tasks Verification
                            </h2>
                            <p className="mt-0.5 text-[11px] text-slate-500">
                                Review task progress and completion status.
                            </p>
                        </div>
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-bold text-emerald-700">
                            <CheckCircleIcon size={11} weight="fill" />
                            Verified
                        </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                        {verificationTasks.map((task) => {
                            const isCompleted = task.status === "Completed";

                            return (
                                <div
                                    key={task.id}
                                    className="flex items-center gap-3 px-5 py-3 transition hover:bg-slate-50"
                                >
                                    {/* Status Icon */}
                                    <div
                                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${isCompleted
                                            ? "bg-emerald-500 text-white"
                                            : "border border-slate-300 bg-white"
                                            }`}
                                    >
                                        {isCompleted && (
                                            <CheckIcon size={12} weight="bold" />
                                        )}
                                    </div>

                                    {/* Info */}
                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2">
                                            <h3
                                                className={`truncate text-xs font-semibold ${isCompleted
                                                    ? "text-slate-400 line-through"
                                                    : "text-slate-700"
                                                    }`}
                                            >
                                                {task.name}
                                            </h3>
                                            <span
                                                className={`shrink-0 rounded px-1.5 py-0.5 text-[8px] font-bold ${task.priority === "Urgent"
                                                    ? "bg-red-50 text-red-600"
                                                    : task.priority === "High"
                                                        ? "bg-orange-50 text-orange-600"
                                                        : task.priority ===
                                                            "Medium"
                                                            ? "bg-amber-50 text-amber-600"
                                                            : "bg-slate-100 text-slate-500"
                                                    }`}
                                            >
                                                {task.priority}
                                            </span>
                                        </div>

                                        {/* Progress Bar */}
                                        <div className="mt-1.5 flex items-center gap-2">
                                            <div className="h-1 flex-1 overflow-hidden rounded-full bg-slate-100">
                                                <div
                                                    className={`h-full rounded-full ${isCompleted
                                                        ? "bg-emerald-500"
                                                        : task.status ===
                                                            "In Progress"
                                                            ? "bg-blue-500"
                                                            : task.status ===
                                                                "On Hold"
                                                                ? "bg-amber-500"
                                                                : "bg-slate-300"
                                                        }`}
                                                    style={{
                                                        width: `${task.progress}%`,
                                                    }}
                                                />
                                            </div>
                                            <span className="w-7 text-right text-[9px] font-bold text-slate-500">
                                                {task.progress}%
                                            </span>
                                        </div>
                                    </div>

                                    {/* Status Badge */}
                                    <span
                                        className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-semibold ${task.status === "Completed"
                                            ? "bg-emerald-50 text-emerald-700"
                                            : task.status === "In Progress"
                                                ? "bg-blue-50 text-blue-700"
                                                : task.status === "On Hold"
                                                    ? "bg-amber-50 text-amber-700"
                                                    : task.status === "Due Date"
                                                        ? "bg-red-50 text-red-700"
                                                        : "bg-slate-100 text-slate-600"
                                            }`}
                                    >
                                        {task.status}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </section>



                {/* ================= ACTIONS ================= */}
                <div className="mt-6 flex flex-col-reverse gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-end">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="inline-flex h-10 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-xs font-bold text-slate-600 transition-colors hover:bg-slate-50"
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        onClick={handleSaveDraft}
                        className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
                    >
                        <FileTextIcon size={15} weight="duotone" />
                        Save as Draft
                    </button>

                    <button
                        type="button"
                        onClick={handleSubmitInvoice}
                        className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-red-600 px-5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                    >
                        <FileTextIcon size={15} weight="duotone" />
                        Generate Invoice
                    </button>
                </div>
            </div>
        </div>
    );
};

export default InvoiceGenerate;