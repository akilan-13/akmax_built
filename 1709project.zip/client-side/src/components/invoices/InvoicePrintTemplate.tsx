import { forwardRef } from "react";

type InvoiceStatus =
    | "Draft"
    | "Submitted"
    | "Approved"
    | "Rejected"
    | "Paid"
    | "Overdue";

interface MilestoneModule {
    name: string;
    rate: string;
}

interface Invoice {
    id: string;
    invoiceNo: string;
    vendor: string;
    project: string;
    amount: string;
    dueDate: string;
    status: InvoiceStatus;
    rejectionRemarks?: string;
    milestoneName?: string;
    installmentAmount?: number;
    taxRate?: number;
    milestoneModules?: MilestoneModule[];
    issuedDate?: string;
    currency?: string;
    billToName?: string;
    billToDepartment?: string;
    paymentDate?: string;
    transactionRefId?: string;
}

interface InvoicePrintTemplateProps {
    invoice: Invoice;
    installmentAmount: number;
    taxAmount: number;
    taxRatePercent: number;
    totalAmount: number;
    milestoneName: string;
}

// This component renders a full, standalone A4-style invoice document.
// It's kept off-screen (not display:none, since html2canvas can't
// capture display:none elements) and used for both print and PDF export.
const InvoicePrintTemplate = forwardRef<HTMLDivElement, InvoicePrintTemplateProps>(
    (
        {
            invoice,
            installmentAmount,
            taxAmount,
            taxRatePercent,
            totalAmount,
            milestoneName,
        },
        ref
    ) => {
        const isPaid = invoice.status === "Paid";

        return (
            <div
                ref={ref}
                id="invoice-print-template"
                style={{
                    width: "794px", // ~A4 at 96dpi
                    minHeight: "1123px",
                    background: "#ffffff",
                    padding: "48px",
                    fontFamily: "Arial, Helvetica, sans-serif",
                    color: "#1e293b",
                    position: "relative",
                    boxSizing: "border-box",
                }}
            >
                {/* Watermark */}
                {isPaid && (
                    <div
                        style={{
                            position: "absolute",
                            top: "38%",
                            left: "50%",
                            transform: "translate(-50%, -50%) rotate(-28deg)",
                            fontSize: "110px",
                            fontWeight: 800,
                            color: "rgba(220,38,38,0.12)",
                            letterSpacing: "4px",
                            pointerEvents: "none",
                            userSelect: "none",
                        }}
                    >
                        PAID
                    </div>
                )}

                {/* Header */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ display: "flex", gap: "12px" }}>
                        <div
                            style={{
                                width: "44px",
                                height: "44px",
                                borderRadius: "10px",
                                background: "#dc2626",
                                color: "#fff",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontWeight: 800,
                                fontSize: "22px",
                            }}
                        >
                            P
                        </div>
                        <div>
                            <p style={{ margin: 0, fontWeight: 800, fontSize: "16px", letterSpacing: "0.5px" }}>
                                ARGUS
                            </p>
                            <p style={{ margin: 0, fontSize: "9px", fontWeight: 700, color: "#dc2626", letterSpacing: "1px" }}>
                                NETWORK INFRASTRUCTURE
                            </p>
                            <div style={{ marginTop: "8px", fontSize: "10px", color: "#64748b", lineHeight: 1.5 }}>
                                <p style={{ margin: 0 }}>10-12 Knutsford Boulevard</p>
                                <p style={{ margin: 0 }}>Kingston 5, St. Andrew</p>
                                <p style={{ margin: 0 }}>Jamaica, W.I.</p>
                                <p style={{ margin: 0 }}>compliance@projectflow.com</p>
                            </div>
                        </div>
                    </div>

                    <div style={{ textAlign: "right" }}>
                        <p style={{ margin: 0, fontWeight: 800, fontSize: "26px", letterSpacing: "1px" }}>
                            INVOICE
                        </p>
                        <p style={{ margin: "6px 0 0", fontSize: "9px", fontWeight: 700, color: "#64748b", letterSpacing: "0.5px" }}>
                            INVOICE REFERENCE
                        </p>
                        <p style={{ margin: 0, fontWeight: 800, fontSize: "12px" }}>{invoice.invoiceNo}</p>
                    </div>
                </div>

                {/* Bill from / Bill to */}
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: "36px", gap: "24px" }}>
                    <div>
                        <p style={{ margin: 0, fontSize: "9px", fontWeight: 700, color: "#dc2626", letterSpacing: "0.5px" }}>
                            BILL FROM (VENDOR)
                        </p>
                        <p style={{ margin: "4px 0 0", fontWeight: 800, fontSize: "13px" }}>{invoice.vendor}</p>
                        <p style={{ margin: "2px 0 0", fontSize: "10px", color: "#64748b" }}>
                            Tax Registration: 104-552-713
                        </p>
                        <p style={{ margin: "2px 0 0", fontSize: "10px", color: "#dc2626", fontStyle: "italic" }}>
                            Verified Network Contractor
                        </p>
                    </div>

                    <div style={{ textAlign: "right" }}>
                        <p style={{ margin: 0, fontSize: "9px", fontWeight: 700, color: "#dc2626", letterSpacing: "0.5px" }}>
                            BILL TO
                        </p>
                        <p style={{ margin: "4px 0 0", fontWeight: 800, fontSize: "13px" }}>
                            {invoice.billToName ?? "National Telecom Authority"}
                        </p>
                        <p style={{ margin: "2px 0 0", fontSize: "10px", color: "#64748b" }}>
                            {invoice.billToDepartment ?? "Accounts Payable Department"}
                        </p>
                        <p style={{ margin: "2px 0 0", fontSize: "10px", color: "#64748b" }}>
                            Project: {invoice.project}
                        </p>
                    </div>
                </div>

                <div style={{ height: "1px", background: "#e2e8f0", margin: "28px 0" }} />

                {/* Issued / Due / Currency */}
                <div style={{ display: "flex", gap: "48px" }}>
                    <div>
                        <p style={{ margin: 0, fontSize: "9px", fontWeight: 700, color: "#94a3b8", letterSpacing: "0.5px" }}>
                            ISSUED DATE
                        </p>
                        <p style={{ margin: "4px 0 0", fontWeight: 800, fontSize: "12px" }}>
                            {invoice.issuedDate ?? "—"}
                        </p>
                    </div>
                    <div>
                        <p style={{ margin: 0, fontSize: "9px", fontWeight: 700, color: "#94a3b8", letterSpacing: "0.5px" }}>
                            PAYMENT DUE
                        </p>
                        <p style={{ margin: "4px 0 0", fontWeight: 800, fontSize: "12px", color: isPaid ? "#1e293b" : "#dc2626" }}>
                            {invoice.dueDate}
                        </p>
                    </div>
                    <div>
                        <p style={{ margin: 0, fontSize: "9px", fontWeight: 700, color: "#94a3b8", letterSpacing: "0.5px" }}>
                            CURRENCY
                        </p>
                        <p style={{ margin: "4px 0 0", fontWeight: 800, fontSize: "12px" }}>
                            {invoice.currency ?? "USD"}
                        </p>
                    </div>
                </div>

                <div style={{ marginTop: "28px" }}>
                    {/* Line items */}
                    <div
                        style={{
                            display: "grid",
                            gridTemplateColumns: "1fr 60px 100px 100px",
                            fontSize: "9px",
                            fontWeight: 700,
                            color: "#334155",
                            borderBottom: "2px solid #1e293b",
                            paddingBottom: "8px",
                        }}
                    >
                        <span>DESCRIPTION OF WORKS / MATERIALS</span>
                        <span style={{ textAlign: "right" }}>QTY</span>
                        <span style={{ textAlign: "right" }}>UNIT PRICE</span>
                        <span style={{ textAlign: "right" }}>TOTAL</span>
                    </div>

                    <div style={{ minHeight: "60px" }}>
                        <div
                            style={{
                                display: "grid",
                                gridTemplateColumns: "1fr 60px 100px 100px",
                                fontSize: "10px",
                                padding: "10px 0",
                                borderBottom: "1px solid #f1f5f9",
                            }}
                        >
                            <span>{milestoneName}</span>
                            <span style={{ textAlign: "right" }}>1</span>
                            <span style={{ textAlign: "right" }}>
                                {invoice.currency ?? "$"}{installmentAmount.toLocaleString()}
                            </span>
                            <span style={{ textAlign: "right", fontWeight: 700 }}>
                                {invoice.currency ?? "$"}{installmentAmount.toLocaleString()}
                            </span>
                        </div>
                    </div>

                    {/* Totals */}
                    <div style={{ display: "flex", justifyContent: "flex-end", marginTop: "16px" }}>
                        <div style={{ width: "240px" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", padding: "4px 0" }}>
                                <span style={{ color: "#64748b", fontWeight: 600 }}>SUBTOTAL</span>
                                <span style={{ fontWeight: 700 }}>
                                    {invoice.currency ?? "$"}{installmentAmount.toLocaleString()}
                                </span>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", padding: "4px 0" }}>
                                <span style={{ color: "#64748b", fontWeight: 600 }}>
                                    GCT ({taxRatePercent}%)
                                </span>
                                <span style={{ fontWeight: 700 }}>
                                    {invoice.currency ?? "$"}{taxAmount.toLocaleString()}
                                </span>
                            </div>
                            <div style={{ height: "1px", background: "#e2e8f0", margin: "8px 0" }} />
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px", padding: "4px 0" }}>
                                <span style={{ fontWeight: 800 }}>GRAND TOTAL</span>
                                <span style={{ fontWeight: 800, color: "#dc2626" }}>
                                    {invoice.currency ?? "$"}{totalAmount.toLocaleString()}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div style={{ position: "absolute", bottom: "48px", left: "48px", right: "48px" }}>
                    <div style={{ height: "1px", background: "#e2e8f0", marginBottom: "16px" }} />
                    <p style={{ margin: 0, textAlign: "center", fontSize: "9px", fontWeight: 700, letterSpacing: "0.5px" }}>
                        PAYMENT TERMS &amp; INSTRUCTIONS
                    </p>
                    <p style={{ margin: "4px 0 0", textAlign: "center", fontSize: "9px", color: "#64748b" }}>
                        Please remit payment within 30 days of invoice date. Late payments may be subject to a 1.5% monthly financing fee.
                    </p>
                    <p style={{ margin: "4px 0 0", textAlign: "center", fontSize: "9px", color: "#64748b" }}>
                        Bank: NCB Knutsford • Account Name: {invoice.vendor} • SWIFT: JNCBJMKK
                    </p>
                    <p style={{ margin: "12px 0 0", textAlign: "center", fontSize: "8px", color: "#94a3b8" }}>
                        © 2026 ARGUS Project Management System • Digital Document PF-inv2
                    </p>
                </div>
            </div>
        );
    }
);

InvoicePrintTemplate.displayName = "InvoicePrintTemplate";

export default InvoicePrintTemplate;
export type { Invoice as PrintableInvoice };