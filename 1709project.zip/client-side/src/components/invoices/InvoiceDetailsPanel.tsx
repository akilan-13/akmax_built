import { CheckCircleIcon, ClockIcon, DownloadSimpleIcon, FileTextIcon, XCircleIcon, CurrencyDollarIcon, PaperclipIcon, XIcon, PrinterIcon } from "@phosphor-icons/react";
import { useEffect, useRef, useState } from "react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import InvoicePrintTemplate from "./InvoicePrintTemplate";


type InvoiceStatus =
    | "Draft"
    | "Submitted"
    | "Approved"
    | "Rejected"
    | "Paid"
    | "Overdue";

interface MilestoneModule {
    name: string;
    rate: string;
}

interface Invoice {
    id: string;
    invoiceNo: string;
    vendor: string;
    project: string;
    amount: string;
    dueDate: string;
    status: InvoiceStatus;
    rejectionRemarks?: string;
    milestoneName?: string;
    installmentAmount?: number;
    taxRate?: number;
    milestoneModules?: MilestoneModule[];
}

interface PaymentDetails {
    amount: string;
    transactionRefId: string;
    paymentDate: string;
    notes: string;
    documents: File[];
}

interface InvoiceDetailsPanelProps {
    invoice: Invoice;
    statusConfig: Record<
        InvoiceStatus,
        {
            badge: string;
            icon: React.ReactNode;
            iconBg: string;
            iconColor: string;
            dot: string;
        }
    >;
    onApprove: (totalAmount: number) => void;
    onReject: (remarks: string) => void;
    onMarkAsPaid: (details: PaymentDetails) => void;
}

const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const InvoiceDetailsPanel = ({
    invoice,
    statusConfig,
    onApprove,
    onReject,
    onMarkAsPaid,
}: InvoiceDetailsPanelProps) => {
    const [activeDetailTab, setActiveDetailTab] = useState<"billing" | "audit">("billing");

    // ---- Reject flow: remarks required before confirming ----
    const [isRejecting, setIsRejecting] = useState(false);
    const [rejectRemarks, setRejectRemarks] = useState("");

    // ---- Milestone / billing data (per-invoice, with fallback defaults) ----
    const milestoneName = invoice.milestoneName ?? "Milestone 2 - Construction Progress";
    const installmentAmount = invoice.installmentAmount ?? 125000;
    const taxRate = invoice.taxRate ?? 0.18; // 18%
    const taxAmount = installmentAmount * taxRate;
    const totalWithTax = installmentAmount + taxAmount;

    const milestoneModules: MilestoneModule[] = invoice.milestoneModules ?? [
        { name: "Cable Installation", rate: "₹45,000" },
        { name: "Joint Closure", rate: "₹30,000" },
        { name: "Trenching & Ducting", rate: "₹50,000" },
    ];

    // ---- Payment capture form state (only usable after approval) ----
    const [paymentAmount, setPaymentAmount] = useState(String(totalWithTax));
    const [transactionRefId, setTransactionRefId] = useState("");
    const [paymentNotes, setPaymentNotes] = useState("");
    const [paymentDate, setPaymentDate] = useState("");
    const [paymentDocuments, setPaymentDocuments] = useState<File[]>([]);
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const printRef = useRef<HTMLDivElement>(null);

    const handlePrint = () => {
        const printContents = printRef.current?.outerHTML;
        if (!printContents) return;

        const printWindow = window.open("", "_blank", "width=900,height=1200");
        if (!printWindow) return;

        printWindow.document.write(`
        <html>
            <head>
                <title>${invoice.invoiceNo}</title>
                <style>
                    @page { size: A4; margin: 0; }
                    body { margin: 0; }
                </style>
            </head>
            <body>${printContents}</body>
        </html>
    `);
        printWindow.document.close();
        printWindow.focus();

        // Give the new window a tick to lay out images/fonts before printing.
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 300);
    };

    const handleDownloadPdf = async () => {
        if (!printRef.current) return;

        const canvas = await html2canvas(printRef.current, {
            scale: 2,
            useCORS: true,
            backgroundColor: "#ffffff",
        });

        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF({
            orientation: "portrait",
            unit: "px",
            format: [canvas.width, canvas.height],
        });

        pdf.addImage(imgData, "PNG", 0, 0, canvas.width, canvas.height);
        pdf.save(`${invoice.invoiceNo}.pdf`);
    };
    // Reset the payment form whenever a different invoice is selected,
    // defaulting the amount to that invoice's computed total.
    useEffect(() => {
        setPaymentAmount(String(totalWithTax));
        setTransactionRefId("");
        setPaymentNotes("");
        setPaymentDate("");
        setPaymentDocuments([]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [invoice.id]);

    const phases = [
        {
            name: "Phase 1 - Survey",
            tasks: [
                { name: "Site Visit", status: "Completed" },
                { name: "Pole Inspection", status: "Completed" },
                { name: "GPS Mapping", status: "In Progress" },
            ],
        },
        {
            name: "Phase 2 - Construction",
            tasks: [
                { name: "Cable Installation", status: "To Do" },
                { name: "Joint Closure", status: "To Do" },
            ],
        },
        {
            name: "Phase 3 - Quality Assurance",
            tasks: [
                { name: "Network Testing", status: "To Do" },
                { name: "Final Inspection", status: "To Do" },
            ],
        },
    ];

    const taskStatusStyles: Record<string, string> = {
        Completed: "border-emerald-200 bg-emerald-50 text-emerald-700",
        "In Progress": "border-amber-200 bg-amber-50 text-amber-700",
        "To Do": "border-slate-200 bg-slate-50 text-slate-500",
    };

    // ---- Derived flags straight from the invoice's actual status ----
    const isPending = invoice.status === "Draft" || invoice.status === "Submitted";
    const isApproved = invoice.status === "Approved";
    const isRejected = invoice.status === "Rejected";
    const isPaid = invoice.status === "Paid";
    const isOverdue = invoice.status === "Overdue";

    const canDownload = isPaid;

    const canMarkAsPaid =
        !!paymentAmount && !!transactionRefId && !!paymentDate && paymentDocuments.length > 0;

    const handleApprove = () => onApprove(totalWithTax);

    const handleFilesSelected = (fileList: FileList | null) => {
        if (!fileList || fileList.length === 0) return;

        const selectedFiles = Array.from(fileList).filter((file) => {
            return (
                file.type === "application/pdf" ||
                file.type.startsWith("image/")
            );
        });

        if (selectedFiles.length === 0) {
            return;
        }

        setPaymentDocuments((prev) => [...prev, ...selectedFiles]);

        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleRemoveDocument = (index: number) => {
        setPaymentDocuments((prev) => prev.filter((_, i) => i !== index));
    };

    const handleMarkAsPaid = () => {
        if (!canMarkAsPaid) return;
        onMarkAsPaid({
            amount: paymentAmount,
            transactionRefId,
            paymentDate,
            notes: paymentNotes,
            documents: paymentDocuments,
        });
    };

    const handleConfirmReject = () => {
        if (!rejectRemarks.trim()) return;
        onReject(rejectRemarks.trim());
        setIsRejecting(false);
        setRejectRemarks("");
    };

    return (
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm p-5">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-500">
                            <FileTextIcon size={21} weight="duotone" />
                        </div>

                        <div>
                            <p className="text-base font-bold text-slate-800">
                                {invoice.invoiceNo}
                            </p>

                            <p className="mt-0.5 text-[10px] font-medium text-slate-500">
                                {invoice.vendor}
                            </p>
                        </div>
                    </div>
                </div>

                <span
                    className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[10px] font-bold ${statusConfig[invoice.status].badge}`}
                >
                    <span
                        className={`h-1.5 w-1.5 rounded-full ${statusConfig[invoice.status].dot}`}
                    />
                    {invoice.status}
                </span>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                    <p className="text-[9px] font-semibold uppercase tracking-wide text-slate-400">
                        Due Date
                    </p>
                    <p className={`mt-1 text-xs font-bold ${isOverdue ? "text-red-600" : "text-slate-700"}`}>
                        {invoice.dueDate}
                    </p>
                </div>

                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                    <p className="text-[9px] font-semibold uppercase tracking-wide text-slate-400">
                        Project
                    </p>
                    <p title={invoice.project} className="mt-1 truncate text-xs font-bold text-slate-700">
                        {invoice.project}
                    </p>
                </div>
            </div>

            <div className="my-4">
                <div className="flex items-center rounded-xl bg-slate-100 p-1">
                    <button
                        type="button"
                        onClick={() => setActiveDetailTab("billing")}
                        className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs font-bold transition-all ${activeDetailTab === "billing"
                            ? "bg-white text-slate-800 shadow-sm"
                            : "text-slate-500 hover:text-slate-700"
                            }`}
                    >
                        <FileTextIcon
                            size={16}
                            weight="duotone"
                            className={activeDetailTab === "billing" ? "text-red-500" : "text-slate-400"}
                        />
                        Billing Details
                    </button>

                    <button
                        type="button"
                        onClick={() => setActiveDetailTab("audit")}
                        className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs font-bold transition-all ${activeDetailTab === "audit"
                            ? "bg-white text-slate-800 shadow-sm"
                            : "text-slate-500 hover:text-slate-700"
                            }`}
                    >
                        <CheckCircleIcon
                            size={16}
                            weight="duotone"
                            className={activeDetailTab === "audit" ? "text-red-500" : "text-slate-400"}
                        />
                        Project Audit Trace
                    </button>
                </div>
            </div>

            {activeDetailTab === "billing" && (
                <div className="p-5">
                    {/* Milestone header */}
                    <div className="mb-3 flex items-center gap-2">
                        <FileTextIcon size={15} weight="duotone" className="text-slate-500" />
                        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                            Milestone Billing
                        </p>
                    </div>

                    <div className="rounded-xl border border-red-100 bg-white p-4">
                        <p className="text-xs font-bold text-slate-800">{milestoneName}</p>
                        <p className="mt-1.5 text-[11px] leading-5 text-slate-500">
                            Installment billed against this milestone, inclusive of applicable tax.
                            Task-level progress is available under the "Project Audit Trace" tab.
                        </p>

                        <div className="mt-4 space-y-2">
                            <div className="flex items-center justify-between text-[11px]">
                                <span className="font-semibold text-slate-500">Installment Amount</span>
                                <span className="font-bold text-slate-700">₹{installmentAmount.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center justify-between text-[11px]">
                                <span className="font-semibold text-slate-500">Tax ({(taxRate * 100).toFixed(0)}%)</span>
                                <span className="font-bold text-slate-700">₹{taxAmount.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center justify-between border-t border-slate-100 pt-2 text-xs">
                                <span className="font-bold text-slate-800">Total Amount</span>
                                <span className="font-mono font-bold text-red-600">₹{totalWithTax.toLocaleString()}</span>
                            </div>
                        </div>
                    </div>

                    {/* Milestone modules list */}
                    <div className="mt-5">
                        <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-slate-400">
                            Milestone Modules
                        </p>
                        <div className="overflow-hidden rounded-xl border border-slate-200">
                            <table className="w-full text-left text-[11px]">
                                <thead className="bg-slate-50">
                                    <tr>
                                        <th className="px-3 py-2 font-semibold text-slate-500">Module</th>
                                        <th className="px-3 py-2 text-right font-semibold text-slate-500">Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {milestoneModules.map((mod, i) => (
                                        <tr key={i} className="border-t border-slate-100">
                                            <td className="px-3 py-2 font-medium text-slate-700">{mod.name}</td>
                                            <td className="px-3 py-2 text-right font-bold text-slate-700">{mod.rate}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div className="my-5 h-px bg-slate-200" />

                    {/* Approval workflow (super admin) */}
                    <div className="mb-3 flex items-center gap-2">
                        <CheckCircleIcon size={15} weight="duotone" className="text-slate-500" />
                        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                            Super Admin Approval
                        </p>
                    </div>

                    {isPending && !isRejecting && (
                        <div className="flex gap-2 rounded-xl border border-slate-200 p-4">
                            <button
                                type="button"
                                onClick={handleApprove}
                                className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-2 text-[11px] font-bold text-white hover:opacity-90"
                            >
                                <CheckCircleIcon size={14} weight="bold" />
                                Approve
                            </button>
                            <button
                                type="button"
                                onClick={() => setIsRejecting(true)}
                                className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-red-500 px-3 py-2 text-[11px] font-bold text-white hover:opacity-90"
                            >
                                <XCircleIcon size={14} weight="bold" />
                                Reject
                            </button>
                        </div>
                    )}

                    {isPending && isRejecting && (
                        <div className="rounded-xl border border-red-200 bg-red-50/40 p-4">
                            <label className="text-[10px] font-semibold text-red-600">
                                Rejection Remarks <span className="text-red-500">*</span>
                            </label>
                            <textarea
                                value={rejectRemarks}
                                onChange={(e) => setRejectRemarks(e.target.value)}
                                placeholder="State the reason for rejecting this invoice..."
                                rows={3}
                                autoFocus
                                className="mt-1 w-full rounded-lg border border-red-200 bg-white p-2 text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-red-300"
                            />
                            <div className="mt-3 flex gap-2">
                                <button
                                    type="button"
                                    onClick={handleConfirmReject}
                                    disabled={!rejectRemarks.trim()}
                                    className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-red-500 px-3 py-2 text-[11px] font-bold text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                                >
                                    <XCircleIcon size={14} weight="bold" />
                                    Confirm Reject
                                </button>
                                <button
                                    type="button"
                                    onClick={() => {
                                        setIsRejecting(false);
                                        setRejectRemarks("");
                                    }}
                                    className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-[11px] font-bold text-slate-600 hover:bg-slate-50"
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    )}

                    {!isPending && (
                        <div
                            className={`rounded-xl border p-3 text-[11px] ${isApproved || isPaid
                                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                : isRejected
                                    ? "border-red-200 bg-red-50 text-red-700"
                                    : "border-orange-200 bg-orange-50 text-orange-700"
                                }`}
                        >
                            <p className="font-bold">
                                {isPaid ? "Approved & Paid" : invoice.status} by Super Admin
                            </p>
                            {isRejected && invoice.rejectionRemarks && (
                                <p className="mt-1 text-red-600">
                                    Remarks: {invoice.rejectionRemarks}
                                </p>
                            )}
                        </div>
                    )}

                    {/* Payment section - only when approved and not yet paid */}
                    {isApproved && (
                        <div className="mt-5">
                            <div className="mb-3 flex items-center gap-2">
                                <CurrencyDollarIcon size={15} weight="duotone" className="text-slate-500" />
                                <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                                    Payment
                                </p>
                            </div>

                            <div className="space-y-3 rounded-xl border border-slate-200 p-4">
                                <div>
                                    <label className="text-[10px] font-semibold text-slate-500">
                                        Amount
                                        <span className="ml-1 font-normal normal-case text-slate-400">
                                            (defaults to the approved total, editable)
                                        </span>
                                    </label>
                                    <input
                                        type="number"
                                        value={paymentAmount}
                                        onChange={(e) => setPaymentAmount(e.target.value)}
                                        className="mt-1 w-full rounded-lg border border-slate-200 p-2 text-[11px] font-bold text-slate-700 focus:outline-none focus:ring-1 focus:ring-red-300"
                                    />
                                </div>

                                <div>
                                    <label className="text-[10px] font-semibold text-slate-500">
                                        Payment Transaction Reference ID
                                    </label>
                                    <input
                                        type="text"
                                        value={transactionRefId}
                                        onChange={(e) => setTransactionRefId(e.target.value)}
                                        placeholder="e.g. TXN123456789"
                                        className="mt-1 w-full rounded-lg border border-slate-200 p-2 text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-red-300"
                                    />
                                </div>

                                <div>
                                    <label className="text-[10px] font-semibold text-slate-500">
                                        Payment Date
                                    </label>
                                    <input
                                        type="date"
                                        value={paymentDate}
                                        onChange={(e) => setPaymentDate(e.target.value)}
                                        className="mt-1 w-full rounded-lg border border-slate-200 p-2 text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-red-300"
                                    />
                                </div>

                                <div>
                                    <label className="text-[10px] font-semibold text-slate-500">
                                        Notes
                                    </label>
                                    <textarea
                                        value={paymentNotes}
                                        onChange={(e) => setPaymentNotes(e.target.value)}
                                        rows={2}
                                        placeholder="Optional notes about this payment..."
                                        className="mt-1 w-full rounded-lg border border-slate-200 p-2 text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-red-300"
                                    />
                                </div>

                                <div>
                                    <label className="text-[10px] font-semibold text-slate-500">
                                        Payment Proof / Document{" "}
                                        <span className="text-red-500">*</span>
                                        <span className="ml-1 font-normal normal-case text-slate-400">
                                            (receipt, payment slip, PDF or image — required)
                                        </span>
                                    </label>

                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        multiple
                                        accept="application/pdf,image/*"
                                        onChange={(e) => {
                                            handleFilesSelected(e.target.files);
                                        }}
                                        className="hidden"
                                    />

                                    <button
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        className="mt-1 flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-slate-300 bg-slate-50 px-3 py-3 text-[11px] font-semibold text-slate-500 transition hover:border-red-300 hover:bg-red-50/40 hover:text-red-600"
                                    >
                                        <PaperclipIcon size={15} weight="bold" />
                                        Click to upload payment document(s)
                                    </button>

                                    {paymentDocuments.length > 0 && (
                                        <div className="mt-2 space-y-1.5">
                                            {paymentDocuments.map((file, index) => (
                                                <div
                                                    key={`${file.name}-${index}`}
                                                    className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5"
                                                >
                                                    <div className="flex min-w-0 items-center gap-2">
                                                        <FileTextIcon
                                                            size={14}
                                                            weight="duotone"
                                                            className="shrink-0 text-slate-400"
                                                        />

                                                        <span className="truncate text-[10px] font-medium text-slate-600">
                                                            {file.name}
                                                        </span>

                                                        <span className="shrink-0 text-[9px] text-slate-400">
                                                            {formatFileSize(file.size)}
                                                        </span>
                                                    </div>

                                                    <button
                                                        type="button"
                                                        onClick={() => handleRemoveDocument(index)}
                                                        className="shrink-0 rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-500"
                                                        title="Remove document"
                                                    >
                                                        <XIcon size={12} weight="bold" />
                                                    </button>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    {paymentDocuments.length === 0 && (
                                        <p className="mt-1.5 text-[10px] text-slate-400">
                                            Upload at least one PDF or image file before marking as paid.
                                        </p>
                                    )}
                                </div>

                                <button
                                    type="button"
                                    onClick={handleMarkAsPaid}
                                    disabled={!canMarkAsPaid}
                                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                                >
                                    <CheckCircleIcon size={15} weight="bold" />
                                    Mark as Paid
                                </button>
                            </div>
                        </div>
                    )}

                    {isPaid && (
                        <div className="mt-5 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-[11px] text-emerald-700">
                            <p className="font-bold">Payment Recorded</p>
                            <div className="mt-2 space-y-1">
                                <p>Amount: {invoice.amount}</p>
                                <p>Reference ID: {transactionRefId}</p>
                                <p>Payment Date: {paymentDate}</p>
                                {paymentNotes && <p>Notes: {paymentNotes}</p>}
                                {paymentDocuments.length > 0 && (
                                    <p>
                                        Documents: {paymentDocuments.map((f) => f.name).join(", ")}
                                    </p>
                                )}
                            </div>
                        </div>
                    )}

                    <div className="mt-5 grid grid-cols-2 gap-2">
                        <button
                            type="button"
                            onClick={handlePrint}
                            disabled={!canDownload}
                            title={!canDownload ? "Available once payment is completed" : undefined}
                            className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 px-4 py-2.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            <PrinterIcon size={15} weight="bold" />
                            Print Invoice
                        </button>

                        <button
                            type="button"
                            onClick={handleDownloadPdf}
                            disabled={!canDownload}
                            title={!canDownload ? "Available once payment is completed" : undefined}
                            className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-xs font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            <DownloadSimpleIcon size={15} weight="bold" />
                            Download Invoice
                        </button>
                    </div>
                    <div style={{ position: "fixed", top: 0, left: "-10000px", zIndex: -1 }}>
                        <InvoicePrintTemplate
                            ref={printRef}
                            invoice={invoice}
                            installmentAmount={installmentAmount}
                            taxAmount={taxAmount}
                            taxRatePercent={taxRate * 100}
                            totalAmount={totalWithTax}
                            milestoneName={milestoneName}
                        />
                    </div>
                </div>
            )}

            {activeDetailTab === "audit" && (
                <div className="p-5">
                    <div className="rounded-xl bg-slate-900 p-4 text-white">
                        <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                            Linked Project Audit
                        </p>
                        <p className="mt-1 text-sm font-bold">{invoice.project}</p>

                        <div className="mt-4 flex items-center justify-between">
                            <span className="text-[10px] font-semibold text-slate-400">
                                Overall Completion:
                            </span>
                            <span className="text-[10px] font-bold text-slate-300">45%</span>
                        </div>

                        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-700">
                            <div className="h-full rounded-full bg-red-500" style={{ width: "45%" }} />
                        </div>
                    </div>

                    <div className="mt-5">
                        <div className="mb-3 flex items-center gap-2">
                            <CheckCircleIcon size={15} weight="duotone" className="text-slate-500" />
                            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                                Phase & Task Completion Audit
                            </p>
                        </div>

                        <div className="space-y-3">
                            {phases.map((phase, index) => (
                                <div key={index} className="rounded-xl border border-slate-700 p-3">
                                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                                        <p className="text-xs font-bold text-slate-700">{phase.name}</p>
                                        <span className="rounded bg-slate-100 px-2 py-1 text-[9px] font-bold text-slate-600">
                                            {phase.tasks.length} tasks
                                        </span>
                                    </div>

                                    <div className="mt-2 space-y-2">
                                        {phase.tasks.map((task, taskIndex) => (
                                            <div key={taskIndex} className="flex items-center justify-between gap-3">
                                                <span
                                                    className={`text-[10px] font-medium ${task.status === "Completed"
                                                        ? "text-slate-400 line-through"
                                                        : "text-slate-600"
                                                        }`}
                                                >
                                                    {task.name}
                                                </span>
                                                <span
                                                    className={`rounded border px-2 py-0.5 text-[9px] font-bold ${taskStatusStyles[task.status]}`}
                                                >
                                                    {task.status}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="mt-5 rounded-lg border border-slate-100 bg-slate-50 p-3">
                        <div className="flex items-start gap-2">
                            <ClockIcon size={15} weight="duotone" className="mt-0.5 text-slate-400" />
                            <div>
                                <p className="text-[10px] font-bold text-slate-600">Audit Information</p>
                                <p className="mt-1 text-[10px] leading-4 text-slate-400">
                                    Project progress and task completion are linked to this invoice for
                                    verification before approval.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default InvoiceDetailsPanel;