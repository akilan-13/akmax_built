
import {
    FolderOpen,
    FileText,
    Receipt,
    CurrencyDollar,
} from "@phosphor-icons/react";

import DataCard from "../../components/DataCard";
import StatCard from "../StatCard";
import { useNavigate } from "react-router-dom";


const vendorProjects = [
    {
        id: "PRJ-001",
        initial: "PF",
        name: "Spalding Fiber FTTx Network Deployment",
        vendor: "Prime Fiber Ltd",
        status: "Active",
        progress: 78,
    },
    {
        id: "PRJ-002",
        initial: "PF",
        name: "Smart City Infrastructure",
        vendor: "Prime Fiber Ltd",
        status: "Active",
        progress: 62,
    },
    
];



export default function VendorSummary() {
    const navigate = useNavigate();
    return (
        <div className="p-3 sm:p-4 md:p-3">
            <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                    <h1 className="text-2xl font-bold text-slate-900">
                        Prime Fiber Ltd Portal
                    </h1>
                    <p className="mt-1 max-w-3xl text-[12px] leading-relaxed text-slate-500 sm:text-[13px]">
                        Access submitted quotations, log field material usage,
                        and generate construction milestone invoices.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-4">
              <StatCard
                    label="My Fiber Projects"
                    value={2}
                    icon={FolderOpen}
                    tone="amber"
                    delta="+12%"
                    deltaLabel="from last month"
                />

                <StatCard
                    label="My Pending Deliverables & Tasks"
                    value={2}
                    icon={FileText}
                    tone="red"
                    delta="+12%"
                    deltaLabel="from last month"
                />

                <StatCard
                    label="Unpaid Invoices"
                    value={2}
                    icon={Receipt}
                    tone="green"
                    delta="+12%"
                    deltaLabel="from last month"
                />

                <StatCard
                    label="Total Billed Value"
                    value="$110,500"
                    icon={CurrencyDollar}
                    tone="blue"
                    delta="+12%"
                    deltaLabel="from last month"
                />
                
            </div>

            <div className="mt-6 grid grid-cols-1 gap-5 xl:grid-cols-2">
                <div className="space-y-5">
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <h2 className="text-base font-bold text-slate-900">
                                   My Active Fiber Projects
                                </h2>

                                <p className="mt-0.5 text-xs text-slate-500">
                                    Current fiber projects and their status
                                </p>
                            </div>
                        </div>

                       <div className="divide-y divide-slate-100">
                            {vendorProjects.map((project) => (
                                <div
                                    key={project.id}
                                    onClick={() =>
                                        navigate(`/projects/project_details/${project.id}`)
                                    }
                                    className="group cursor-pointer px-4 py-4 transition-colors duration-200 hover:bg-slate-50"
                                >
                                    <div className="flex items-start gap-3">
                                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-bold text-slate-700 transition-colors duration-200 group-hover:bg-red-600 group-hover:text-white">
                                            {project.initial}
                                        </div>

                                        <div className="min-w-0 flex-1">
                                            <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                                <div className="min-w-0 flex-1">
                                                    <h3 className="text-sm font-bold leading-snug text-slate-900">
                                                        {project.name}
                                                    </h3>

                                                    <p className="mt-1 text-xs text-slate-500">
                                                        {project.vendor}
                                                    </p>
                                                </div>

                                                <span
                                                    className={`w-fit shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold ${
                                                        project.status === "Active"
                                                            ? "bg-emerald-50 text-emerald-600"
                                                            : "bg-amber-50 text-amber-600"
                                                    }`}
                                                >
                                                    {project.status}
                                                </span>
                                            </div>

                                            <div className="mt-4">
                                                <div className="mb-1.5 flex items-center justify-between text-[11px]">
                                                    <span className="font-medium text-slate-500">
                                                        Progress
                                                    </span>

                                                    <span className="font-bold text-slate-700">
                                                        {project.progress}%
                                                    </span>
                                                </div>

                                                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                                                    <div
                                                        className="h-full rounded-full bg-red-600 transition-all"
                                                        style={{
                                                            width: `${project.progress}%`,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                   <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex items-center gap-2.5">
                                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                                    <Receipt
                                        size={19}
                                        weight="bold"
                                    />
                                </div>

                                <div>
                                    <h2 className="text-base font-bold text-slate-900">
                                        My Pending Deliverables & Tasks
                                    </h2>
                                </div>
                            </div>
                        </div>

                        <div className="divide-y divide-slate-100">
                            <div className="group flex items-center gap-3 border border-transparent px-4 py-3.5 transition-all duration-200 hover:cursor-pointer hover:bg-red-50">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 transition-colors duration-200 group-hover:bg-red-600 group-hover:text-white">
                                    <FileText
                                        size={17}
                                        weight="bold"
                                    />
                                </div>

                                <div className="min-w-0 flex-1">
                                    <h3 className="truncate text-sm font-semibold text-slate-800">
                                        FTTH OSP Material Proposal
                                    </h3>

                                    <p className="mt-0.5 text-[11px] text-slate-500">
                                        Submitted for client review
                                    </p>
                                </div>

                                <span className="shrink-0 rounded-full bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-600">
                                    Pending
                                </span>
                            </div>

                            <div className="group flex items-center gap-3 border border-transparent px-4 py-3.5 transition-all duration-200 hover:cursor-pointer hover:bg-red-50">
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 transition-colors duration-200 group-hover:bg-red-600 group-hover:text-white">
                                    <FileText
                                        size={17}
                                        weight="bold"
                                    />
                                </div>

                                <div className="min-w-0 flex-1">
                                    <h3 className="truncate text-sm font-semibold text-slate-800">
                                        Fiber Route Construction Proposal
                                    </h3>

                                    <p className="mt-0.5 text-[11px] text-slate-500">
                                        Awaiting commercial approval
                                    </p>
                                </div>

                                <span className="shrink-0 rounded-full bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-600">
                                    Pending
                                </span>
                            </div>
                        </div>

                        <div className="border-t border-slate-100 px-4 py-3">
                            <button
                                type="button"
                                onClick={() => navigate("/tasks")}
                                className="flex items-center gap-1.5 text-xs font-semibold text-red-600 transition hover:text-red-700"
                            >
                                Open Task Checklist
                            </button>
                        </div>
                    </div>
                </div>

                <div className="h-fit rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h2 className="text-base font-bold text-slate-900">
                                Compliance & Quality Auditing
                            </h2>

                            <p className="mt-0.5 text-xs text-slate-500">
                                Vendor compliance requirements and quality standards
                            </p>
                        </div>

                        <span className="flex w-fit items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                            Compliant
                        </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                        <div className="px-4 py-4">
                            <div className="flex gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-50 text-amber-600">
                                    <span className="text-base font-black">!</span>
                                </div>

                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-slate-900">
                                        OTDR Fiber Splice Records
                                    </h3>

                                    <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                        OTDR fiber splice records must be attached to final
                                        invoices before submission.
                                    </p>

                                    <div className="mt-2 rounded-lg bg-amber-50 px-3 py-2.5 text-xs leading-relaxed text-amber-700">
                                        <span className="font-bold">
                                            Action Required:
                                        </span>{" "}
                                        Attach all applicable OTDR records with the final
                                        invoice documentation.
                                    </div>
                                </div>

                                <div className="hidden shrink-0 sm:block">
                                    <span className="rounded-full bg-amber-50 px-2.5 py-1 text-[10px] font-bold text-amber-600">
                                        Required
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="px-4 py-4">
                            <div className="flex gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                                    <span className="text-base font-black">✓</span>
                                </div>

                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Safety Certificates
                                    </h3>

                                    <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                        Safety certificates are fully up-to-date and compliant
                                        with current project requirements.
                                    </p>

                                    <div className="mt-2 rounded-lg bg-emerald-50 px-3 py-2.5 text-xs leading-relaxed text-emerald-700">
                                        <span className="font-bold">
                                            Status:
                                        </span>{" "}
                                        All required safety documentation is valid and current.
                                    </div>
                                </div>

                                <div className="hidden shrink-0 sm:block">
                                    <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                                        Valid
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="px-4 py-4">
                            <div className="flex gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-600">
                                    <span className="text-sm font-black">i</span>
                                </div>

                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Quality Standards
                                    </h3>

                                    <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                        All fiber OSP and trenching works must meet ISO 9001
                                        requirements and certified optical loss standards.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    );
}

