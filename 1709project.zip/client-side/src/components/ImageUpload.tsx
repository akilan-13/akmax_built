import React, { useRef, useState } from 'react';

interface ImageUploadProps {
    value?: string;
    onChange?: (file: File | null) => void;
    accept?: string;
    className?: string;
}

const ImageUpload: React.FC<ImageUploadProps> = ({
    value,
    onChange,
    accept = 'image/*',
    className = '',
}) => {
    const inputRef = useRef<HTMLInputElement>(null);
    const [preview, setPreview] = useState<string | undefined>(value);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];

        if (!file) return;

        const previewUrl = URL.createObjectURL(file);

        setPreview(previewUrl);
        onChange?.(file);
    };

    const handleClick = () => {
        inputRef.current?.click();
    };

    const handleRemove = (e: React.MouseEvent) => {
        e.stopPropagation();

        if (preview?.startsWith('blob:')) {
            URL.revokeObjectURL(preview);
        }

        setPreview(undefined);

        if (inputRef.current) {
            inputRef.current.value = '';
        }

        onChange?.(null);
    };

    return (
        <div
            onClick={handleClick}
            className={`relative flex h-16 w-16 shrink-0 cursor-pointer items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-slate-300 text-center text-[11px] font-medium leading-tight text-slate-400 transition hover:border-primary hover:text-primary ${className}`}
        >
            <input
                ref={inputRef}
                type="file"
                accept={accept}
                onChange={handleFileChange}
                className="hidden"
            />

            {preview ? (
                <>
                    <img
                        src={preview}
                        alt="Preview"
                        className="h-full w-full object-contain"
                    />

                    <button
                        type="button"
                        onClick={handleRemove}
                        className="absolute right-0.5 top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] text-white"
                    >
                        ×
                    </button>
                </>
            ) : (
                <>
                    Upload
                    <br />
                    Logo
                </>
            )}
        </div>
    );
};

export default ImageUpload;