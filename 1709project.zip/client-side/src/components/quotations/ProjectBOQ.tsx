import { useMemo, useState } from "react";
import {
    FileTextIcon,
    PlusIcon,
    CaretDownIcon,
    TrashIcon,
    CheckIcon,
    XIcon,
    ArrowLeftIcon,
    DownloadSimpleIcon,
    CaretDown,
} from "@phosphor-icons/react";
import Select, { SingleValue } from "react-select";

import Field from "../Field";
import DataTable, { DataTableColumn } from "../DataTable";
import { getSelectStyles } from "../../utils/selectStyles";

import {
    BOQ_SECTIONS,
    VENDOR_OPTIONS,
} from "../../data/projectBOQData";

import {
    BOQItemm,
    SelectOption,
} from "../../types/projectBOQ";

import { RateItem } from "../../types/rateSchedule";
import BrowseAddRate from "../../offcanvas/quotation/BrowseAddRate";

import { useNavigate } from "react-router-dom";
import QuotationHeader from "./QuotationHeader";
import QuotationTabs from "./QuotationTabs";
import Dropdown from "../Dropdown";

interface ProjectBOQProps {
    onBack?: () => void;
    showBackButton?: boolean;
    onExportEstimate?: () => void;
    onGenerateQuotation?: () => void;
}

interface PaymentInstallment {
    id: number;
    name: string;
    amount: number;
    type: "advance" | "balance";
    dueDate: string;
}

interface NewInstallment {
    name: string;
    value: string;
    dueDate: string;
}

interface NewBOQItem {
    module: string;
    category: string;
    description: string;
    unit: string;
    quantity: string;
    rate: string;
}

interface UploadedDocument {
    id: string;
    name: string;
    size: number;
    type: string;
    file: File;
}
const ProjectBOQ = ({
    onExportEstimate,
    onGenerateQuotation,
    onBack,
    showBackButton = false,
}: ProjectBOQProps) => {
    const [projectName, setProjectName] = useState("");
    const [vendors, setVendors] = useState<SelectOption[]>([]);
    const [projectSiteLocation, setProjectSiteLocation, ] = useState("");
    const [projectValue , setProjectValue,] = useState("");
    const [ validityPeriod, setValidityPeriod, ] = useState("30");
    const [ siteSurveyReference, setSiteSurveyReference, ] = useState("");
    const [boqItems, setBoqItems] = useState<BOQItemm[]>([]); 
    const [ addingSectionId, setAddingSectionId, ] = useState<number | null>(null);
    const [ newBOQItem, setNewBOQItem, ] = useState<NewBOQItem>({ module: "", category: "",
        description: "", unit: "", quantity: "1", rate: "", });
    const [ isBrowseRateOpen,  setIsBrowseRateOpen, ] = useState(false);
    const [ paymentToggle, setPaymentToggle, ] = useState<"amount" | "percentage">("amount");
    const [ paymentInstallments,  setPaymentInstallments,  ] = useState<PaymentInstallment[]>( [] );
    const [ newInstallment, setNewInstallment, ] = useState<NewInstallment>({name: "", value: "", dueDate: "", });
    const [formTemplate, setFormTemplate] = useState<SelectOption | null>(null);
    const VALIDITY_OPTIONS: SelectOption[] = [
        {value: "15", label: "15 Days", },
        {value: "30", label: "30 Days", },
        {value: "45", label: "45 Days", },
        {value: "60", label: "60 Days", },
        {value: "90", label: "90 Days", },
    ];

    const FORM_TEMPLATE_OPTIONS: SelectOption[] = [
    {
        value: "TeleCommunications",
        label: "TeleCommunications",
    },
    {
        value: "Construction",
        label: "Construction",
    },
    {
        value: "Technology",
        label: "Technology",
    },
    {
        value: "Utilities",
        label: "Utilities",
    },
    {
        value: "Professional Services",
        label: "Professional Services",
    },
];

    const formatCurrency = (value: number) => {
        return Number(value || 0).toLocaleString(
            "en-US",
            {minimumFractionDigits: 2, maximumFractionDigits: 2, }
        );
    };
    const getSelectStyles = () => {
    return {
        control: (base: any, state: any) => ({
            ...base,
            minHeight: "42px",
            borderRadius: "8px",
            borderColor: state.isFocused ? "#fca5a5" : "#e2e8f0",
            backgroundColor: state.isFocused ? "#ffffff" : "#fafafa",
            boxShadow: state.isFocused ? "0 0 0 1px #fca5a5" : "none",
            cursor: "pointer",
            "&:hover": {
                borderColor: "#fca5a5",
            },
            width: "100%",
        }),
        valueContainer: (base: any) => ({ ...base, padding: "2px 8px",
            flexWrap: "wrap", gap: "4px", overflow: "auto", maxHeight: "100px", }),
        input: (base: any) => ({...base, fontSize: "13px", color: "#475569", margin: "0", padding: "0",minWidth: "60px", }),
        placeholder: (base: any) => ({ ...base, fontSize: "13px", color: "#94a3b8", }), 
        multiValue: (base: any) => ({ ...base, backgroundColor: "#fef2f2", borderRadius: "6px", maxWidth: "100%", margin: "2px", }),
        multiValueLabel: (base: any) => ({ ...base, color: "#b91c1c", fontSize: "11px", fontWeight: 600, padding: "3px 6px", whiteSpace: "nowrap",}),
        multiValueRemove: (base: any) => ({ ...base, color: "#b91c1c", borderRadius: "0 6px 6px 0", padding: "0 6px", ":hover": { backgroundColor: "#fee2e2",color: "#991b1b",
            },
        }),
        indicatorSeparator: () => ({
            display: "none",
        }),
        dropdownIndicator: (base: any, state: any) => ({
            ...base,
            color: state.isFocused ? "#ef4444" : "#94a3b8",
            paddingRight: "10px",
            "&:hover": {
                color: "#ef4444",
            },
        }),
        clearIndicator: (base: any) => ({
            ...base,
            color: "#94a3b8",
            padding: "0 8px",
            "&:hover": {
                color: "#ef4444",
            },
        }),
        menu: (base: any) => ({
            ...base,
            marginTop: "4px",
            borderRadius: "8px",
            overflow: "hidden",
            border: "1px solid #e2e8f0",
            boxShadow: "0 10px 25px rgba(15, 23, 42, 0.08)",
            zIndex: 9999,
        }),
        menuList: (base: any) => ({
            ...base,
            padding: "4px",
            maxHeight: "220px",
        }),
        option: (base: any, state: any) => ({
            ...base,
            borderRadius: "6px",
            padding: "9px 12px",
            fontSize: "13px",
            cursor: "pointer",
            color: state.isSelected ? "#b91c1c" : "#475569",
            backgroundColor: state.isSelected ? "#fef2f2" : state.isFocused ? "#f8fafc" : "#ffffff",
            "&:active": {
                backgroundColor: "#fef2f2",
            },
        }),
        noOptionsMessage: (base: any) => ({
            ...base,
            fontSize: "13px",
            color: "#94a3b8",
            padding: "10px",
        }),
    };
};
    const getModuleFromRate = ( rate: any ): string => { if (!rate) {return "";}
        const directValues = [ rate.module, rate.moduleName, rate.module_name, 
            rate.modules, rate.moduleTitle, rate.module_title, ];
        for (const value of directValues) {
            if ( typeof value === "string" && value.trim() ) {
                return value.trim();
            }
        }

        const objectValues = [
            rate.module,
            rate.modules,
            rate.moduleData,
            rate.module_data,
        ];

        for (const value of objectValues) {
            if (
                value &&
                typeof value === "object"
            ) {
                const nestedValues = [
                    value.label,
                    value.name,
                    value.value,
                    value.title,
                    value.module,
                    value.moduleName,
                ];

                for (
                    const nestedValue of nestedValues
                ) {
                    if (
                        typeof nestedValue ===
                            "string" &&
                        nestedValue.trim()
                    ) {
                        return nestedValue.trim();
                    }
                }
            }
        }

        if (
            rate.category &&
            typeof rate.category === "object"
        ) {
            const categoryModule =
                rate.category.module;

            if (
                typeof categoryModule ===
                    "string" &&
                categoryModule.trim()
            ) {
                return categoryModule.trim();
            }

            if (
                categoryModule &&
                typeof categoryModule ===
                    "object"
            ) {
                return String(
                    categoryModule.label ??
                        categoryModule.name ??
                        categoryModule.value ??
                        ""
                ).trim();
            }
        }

        const fallbackValues = [
            rate.moduleCode,
            rate.module_code,
            rate.moduleId,
            rate.module_id,
        ];

        for (const value of fallbackValues) {
            if (
                value !== undefined &&
                value !== null &&
                String(value).trim()
            ) {
                return String(value).trim();
            }
        }

        return "";
    };

    const handleAddRates = ( selectedRates: RateItem[] ) => {
        if ( !selectedRates || selectedRates.length === 0 ) {
            return;
        }

        const currentMaxId =
            boqItems.length > 0
                ? Math.max(
                      ...boqItems.map((item) =>
                          Number(item.id)
                      )
                  )
                : 0;

        const newItems: BOQItemm[] =
            selectedRates.map(
                (rate: RateItem,index) => {
                    const rawRate = rate as any;
                    const module = getModuleFromRate( rawRate );

                    let category = "";

                    if ( typeof rawRate.category === "string") {
                        category = rawRate.category;
                    } else if ( rawRate.category && typeof rawRate.category === "object") {
                        category = rawRate.category .label ?? rawRate.category .name ?? rawRate.category .value ??
                            "";
                    }

                    const description =
                        String(
                            rawRate.description ??
                                rawRate.itemDescription ??
                                rawRate.item_description ??
                                rawRate.name ??
                                ""
                        ).trim();

                    let unit = "Unit";

                    if (
                        typeof rawRate.unit === "string"
                    ) { unit = rawRate.unit;
                    } else if (
                        rawRate.unit &&
                        typeof rawRate.unit === "object"
                    ) { unit = rawRate.unit .label ?? rawRate.unit .name ?? rawRate.unit .value ?? "Unit"; }

                    const masterRate = 
                        Number( rawRate.standardRate ?? rawRate.standard_rate ??
                                rawRate.rate ?? rawRate.unitRate ?? rawRate.unit_rate ?? 0 );

                    const categoryType =
                        String(
                            rawRate.categoryType ??
                                rawRate.categorytype ??
                                rawRate.category_type ??
                                ""
                        ).trim();

                    return {
                        id:
                            currentMaxId +
                            index +
                            1,

                        module:
                            module || "-",

                        category:
                            category ||
                            "General",

                        description:
                            description ||
                            "-",

                        unit:
                            unit || "Unit",

                        quantity: 1,

                        rate:
                            Number.isFinite(
                                masterRate
                            )
                                ? masterRate
                                : 0,

                        categoryType,
                    };
                }
            );

        setBoqItems(
            (currentItems) => [
                ...currentItems,
                ...newItems,
            ]
        );

        setIsBrowseRateOpen(false);
    };

    const handleStartAddItem = ( sectionId: number, category: string ) => { 
        if (addingSectionId !== null) {
            return;
        }

        setAddingSectionId(sectionId);

        setNewBOQItem({
            module: "",
            category,
            description: "",
            unit: "",
            quantity: "1",
            rate: "",
        });
    };



    const handleNewBOQItemChange = (
        field: keyof NewBOQItem,
        value: string
    ) => {
        setNewBOQItem((current) => ({
            ...current,
            [field]: value,
        }));
    };

    const resetNewBOQItem = () => {
        setNewBOQItem({
            module: "",
            category: "",
            description: "",
            unit: "",
            quantity: "1",
            rate: "",
        });

        setAddingSectionId(null);
    };

    const handleSaveNewBOQItem = () => { const module = newBOQItem.module.trim(); 
        const category = newBOQItem.category.trim();
        const description = newBOQItem.description.trim();
        const unit = newBOQItem.unit.trim();
        const quantity = Number( newBOQItem.quantity );
        const rate = Number( newBOQItem.rate );
        if ( !module || !category || !description || !unit ||
            !Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(rate) || rate < 0 ) {
            return;
        }

        const currentMaxId =
            boqItems.length > 0
                ? Math.max(
                      ...boqItems.map((item) =>
                          Number(item.id)
                      )
                  )
                : 0;

        const newItem: BOQItemm = {
            id: currentMaxId + 1,
            module,
            category,
            description,
            unit,
            quantity,
            rate,
            categoryType: ""
        };

        setBoqItems(
            (currentItems) => [
                ...currentItems,
                newItem,
            ]
        );

        /*
         * Close inline row
         */
        resetNewBOQItem();
    };

    const removeBOQItem = (
        id: number
    ) => {
        setBoqItems(
            (currentItems) =>
                currentItems.filter(
                    (item) =>
                        Number(item.id) !==
                        Number(id)
                )
        );
    };

    const subtotal = useMemo(() => {
        return boqItems.reduce(
            (total, item) => {
                const quantity =
                    Number(
                        item.quantity || 0
                    );

                const rate =
                    Number(item.rate || 0);

                return (
                    total +
                    quantity * rate
                );
            },
            0
        );
    }, [boqItems]);

    const contingency =
        subtotal * 0.1;

    const grandTotal =
        subtotal + contingency;

    const totalInstallmentAmount =
        useMemo(() => {
            return paymentInstallments.reduce(
                (
                    total,
                    installment
                ) =>
                    total +
                    Number(
                        installment.amount ||
                            0
                    ),
                0
            );
        }, [paymentInstallments]);

    const remainingBalance =
        Math.max(
            0,
            grandTotal -
                totalInstallmentAmount
        );

    const handlePaymentToggle = (
        mode:
            | "amount"
            | "percentage"
    ) => {
        setPaymentToggle(mode);

        setNewInstallment({
            name: "",
            value: "",
            dueDate: "",
        });
    };

    const addInstallment = () => {
        const name =
            newInstallment.name.trim();

        const inputValue = Number(
            newInstallment.value
        );

        if (!name) {
            return;
        }

        if (
            !Number.isFinite(
                inputValue
            ) ||
            inputValue <= 0
        ) {
            return;
        }

        if (!newInstallment.dueDate) {
            return;
        }

        if (
            paymentToggle ===
                "percentage" &&
            inputValue > 100
        ) {
            return;
        }

        if (grandTotal <= 0) {
            return;
        }

        const amount =
            paymentToggle ===
            "amount"
                ? inputValue
                : (grandTotal *
                      inputValue) /
                  100;

        if (
            !Number.isFinite(amount) ||
            amount <= 0
        ) {
            return;
        }

        if (
            amount >
            remainingBalance
        ) {
            return;
        }

        const newItem: PaymentInstallment =
            {
                id: Date.now(),
                name,
                amount,
                type:
                    paymentInstallments.length ===
                    0
                        ? "advance"
                        : "balance",
                dueDate:
                    newInstallment.dueDate,
            };

        setPaymentInstallments(
            (
                currentInstallments
            ) => [
                ...currentInstallments,
                newItem,
            ]
        );

        setNewInstallment({
            name: "",
            value: "",
            dueDate: "",
        });
    };


    const documentTypeOptions = [
    {
        value: "BOQ",
        label: "BOQ",
    },
    {
        value: "Vendor Quotation",
        label: "Vendor Quotation",
    },
    {
        value: "Supporting Document",
        label: "Supporting Document",
    },
    {
        value: "Contract",
        label: "Contract",
    },
    {
        value: "Other",
        label: "Other",
    },
];

    const [documentType, setDocumentType] = useState("");

const [uploadedDocuments, setUploadedDocuments] =
    useState<UploadedDocument[]>([]);

const handleDocumentUpload = (
    files: FileList | null
) => {
    if (!files || files.length === 0 || !documentType) {
        return;
    }

    const newDocuments: UploadedDocument[] =
        Array.from(files).map((file) => ({
            id: `${Date.now()}-${Math.random()
                .toString(36)
                .slice(2)}`,
            name: file.name,
            size: file.size,
            type: documentType,
            file,
        }));

    setUploadedDocuments((current) => [
        ...current,
        ...newDocuments,
    ]);
};

const removeDocument = (id: string) => {
    setUploadedDocuments((current) =>
        current.filter(
            (document) => document.id !== id
        )
    );
};

const formatFileSize = (bytes: number) => {
    if (bytes === 0) {
        return "0 Bytes";
    }

    const units = [
        "Bytes",
        "KB",
        "MB",
        "GB",
    ];

    const index = Math.floor(
        Math.log(bytes) / Math.log(1024)
    );

    return `${(
        bytes /
        Math.pow(1024, index)
    ).toFixed(index === 0 ? 0 : 1)} ${
        units[index]
    }`;
};
    const removeInstallment = (
        id: number
    ) => {
        setPaymentInstallments(
            (
                currentInstallments
            ) =>
                currentInstallments.filter(
                    (installment) =>
                        installment.id !==
                        id
                )
        );
    };

    const getSectionTotal = (
        category: string
    ) => {
        return boqItems
            .filter(
                (item) =>
                    item.category ===
                    category
            )
            .reduce(
                (
                    total,
                    item
                ) =>
                    total +
                    Number(
                        item.quantity ||
                            0
                    ) *
                        Number(
                            item.rate ||
                                0
                        ),
                0
            );
    };

    const inputClass =
        "w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-[9px] text-slate-700 outline-none placeholder:text-slate-400 focus:border-red-300 focus:ring-1 focus:ring-red-100";

    const boqColumns: DataTableColumn<BOQItemm>[] =
        [
            {
                key: "module",
                label: "Modules",
                width: "150px",

                render: (item) => (
                    <div className="min-w-0">
                        <span
                            className="block truncate text-[10px] font-semibold text-slate-700"
                            title={
                                item.module ||
                                "-"
                            }
                        >
                            {item.module ||
                                "-"}
                        </span>
                    </div>
                ),
            },

            {
                key: "category",
                label: "Category",
                width: "150px",

                render: (item) => (
                    <div className="min-w-0">
                        <span
                            className="block truncate text-[10px] font-medium text-slate-600"
                            title={
                                item.category ||
                                "-"
                            }
                        >
                            {item.category ||
                                "-"}
                        </span>
                    </div>
                ),
            },

            {
                key: "description",
                label: "Description",
                width: "250px",

                render: (item) => (
                    <div className="min-w-0">
                        <span className="block text-[10px] font-medium leading-5 text-slate-700">
                            {item.description ||
                                "-"}
                        </span>
                    </div>
                ),
            },

            {
                key: "unit",
                label: "Unit",
                width: "100px",

                render: (item) => (
                    <span className="block text-[10px] font-medium text-slate-600">
                        {item.unit ||
                            "-"}
                    </span>
                ),
            },

            {
                key: "quantity",
                label: "Qty",
                width: "80px",
                align: "right",

                render: (item) => (
                    <span className="block text-[10px] font-semibold text-slate-700">
                        {Number(
                            item.quantity ||
                                0
                        )}
                    </span>
                ),
            },

            {
                key: "rate",
                label: "Rate",
                width: "120px",
                align: "right",

                render: (item) => (
                    <span className="block text-[10px] font-semibold text-slate-700">
                        J${" "}
                        {formatCurrency(
                            Number(
                                item.rate ||
                                    0
                            )
                        )}
                    </span>
                ),
            },

            {
                key: "total",
                label: "Total",
                width: "120px",
                align: "right",

                render: (item) => {
                    const quantity =
                        Number(
                            item.quantity ||
                                0
                        );

                    const rate =
                        Number(
                            item.rate ||
                                0
                        );

                    const total =
                        quantity * rate;

                    return (
                        <span className="block text-[10px] font-bold text-slate-900">
                            J${" "}
                            {formatCurrency(
                                total
                            )}
                        </span>
                    );
                },
            },

            {
                key: "actions",
                label: "",
                width: "50px",
                align: "center",

                render: (item) => (
                    <button
                        type="button"
                        onClick={() =>
                            removeBOQItem(
                                Number(
                                    item.id
                                )
                            )
                        }
                        title="Delete item"
                        className="flex h-6 w-6 items-center justify-center rounded-md text-slate-300 transition hover:bg-red-50 hover:text-red-500"
                    >
                        <TrashIcon
                            size={13}
                            weight="bold"
                        />
                    </button>
                ),
            },
        ];

    const navigate = useNavigate();
    return (
        <div className="min-h-screen bg-slate-50">
            <div className="space-y-4">
                   <QuotationHeader
                        showNewQuotation={false}
                        showAddBOQ={false}
                        showBoqActions={true}
                        onExportEstimate={onExportEstimate}
                        onGenerateQuotation={onGenerateQuotation}
                        boqData={boqItems}
                    />

                    <div className="flex w-full items-center">
                        <QuotationTabs
                            activeTab="boq"
                            onChange={(tab) => {
                                if (tab === "bids") {
                                    navigate("/quotation");
                                }

                                if (tab === "boq") {
                                    navigate("/quotation/project_boq");
                                }
                            }}
                        />
                    </div>
                </div>
            <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_280px] pt-6">
                <div className="space-y-5">

                <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                    {/* HEADER */}
                    <div className="border-b border-slate-200 px-5 py-4">
                        <div className="flex items-center justify-between gap-4">

                            {/* LEFT SIDE */}
                            <div className="flex items-center gap-3">

                                {/* BACK BUTTON */}
                                <button
                                    type="button"
                                    onClick={() =>
                                        navigate("/quotation/project_boq")
                                    }
                                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 transition-colors hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                                    title="Back to Project BOQ"
                                >
                                    <ArrowLeftIcon
                                        size={15}
                                        weight="bold"
                                    />
                                </button>

                                {/* SECTION ICON */}
                                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                    <FileTextIcon
                                        size={14}
                                        weight="duotone"
                                    />
                                </div>

                                {/* TITLE */}
                                <div>
                                    <h2 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                                        Project &amp; Vendor Assignment
                                    </h2>

                                    <p className="mt-0.5 text-[10px] uppercase tracking-wide text-slate-400">
                                        Define the project and assigned vendors
                                    </p>
                                </div>

                            </div>

                          

                        </div>
                    </div>



                    {/* FORM */}
                    <div className="grid grid-cols-1 gap-x-5 gap-y-4 p-5 md:grid-cols-2 xl:grid-cols-4">
                        {/* PROJECT NAME */}
                        <div className="md:col-span-1 xl:col-span-2">
                            <Field
                                label="Project Name"
                                type="text"
                                value={projectName}
                                onChange={(e) => setProjectName(e.target.value)}
                                placeholder="e.g. Kingston Fiber Expansion"
                            />
                        </div>

                        {/* FORM TEMPLATE */}
                        <div className="md:col-span-1 xl:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                                Form Template
                            </label>

                            <Select<SelectOption, false>
                                options={FORM_TEMPLATE_OPTIONS}
                                value={formTemplate}
                                onChange={(selectedOption) =>
                                    setFormTemplate(selectedOption)
                                }
                                placeholder="Select Form Template"
                                styles={getSelectStyles()}
                                isSearchable={false}
                                isMulti={false}
                            />
                        </div>
                        

                        {/* SITE SURVEY REFERENCE */}
                        <div className="md:col-span-1 xl:col-span-2">
                            <Field
                                label="Site Survey Reference"
                                type="text"
                                value={siteSurveyReference}
                                onChange={(e) => setSiteSurveyReference(e.target.value)}
                                placeholder="e.g. SURV-2024-001"
                            />
                        </div>

                        {/* DATE */}
                        <div className="md:col-span-1 xl:col-span-2">
                            <Field
                                label="Response Due Date"
                                type="date"
                                value={validityPeriod}
                                onChange={(e) => setValidityPeriod(e.target.value)}
                            />
                        </div>

                        {/* PROJECT VALue */}
                        <div className="md:col-span-1 xl:col-span-2">
                            <Field
                                label="Project Value"
                                type="text"
                                value={projectValue}
                                onChange={(e) => setProjectValue(e.target.value)}
                                placeholder="e.g. $25,000"
                            />
                        </div>
                         {/* PROJECT SITE LOCATION */}
                        <div className="md:col-span-1 xl:col-span-2">
                            <Field
                                label="Project Site Location"
                                type="text"
                                value={projectSiteLocation}
                                onChange={(e) => setProjectSiteLocation(e.target.value)}
                                placeholder="e.g. Kingston, Jamaica"
                            />
                        </div>
                        {/* ASSIGNING VENDORS */}
                       <div className="col-span-1 md:col-span-2 xl:col-span-4">
                            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                                Assigning Vendors
                            </label>

                            <Select<SelectOption, true>
                                options={VENDOR_OPTIONS}
                                value={vendors}
                                onChange={(selectedOptions) =>
                                    setVendors(selectedOptions ? [...selectedOptions] : [])
                                }
                                placeholder="Select Vendors"
                                styles={getSelectStyles()}
                                isSearchable={false}
                                isMulti
                                closeMenuOnSelect={false}
                                hideSelectedOptions={false}
                            />
                        </div>

                        



                    </div>

                </section>
                    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        {/* BOQ HEADER */}
                        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-5 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                    Structured
                                    Bill of
                                    Quantities
                                    Estimator
                                </h2>
                                <p className="mt-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                    {
                                        boqItems.length
                                    }{" "}
                                    {boqItems.length ===
                                    1
                                        ? "Line Item"
                                        : "Line Items"}{" "}
                                    Calculated
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={() =>
                                    setIsBrowseRateOpen(
                                        true
                                    )
                                }
                                className="flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-red-700"
                            >
                                <PlusIcon
                                    size={14}
                                    weight="bold"
                                />

                                Browse &amp;
                                Add Rates
                            </button>

                        </div>

                        {/* BOQ CONTENT */}

                        <div className="p-5">

                            <div className="space-y-8">

                                {BOQ_SECTIONS.map(
                                    (section) => {

                                        const sectionItems =
                                            boqItems.filter(
                                                (
                                                    item
                                                ) =>
                                                    item.category ===
                                                    section.category
                                            );

                                        const sectionTotal =
                                            getSectionTotal(
                                                section.category
                                            );

                                        const isAdding =
                                            addingSectionId ===
                                            section.id;

                                        return (
                                            <div
                                                key={
                                                    section.id
                                                }
                                            >

                                                <div className="mb-3 flex items-center justify-between border-b border-slate-200 pb-3">

                                                    <div className="flex items-center gap-2.5">

                                                        <div
                                                            className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold text-white ${section.color}`}
                                                        >
                                                            {
                                                                section.id
                                                            }
                                                        </div>

                                                        <h3 className="text-[10px] font-bold uppercase tracking-wide text-slate-900">
                                                            {
                                                                section.title
                                                            }
                                                        </h3>

                                                    </div>

                                                    <div className="flex items-center gap-3">

                                                        {/* SUBTOTAL */}

                                                        <div className="text-right">
                                                            <p className="text-[8px] font-bold uppercase text-slate-400">
                                                                Subtotal
                                                            </p>

                                                            <p className="mt-0.5 text-[10px] font-bold text-slate-700">
                                                                J${" "}
                                                                {formatCurrency(
                                                                    sectionTotal
                                                                )}
                                                            </p>
                                                        </div>

                                                        {/* ADD ITEM */}

                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                handleStartAddItem(
                                                                    section.id,
                                                                    section.category
                                                                )
                                                            }
                                                            disabled={
                                                                addingSectionId !==
                                                                null
                                                            }
                                                            className="flex items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-[9px] font-bold text-red-600 transition hover:border-red-300 hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-40"
                                                        >
                                                            <PlusIcon
                                                                size={
                                                                    11
                                                                }
                                                                weight="bold"
                                                            />

                                                            Add Item
                                                        </button>

                                                        <CaretDownIcon
                                                            size={
                                                                12
                                                            }
                                                            className="text-slate-400"
                                                        />

                                                    </div>

                                                </div>

                                                <div className="overflow-hidden rounded-lg border border-slate-200">

                                                    {/* TABLE HEADER */}

                                                    <div className="overflow-x-auto">

                                                        <table className="w-full min-w-[1100px] border-collapse">

                                                            <thead>

                                                                <tr className="bg-slate-50">

                                                                    <th className="w-[150px] border-b border-slate-200 px-3 py-2 text-left text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Modules
                                                                    </th>

                                                                    <th className="w-[150px] border-b border-slate-200 px-3 py-2 text-left text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Category
                                                                    </th>

                                                                    <th className="w-[250px] border-b border-slate-200 px-3 py-2 text-left text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Description
                                                                    </th>

                                                                    <th className="w-[100px] border-b border-slate-200 px-3 py-2 text-left text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Unit
                                                                    </th>

                                                                    <th className="w-[80px] border-b border-slate-200 px-3 py-2 text-right text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Qty
                                                                    </th>

                                                                    <th className="w-[120px] border-b border-slate-200 px-3 py-2 text-right text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Rate
                                                                    </th>

                                                                    <th className="w-[120px] border-b border-slate-200 px-3 py-2 text-right text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Total
                                                                    </th>

                                                                    <th className="w-[60px] border-b border-slate-200 px-3 py-2 text-center text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                                                        Action
                                                                    </th>

                                                                </tr>

                                                            </thead>

                                                            <tbody>

                                                                {sectionItems.map(
                                                                    (
                                                                        item
                                                                    ) => {

                                                                        const total =
                                                                            Number(
                                                                                item.quantity ||
                                                                                    0
                                                                            ) *
                                                                            Number(
                                                                                item.rate ||
                                                                                    0
                                                                            );

                                                                        return (
                                                                            <tr
                                                                                key={
                                                                                    item.id
                                                                                }
                                                                                className="border-b border-slate-100 bg-white transition hover:bg-slate-50"
                                                                            >

                                                                                <td className="px-3 py-2.5">
                                                                                    <span className="block truncate text-[10px] font-semibold text-slate-700">
                                                                                        {
                                                                                            item.module
                                                                                        }
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5">
                                                                                    <span className="block truncate text-[10px] font-medium text-slate-600">
                                                                                        {
                                                                                            item.category
                                                                                        }
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5">
                                                                                    <span className="block text-[10px] font-medium leading-5 text-slate-700">
                                                                                        {
                                                                                            item.description
                                                                                        }
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5">
                                                                                    <span className="text-[10px] font-medium text-slate-600">
                                                                                        {
                                                                                            item.unit
                                                                                        }
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5 text-right">
                                                                                    <span className="text-[10px] font-semibold text-slate-700">
                                                                                        {Number(
                                                                                            item.quantity ||
                                                                                                0
                                                                                        )}
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5 text-right">
                                                                                    <span className="text-[10px] font-semibold text-slate-700">
                                                                                        J${" "}
                                                                                        {formatCurrency(
                                                                                            Number(
                                                                                                item.rate ||
                                                                                                    0
                                                                                            )
                                                                                        )}
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5 text-right">
                                                                                    <span className="text-[10px] font-bold text-slate-900">
                                                                                        J${" "}
                                                                                        {formatCurrency(
                                                                                            total
                                                                                        )}
                                                                                    </span>
                                                                                </td>

                                                                                <td className="px-3 py-2.5 text-center">

                                                                                    <button
                                                                                        type="button"
                                                                                        onClick={() =>
                                                                                            removeBOQItem(
                                                                                                Number(
                                                                                                    item.id
                                                                                                )
                                                                                            )
                                                                                        }
                                                                                        title="Delete item"
                                                                                        className="mx-auto flex h-6 w-6 items-center justify-center rounded-md text-slate-300 transition hover:bg-red-50 hover:text-red-500"
                                                                                    >
                                                                                        <TrashIcon
                                                                                            size={
                                                                                                13
                                                                                            }
                                                                                            weight="bold"
                                                                                        />
                                                                                    </button>

                                                                                </td>

                                                                            </tr>
                                                                        );
                                                                    }
                                                                )}

                                                                {isAdding && (
                                                                    <tr className="border-b border-red-100 bg-red-50/40">

                                                                        {/* MODULE */}

                                                                        <td className="px-2 py-2">
                                                                            <input autoFocus type="text" 
                                                                            value={ newBOQItem.module }
                                                                            onChange={( e ) => handleNewBOQItemChange(
                                                                                        "module", e .target .value ) }
                                                                            placeholder="Module"
                                                                            className={ inputClass }
                                                                            />
                                                                        </td>

                                                                        {/* CATEGORY */}

                                                                        <td className="px-2 py-2">
                                                                            <input type="text"
                                                                                value={ newBOQItem.category }
                                                                                onChange={( e ) => handleNewBOQItemChange(
                                                                                        "category", e .target .value ) }
                                                                                placeholder="Category"
                                                                                className={ inputClass }
                                                                            />
                                                                        </td>

                                                                        {/* DESCRIPTION */}

                                                                        <td className="px-2 py-2">
                                                                            <input type="text" 
                                                                            value={ newBOQItem.description }
                                                                            onChange={( e ) =>
                                                                                handleNewBOQItemChange("description",e.target.value)}
                                                                                placeholder="Item description"
                                                                                className={inputClass}
                                                                            />
                                                                        </td>

                                                                        {/* UNIT */}

                                                                        <td className="px-2 py-2">
                                                                            <input type="text" 
                                                                            value={newBOQItem.unit}
                                                                            onChange={(e) =>
                                                                            handleNewBOQItemChange("unit",e.target.value)}
                                                                            placeholder="Unit"
                                                                            className={inputClass}
                                                                            />
                                                                        </td>

                                                                        {/* QUANTITY */}

                                                                        <td className="px-2 py-2">
                                                                            <input type="number"
                                                                                min="0"
                                                                                step="0.01"
                                                                                value={newBOQItem.quantity}
                                                                                onChange={(e) =>
                                                                                handleNewBOQItemChange("quantity",e.target.value)}
                                                                                className={`${inputClass} text-right`}
                                                                            />
                                                                        </td>

                                                                        {/* RATE */}

                                                                        <td className="px-2 py-2">
                                                                            <input
                                                                                type="number"
                                                                                min="0"
                                                                                step="0.01"
                                                                                value={
                                                                                    newBOQItem.rate
                                                                                }
                                                                                onChange={(
                                                                                    e
                                                                                ) =>
                                                                                    handleNewBOQItemChange(
                                                                                        "rate",
                                                                                        e
                                                                                            .target
                                                                                            .value
                                                                                    )
                                                                                }
                                                                                placeholder="Rate"
                                                                                className={`${inputClass} text-right`}
                                                                            />
                                                                        </td>

                                                                        {/* TOTAL PREVIEW */}

                                                                        <td className="px-2 py-2 text-right">

                                                                            <span className="text-[10px] font-bold text-red-600">
                                                                                J${" "}
                                                                                {formatCurrency(
                                                                                    Number(
                                                                                        newBOQItem.quantity ||
                                                                                            0
                                                                                    ) *
                                                                                        Number(
                                                                                            newBOQItem.rate ||
                                                                                                0
                                                                                        )
                                                                                )}
                                                                            </span>

                                                                        </td>

                                                                        {/* ACTIONS */}

                                                                        <td className="px-2 py-2">

                                                                            <div className="flex items-center justify-center gap-1">

                                                                                <button
                                                                                    type="button"
                                                                                    onClick={
                                                                                        handleSaveNewBOQItem
                                                                                    }
                                                                                    disabled={
                                                                                        !newBOQItem.module.trim() ||
                                                                                        !newBOQItem.category.trim() ||
                                                                                        !newBOQItem.description.trim() ||
                                                                                        !newBOQItem.unit.trim() ||
                                                                                        Number(
                                                                                            newBOQItem.quantity
                                                                                        ) <=
                                                                                            0 ||
                                                                                        !newBOQItem.rate ||
                                                                                        Number(
                                                                                            newBOQItem.rate
                                                                                        ) <
                                                                                            0
                                                                                    }
                                                                                    title="Save item"
                                                                                    className="flex h-6 w-6 items-center justify-center rounded-md bg-emerald-50 text-emerald-600 transition hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-40"
                                                                                >
                                                                                    <CheckIcon
                                                                                        size={
                                                                                            12
                                                                                        }
                                                                                        weight="bold"
                                                                                    />
                                                                                </button>

                                                                                <button
                                                                                    type="button"
                                                                                    onClick={
                                                                                        resetNewBOQItem
                                                                                    }
                                                                                    title="Cancel"
                                                                                    className="flex h-6 w-6 items-center justify-center rounded-md bg-slate-100 text-slate-500 transition hover:bg-red-50 hover:text-red-500"
                                                                                >
                                                                                    <XIcon
                                                                                        size={
                                                                                            12
                                                                                        }
                                                                                        weight="bold"
                                                                                    />
                                                                                </button>

                                                                            </div>

                                                                        </td>

                                                                    </tr>
                                                                )}

                                                                {/* ========================================
                                                                    EMPTY STATE
                                                                ========================================= */}

                                                                {sectionItems.length ===
                                                                    0 &&
                                                                    !isAdding && (
                                                                        <tr>

                                                                            <td
                                                                                colSpan={
                                                                                    8
                                                                                }
                                                                                className="px-4 py-6 text-center"
                                                                            >
                                                                                <p className="text-[10px] text-slate-400">
                                                                                    No
                                                                                    items
                                                                                    in
                                                                                    this
                                                                                    section.
                                                                                </p>

                                                                                <button
                                                                                    type="button"
                                                                                    onClick={() =>
                                                                                        handleStartAddItem(
                                                                                            section.id,
                                                                                            section.category
                                                                                        )
                                                                                    }
                                                                                    className="mt-2 inline-flex items-center gap-1 text-[9px] font-bold text-red-600 hover:text-red-700"
                                                                                >
                                                                                    <PlusIcon
                                                                                        size={
                                                                                            11
                                                                                        }
                                                                                        weight="bold"
                                                                                    />
                                                                                    Add
                                                                                    first
                                                                                    item
                                                                                </button>

                                                                            </td>

                                                                        </tr>
                                                                    )}

                                                            </tbody>

                                                        </table>

                                                    </div>

                                                </div>

                                            </div>
                                        );
                                    }
                                )}

                            </div>

                        </div>
                    </section>

                </div>

                <aside className="self-start space-y-5">
                    <section className="top-5 overflow-hidden rounded-2xl bg-slate-900 shadow-lg">

                        <div className="border-b border-slate-800 px-5 py-5">
                            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                Cost Summary
                                (Est.)
                            </p>
                        </div>

                        <div className="space-y-4 px-5 py-5">

                            <div className="flex items-center justify-between">
                                <span className="text-[10px] font-medium text-slate-400">
                                    Sub-Total
                                    Items
                                </span>

                                <span className="text-xs font-bold text-white">
                                    J${" "}
                                    {formatCurrency(
                                        subtotal
                                    )}
                                </span>
                            </div>

                            <div className="flex items-center justify-between">
                                <span className="text-[10px] font-medium text-slate-400">
                                    Contingency
                                    (10%)
                                </span>

                                <span className="text-xs font-bold text-white">
                                    J${" "}
                                    {formatCurrency(
                                        contingency
                                    )}
                                </span>
                            </div>

                            <div className="border-t border-slate-700" />

                            <div>
                                <p className="text-[8px] font-bold uppercase tracking-widest text-red-500">
                                    Grand Total
                                </p>

                                <p className="mt-1 text-xl font-bold text-white">
                                    J${" "}
                                    {formatCurrency(
                                        grandTotal
                                    )}
                                </p>
                            </div>

                            <div className="rounded-xl bg-slate-800/80 p-3.5">

                                <div className="flex gap-2">

                                    <div className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-slate-500 text-[8px] text-slate-400">
                                        i
                                    </div>

                                    <p className="text-[9px] leading-relaxed text-slate-400">
                                        This estimate
                                        is based on
                                        the current
                                        Master Rate
                                        Schedule.
                                        Final
                                        quotation may
                                        vary based on
                                        specific site
                                        conditions and
                                        engineering
                                        requirements.
                                    </p>

                                </div>

                            </div>

                            {paymentInstallments.length >
                                0 && (
                                <>
                                    <div className="border-t border-slate-700" />

                                    <div className="flex items-center justify-between">

                                        <div>
                                            <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">
                                                Scheduled
                                            </p>

                                            <p className="mt-1 text-sm font-bold text-white">
                                                J${" "}
                                                {formatCurrency(
                                                    totalInstallmentAmount
                                                )}
                                            </p>
                                        </div>

                                        <div className="text-right">

                                            <p className="text-[8px] font-bold uppercase tracking-widest text-amber-500">
                                                Remaining
                                            </p>

                                            <p className="mt-1 text-sm font-bold text-amber-400">
                                                J${" "}
                                                {formatCurrency(
                                                    remainingBalance
                                                )}
                                            </p>

                                        </div>

                                    </div>
                                </>
                            )}

                        </div>

                    </section>

                    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

                        {/* <div className="border-b border-slate-200 px-5 py-4">

                            <div className="flex items-center justify-between gap-3">

                                <div>
                                    <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                        Payment
                                        Scheduling
                                    </h2>

                                    <p className="mt-1 text-[10px] leading-relaxed text-slate-500">
                                        Configure payment
                                        installments
                                    </p>
                                </div>

                                <div className="flex shrink-0 rounded-lg bg-slate-100 p-1">

                                    <button
                                        type="button"
                                        onClick={() =>
                                            handlePaymentToggle(
                                                "amount"
                                            )
                                        }
                                        className={`rounded-md px-2.5 py-1 text-[9px] font-bold transition-colors ${
                                            paymentToggle ===
                                            "amount"
                                                ? "bg-red-600 text-white"
                                                : "text-slate-500 hover:text-slate-700"
                                        }`}
                                    >
                                        Amount
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() =>
                                            handlePaymentToggle(
                                                "percentage"
                                            )
                                        }
                                        className={`rounded-md px-2.5 py-1 text-[9px] font-bold transition-colors ${
                                            paymentToggle ===
                                            "percentage"
                                                ? "bg-red-600 text-white"
                                                : "text-slate-500 hover:text-slate-700"
                                        }`}
                                    >
                                        Percentage
                                    </button>

                                </div>

                            </div>

                        </div> */}

                        {/* <div className="p-4"> */}

                            {/* <div className="mb-3 flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5">

                                <span className="text-[10px] font-semibold text-slate-600">
                                    Net Total
                                </span>

                                <span className="text-xs font-bold text-slate-900">
                                    J${" "}
                                    {formatCurrency(
                                        grandTotal
                                    )}
                                </span>

                            </div> */}

                            {/* INSTALLMENTS */}

                            {/* <div className="max-h-64 space-y-2.5 overflow-y-auto">

                                {paymentInstallments.length >
                                0 ? (
                                    paymentInstallments.map(
                                        (
                                            installment,
                                            index
                                        ) => {

                                            const isAdvance =
                                                installment.type ===
                                                "advance";

                                            const percentage =
                                                grandTotal >
                                                0
                                                    ? (installment.amount /
                                                          grandTotal) *
                                                      100
                                                    : 0;

                                            return (
                                                <div
                                                    key={
                                                        installment.id
                                                    }
                                                    className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white p-2.5"
                                                >

                                                    <div className="flex min-w-0 items-start gap-2">

                                                        <span
                                                            className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[9px] font-bold text-white ${
                                                                isAdvance
                                                                    ? "bg-blue-600"
                                                                    : "bg-emerald-600"
                                                            }`}
                                                        >
                                                            {index +
                                                                1}
                                                        </span>

                                                        <div className="min-w-0">

                                                            <p className="truncate text-[10px] font-semibold text-slate-800">
                                                                {
                                                                    installment.name
                                                                }
                                                            </p>

                                                            <p className="text-[8px] text-slate-500">
                                                                {isAdvance
                                                                    ? "Advance Payment"
                                                                    : "Balance Payment"}
                                                            </p>

                                                            <p className="mt-0.5 text-[8px] font-medium text-red-500">
                                                                Due:{" "}
                                                                {new Date(
                                                                    `${installment.dueDate}T00:00:00`
                                                                ).toLocaleDateString(
                                                                    "en-GB",
                                                                    {
                                                                        day: "2-digit",
                                                                        month: "short",
                                                                        year: "numeric",
                                                                    }
                                                                )}
                                                            </p>

                                                        </div>

                                                    </div>

                                                    <div className="flex shrink-0 items-center gap-1">

                                                        <span className="text-[10px] font-bold text-slate-800">
                                                            {paymentToggle === "amount" ? `J$ ${formatCurrency( installment.amount )}` : `${percentage.toFixed(1)}%`}
                                                        </span>

                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                removeInstallment(
                                                                    installment.id
                                                                )
                                                            }
                                                            title="Remove installment"
                                                            className="flex h-6 w-6 items-center justify-center rounded-md text-slate-300 transition hover:bg-red-50 hover:text-red-500"
                                                        >
                                                            <TrashIcon
                                                                size={
                                                                    13
                                                                }
                                                                weight="bold"
                                                            />
                                                        </button>

                                                    </div>

                                                </div>
                                            );
                                        }
                                    )
                                ) : (
                                    <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 text-center">
                                        <p className="text-[10px] text-slate-400">
                                            No installments
                                            added yet
                                        </p>
                                    </div>
                                )}

                            </div> */}

                            {/* REMAINING */}

                            {/* {paymentInstallments.length >
                                0 && (
                                <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2">
                                    <div className="flex items-center justify-between">
                                        <span className="text-[10px] font-semibold text-amber-700">
                                            Remaining
                                            Balance
                                        </span>
                                        <span className="text-[10px] font-bold text-amber-800">
                                            J${" "}
                                            {formatCurrency(
                                                remainingBalance
                                            )}
                                        </span>

                                    </div>

                                </div>
                            )} */}

                            {/* ADD INSTALLMENT */}

                            {/* <div className="mt-3 space-y-2.5">

                                <div>
                                    <label className="mb-1 block text-[9px] font-semibold text-slate-600">
                                        Installment
                                        Name
                                    </label>

                                    <input
                                        type="text"
                                        value={
                                            newInstallment.name
                                        }
                                        onChange={(e) =>
                                            setNewInstallment(
                                                (
                                                    current
                                                ) => ({
                                                    ...current,
                                                    name: e
                                                        .target
                                                        .value,
                                                })
                                            )
                                        }
                                        placeholder="e.g. Mobilization Fee"
                                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-[10px] text-slate-700 outline-none placeholder:text-slate-400 transition focus:border-red-300 focus:bg-white"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1 block text-[9px] font-semibold text-slate-600">
                                        {paymentToggle ===
                                        "amount"
                                            ? "Amount"
                                            : "Percentage (%)"}
                                    </label>

                                    <input
                                        type="number"
                                        min="0"
                                        max={
                                            paymentToggle ===
                                            "percentage"
                                                ? 100
                                                : undefined
                                        }
                                        step={
                                            paymentToggle ===
                                            "amount"
                                                ? "0.01"
                                                : "0.1"
                                        }
                                        value={
                                            newInstallment.value
                                        }
                                        onChange={(e) =>
                                            setNewInstallment(
                                                (
                                                    current
                                                ) => ({
                                                    ...current,
                                                    value: e
                                                        .target
                                                        .value,
                                                })
                                            )
                                        }
                                        placeholder={
                                            paymentToggle ===
                                            "amount"
                                                ? "Enter amount"
                                                : "Enter %"
                                        }
                                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-[10px] text-slate-700 outline-none placeholder:text-slate-400 transition focus:border-red-300 focus:bg-white"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1 block text-[9px] font-semibold text-slate-600">
                                        Due Date
                                    </label>

                                    <input
                                        type="date"
                                        value={
                                            newInstallment.dueDate
                                        }
                                        onChange={(e) =>
                                            setNewInstallment(
                                                (
                                                    current
                                                ) => ({
                                                    ...current,
                                                    dueDate:
                                                        e
                                                            .target
                                                            .value,
                                                })
                                            )
                                        }
                                        min={
                                            new Date()
                                                .toISOString()
                                                .split(
                                                    "T"
                                                )[0]
                                        }
                                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-[10px] text-slate-700 outline-none transition focus:border-red-300 focus:bg-white"
                                    />
                                </div>

                                {grandTotal <=
                                    0 &&
                                    newInstallment.value && (
                                        <p className="text-[9px] font-medium text-red-500">
                                            Add at least one
                                            BOQ rate before
                                            creating a payment
                                            installment.
                                        </p>
                                    )}

                                {Number(
                                    newInstallment.value
                                ) >
                                    0 &&
                                    grandTotal >
                                        0 &&
                                    paymentToggle ===
                                        "amount" &&
                                    Number(
                                        newInstallment.value
                                    ) >
                                        remainingBalance && (
                                        <p className="text-[9px] font-medium text-red-500">
                                            Amount cannot be
                                            greater than the
                                            remaining balance
                                            of J${" "}
                                            {formatCurrency(
                                                remainingBalance
                                            )}
                                        </p>
                                    )}

                                {Number(
                                    newInstallment.value
                                ) >
                                    100 &&
                                    paymentToggle ===
                                        "percentage" && (
                                        <p className="text-[9px] font-medium text-red-500">
                                            Percentage cannot
                                            exceed 100%.
                                        </p>
                                    )}

                                <button
                                    type="button"
                                    onClick={
                                        addInstallment
                                    }
                                    disabled={!newInstallment.name.trim() || !newInstallment.value || Number( newInstallment.value ) <= 0 ||
                                        !newInstallment.dueDate || grandTotal <= 0 || remainingBalance <=0 ||  (paymentToggle === "percentage" &&
                                            Number(newInstallment.value ) >  100) ||(paymentToggle === "amount" &&Number( newInstallment.value ) >
                                                remainingBalance)}
                                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-slate-100 px-4 py-2 text-[10px] font-semibold text-slate-600 transition hover:bg-slate-200 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                    <PlusIcon
                                        size={13}
                                        weight="bold"
                                    />

                                    Add Installment
                                </button>

                            </div> */}

                        {/* </div> */}

                    </section>
                </aside>
            </div>

            <BrowseAddRate
                isOpen={isBrowseRateOpen}
                onClose={() => setIsBrowseRateOpen(false)}
                onAddRates={handleAddRates}
            />
        </div>
    );
};

export default ProjectBOQ;
