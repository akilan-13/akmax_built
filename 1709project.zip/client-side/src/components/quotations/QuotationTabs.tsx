import {
    FileTextIcon,
    CalculatorIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

export type QuotationTab =
    | "bids"
    | "boq";

interface QuotationTabsProps {
    activeTab: QuotationTab;
    onChange: (tab: QuotationTab) => void;
}

const QuotationTabs = ({
    activeTab,
    onChange,
}: QuotationTabsProps) => {
    const navigate = useNavigate();
    return (
        <div className="inline-flex items-center rounded-xl bg-slate-100 p-1">

            {/* BIDS & PROPOSALS */}

            <button
                type="button"
                onClick={() => onChange("bids")}
                className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                    activeTab === "bids"
                        ? "bg-white text-red-600 shadow-sm"
                        : "text-slate-500 hover:text-slate-700"
                }`}
            >
                <span>
                    BIDS &amp; PROPOSALS
                </span>
            </button>


            {/* PROJECT BOQ ESTIMATOR */}

            <button
                type="button"
                onClick={() => {
                    onChange("boq");
                    navigate("/quotation/project_boq");
                }}
                className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                    activeTab === "boq"
                        ? "bg-white text-red-600 shadow-sm"
                        : "text-slate-500 hover:text-slate-700"
                }`}
            >

                <span>
                    PROJECT BOQ Approval
                </span>
            </button>

        </div>
    );
};

export default QuotationTabs;
