import { useState } from "react";
import {
    EyeIcon,
    PencilSimpleIcon,
    TrashIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

import DataTable, {
    DataTableColumn,
} from "../DataTable";

import QuotationHeader from "./QuotationHeader";
import QuotationTabs from "./QuotationTabs";

import { ProjectBOQQuotation, projectBOQQuotations } from "../../data/quotations";
import ViewQuotationDrawer from "../../offcanvas/quotation/ViewQuotationDrawer";

interface ProjectBOQListProps {
    onAddBOQ: () => void;
    onView?: (quotation: ProjectBOQQuotation) => void;
    onEdit?: (quotation: ProjectBOQQuotation) => void;
    activeTab?: "bids" | "boq";
    onTabChange?: (tab: "bids" | "boq") => void;
    onExportEstimate?: () => void;
    onGenerateQuotation?: () => void;
    showBoqActions?: boolean;
}

const ProjectBOQList = ({
    onAddBOQ,
    onView,
    onEdit,
    activeTab = "boq",
    onTabChange,
    onExportEstimate,
    onGenerateQuotation,
    showBoqActions = true,
}: ProjectBOQListProps) => {
    const navigate = useNavigate();
    const [selectedQuotation, setSelectedQuotation] = useState<ProjectBOQQuotation | null>(null);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [showVendors, setShowVendors] = useState(false);
    const [selectedVendors, setSelectedVendors] = useState<string[]>([]);


    const formatCurrency = (value: number) => {
        return Number(value || 0).toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
    };

const getStatusClass = (status: string) => {
    switch (status) {
        case "Draft":
            return "bg-slate-100 text-slate-600";

        case "Generated Quotation":
            return "bg-blue-50 text-blue-600";

        case "Awarded":
            return "bg-emerald-50 text-emerald-600";

        case "Converted to Project":
            return "bg-purple-50 text-purple-600";

        case "Pending Approval":
            return "bg-amber-100 text-amber-600";
    }
};


    const handleViewQuotation = (quotation: ProjectBOQQuotation) => {
        setSelectedQuotation(quotation);
        setIsDrawerOpen(true);
        onView?.(quotation);
    };

    const handleShowVendors = (vendors: string[]) => {
    setSelectedVendors(vendors);
    setShowVendors(true);
};


    // const handleEditQuotation = (quotation: ProjectBOQQuotation) => {
    //     setIsDrawerOpen(false);
    //     onEdit?.(quotation);
    // };
const handleEditQuotation = (quotation: ProjectBOQQuotation) => {
    navigate("/quotation/project_boq/edit-boq", {
        state: {
            mode: "edit",
            quotation,
        },
    });
};

const columns: DataTableColumn<ProjectBOQQuotation>[] = [
    {
        key: "quotationNo",
        label: "Quotation No",
        width: "110px",
        sortable: true,
        render: (quotation) => (
            <span className="text-[12px] font-bold text-slate-800 whitespace-nowrap">
                {quotation.quotationNo}
            </span>
        ),
    },
    {
        key: "projectTitle",
        label: "Project",
        width: "200px",
        sortable: true,
        render: (quotation) => (
            <span
                className="block max-w-[200px] truncate text-[12px] font-semibold text-slate-700"
                title={quotation.projectTitle}
            >
                {quotation.projectTitle}
            </span>
        ),
    },
    {
    key: "vendor",
    label: "Vendors",
    width: "190px",
    sortable: false,
    render: (quotation) => {
        const visibleVendors = quotation.vendor.slice(0, 3);
        const remainingCount = quotation.vendor.length - 3;

        return (
            <div className="flex max-w-[190px] flex-wrap items-center gap-1">
                {visibleVendors.map((vendor, index) => (
                    <span
                        key={`${vendor}-${index}`}
                        className="max-w-[80px] truncate rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600"
                        title={vendor}
                    >
                        {vendor}
                    </span>
                ))}

                {remainingCount > 0 && (
                    <button
                        type="button"
                        onClick={() =>
                            handleShowVendors(quotation.vendor)
                        }
                        className="inline-flex items-center rounded-md bg-blue-50 px-1.5 py-0.5 text-[9px] font-bold text-blue-600 transition hover:bg-blue-100"
                        title="View all vendors"
                    >
                        +{remainingCount}
                    </button>
                )}
            </div>
        );
    },
},

    {
        key: "date",
        label: "Due Date",
        width: "100px",
        sortable: true,
        render: (quotation) => (
            <span className="whitespace-nowrap text-[12px] font-medium text-slate-600">
                {quotation.date}
            </span>
        ),
    },
    {
        key: "projectValue",
        label: "Project Value",
        width : "125px",
        align: "center",
        sortable: true,
        render :(quotation) => (
            <span className="whitespace-nowrap text-[11px] font-semibold text-slate-900">
                {quotation.currency}{" "}
                {formatCurrency(quotation.grandTotal)}
            </span>
        )
    },
    {
        key: "grandTotal",
        label: "Grand Total",
        width: "125px",
        align: "center",
        sortable: true,
        render: (quotation) => (
            <span className="whitespace-nowrap text-[11px] font-bold text-slate-900">
                {quotation.currency}{" "}
                {formatCurrency(quotation.grandTotal)}
            </span>
        ),
    },
    {
        key: "items",
        label: "Items",
        width: "65px",
        align: "center",
        sortable: true,
        render: (quotation) => (
            <span className="text-[12px] font-semibold text-slate-700">
                {quotation.items}
            </span>
        ),
    },
    {
        key: "status",
        label: "Status",
        width: "115px",
        align: "center",
        sortable: true,
        render: (quotation) => (
            <span
                className={`inline-flex max-w-[105px] truncate rounded-full px-2 py-1 text-[9px] font-bold ${getStatusClass(
                    quotation.status
                )}`}
                title={quotation.status}
            >
                {quotation.status}
            </span>
        ),
    },
    {
    key: "actions",
    label: "Actions",
    width: "100px",
    align: "center",
    sortable: false,
    render: (quotation) => (
        <div className="flex items-center justify-center gap-0.5 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
            <button
                type="button"
                onClick={() => handleViewQuotation(quotation)}
                title="View quotation"
                className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-blue-50 hover:text-blue-600"
            >
                <EyeIcon size={14} weight="bold" />
            </button>

         {quotation.status === "Draft" && (
            <button
                type="button"
                onClick={() => handleEditQuotation(quotation)}
                title="Edit quotation"
                className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-amber-50 hover:text-amber-600"
            >
                <PencilSimpleIcon size={14} weight="bold" />
            </button>
        )}


            <button
                type="button"
                onClick={() => {
                    console.log("Delete:", quotation);
                }}
                title="Delete quotation"
                className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-red-50 hover:text-red-600"
            >
                <TrashIcon
                    size={14}
                    weight="bold"
                />
            </button>
        </div>
    ),
},

];


    return (
        <>
            <div className="space-y-5">
                <div className="space-y-4">
                    <QuotationHeader
                        showNewQuotation={activeTab === "bids"}
                        showAddBOQ={activeTab === "boq"}
                        showBoqActions={showBoqActions}
                        onExportEstimate={onExportEstimate}
                        onGenerateQuotation={onGenerateQuotation}
                    />

                    <div className="flex w-full items-center">
                        <QuotationTabs
                            activeTab={activeTab}
                            onChange={(tab) => {
                                onTabChange?.(tab);
                                if (tab === "bids") {
                                    navigate("/quotation");
                                }
                                if (tab === "boq") {
                                    navigate("/quotation/project_boq");
                                }
                            }}
                        />
                    </div>
                </div>

                <section className="rounded-2xl shadow-sm">
                    <div className="px-0 py-4">
                        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                            Recent Quotations
                        </h3>
                        <p className="mt-1 text-[10px] text-slate-400">
                            View and manage project BOQ quotations
                        </p>
                    </div>

                    <div className="rounded-2xl p-0">
                        <DataTable
                            columns={columns}
                            data={projectBOQQuotations}
                            rowKey={(quotation) => quotation.id}
                            emptyMessage="No project BOQ quotations found."
                        />
                    </div>
                </section>
            </div>

            {/* View Quotation Drawer */}
            <ViewQuotationDrawer
                isOpen={isDrawerOpen}
                quotation={selectedQuotation}
                onClose={() => setIsDrawerOpen(false)}
                onEdit={handleEditQuotation}
                onGenerateQuotation={onGenerateQuotation}
            />

            {showVendors && (
                <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm">
                    <div className="w-full max-w-md overflow-hidden rounded-xl bg-white shadow-2xl">

                        {/* Header */}
                        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
                            <div>
                                <h3 className="text-sm font-bold text-slate-900">
                                    Vendors
                                </h3>

                                <p className="mt-0.5 text-[10px] text-slate-500">
                                    All vendors associated with this quotation
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={() => setShowVendors(false)}
                                className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                            >
                                <XIcon size={16} weight="bold" />
                            </button>
                        </div>

                        {/* Vendors */}
                        <div className="max-h-[350px] overflow-y-auto p-5">
                            <div className="space-y-2">
                                {selectedVendors.map((vendor, index) => (
                                    <div
                                        key={`${vendor}-${index}`}
                                        className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50 px-3 py-2.5"
                                    >
                                        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-blue-50 text-[11px] font-bold text-blue-600">
                                            {index + 1}
                                        </div>

                                        <span className="text-xs font-semibold text-slate-700">
                                            {vendor}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="flex justify-end border-t border-slate-200 bg-slate-50 px-5 py-3">
                            <button
                                type="button"
                                onClick={() => setShowVendors(false)}
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-[10px] font-bold text-slate-600 transition hover:bg-slate-100"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </>
    );
};

export default ProjectBOQList;
