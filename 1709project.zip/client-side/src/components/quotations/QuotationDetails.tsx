import {
    ArrowClockwiseIcon,
    ArrowLeftIcon,
    CaretDownIcon,
    CheckCircleIcon,
    ClockIcon,
    FilePdfIcon,
    FileTextIcon,
    PlusIcon,
    ShieldCheckIcon,
    StackIcon,
    TrashIcon,
    XCircleIcon,
} from "@phosphor-icons/react";

import {
    useEffect,
    useMemo,
    useState,
} from "react";

import {
    useLocation,
    useNavigate,
} from "react-router-dom";

import type { Quotation } from "../../types/quotation";

import DataTable, {
    DataTableColumn,
} from "../DataTable";

import AddMrValue from "../../offcanvas/quotation/AddMRValue";
import Field from "../Field";
import Select from "react-select";

type QuotationStatus = Quotation["status"];

type WorkflowStatus =
    | "Approved"
    | "Pending"
    | "Rejected"
    | "Revision Requested";

interface WorkflowStep {
    level: string;
    title: string;
    status: WorkflowStatus;
    person: string;
    role: string;
    comment: string;
    date: string;
}

interface BOQSection {
    id: number;
    title: string;
}

interface BOQRow {
    id: number;
    sectionId: number;
    category: string;
    module: string;
    description: string;
    qty: number;
    uom: string;
    unitPrice: number;
    materialRate?: number;
    serviceRate?: number;
    salesPrice: number;
    mrValue?: number | null;
    gct: number;
}




type DecisionType = "reject" | null;

interface QuotationDetailsProps {
    quotation?: Quotation;
    onBack?: () => void;
    onStatusChange?: (
        quotationId: Quotation["id"],
        status: Quotation["status"]
    ) => void;
}

interface PaymentInstallment {
    id: string;
    name: string;
    amount: number;
    type: "advance" | "balance";
    installmentName: string;
    modules: string[];
    days: number[];
}

const WORKFLOW_PEOPLE = [
    {
        person: "Sarah Johnson",
        role: "Senior Project Manager",
    },
];

const WORKFLOW_TITLES = [
    "Technical Review",
];

const BOQ_SECTIONS: BOQSection[] = [
    {
        id: 1,
        title: "Project Milestone",
    },
    {
        id: 2,
        title: "Material Specifications",
    },
    {
        id: 3,
        title: "Technical Services",
    },
];

type CategoryOption = {
    value: string;
    label: string;
};

const CATEGORY_OPTIONS: Record<
    number,
    CategoryOption[]
> = {
    1: [
        {
            value: "Civil Works",
            label: "Civil Works",
        },
        {
            value: "Permitting",
            label: "Permitting",
        },
        {
            value: "Logistics",
            label: "Logistics",
        },
    ],
    2: [
        {
            value: "Fiber Optics",
            label: "Fiber Optics",
        },
        {
            value: "Hardware & Active Gears",
            label: "Hardware & Active Gears",
        },
        {
            value: "Materials",
            label: "Materials",
        },
    ],
    3: [
        {
            value: "Splicing & Testing",
            label: "Splicing & Testing",
        },
        {
            value: "Engineering Services",
            label: "Engineering Services",
        },
        {
            value: "Labour",
            label: "Labour",
        },
    ],
};

const INITIAL_BOQ_ROWS: BOQRow[] = [
    {
        id: 1,
        sectionId: 1,
        category: "Civil Works",
        module: "Site Preparation",
        description:
            "Site preparation and civil works for fiber deployment",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 2,
        sectionId: 1,
        category: "Permitting",
        module: "Permits",
        description:
            "Required permits and authority approvals",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 3,
        sectionId: 1,
        category: "Logistics",
        module: "Transportation",
        description:
            "Transportation and logistics for project materials",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 4,
        sectionId: 2,
        category: "Fiber Optics",
        module: "ADSS Cable",
        description:
            "144-core aerial ADSS fiber optic cable",
        qty: 1,
        uom: "km",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 5,
        sectionId: 2,
        category: "Hardware & Active Gears",
        module: "Pole Hardware",
        description:
            "Pole hardware attachment and accessories",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 6,
        sectionId: 2,
        category: "Materials",
        module: "Splice Enclosure",
        description:
            "Mid-span fiber optic splice enclosures",
        qty: 1,
        uom: "Units",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 7,
        sectionId: 3,
        category: "Splicing & Testing",
        module: "Splicing",
        description:
            "Fiber splicing and OTDR testing activities",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 8,
        sectionId: 3,
        category: "Engineering Services",
        module: "Engineering",
        description:
            "Engineering design, survey and technical support",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
    {
        id: 9,
        sectionId: 3,
        category: "Labour",
        module: "Installation Labour",
        description:
            "Labour for fiber installation and field activities",
        qty: 1,
        uom: "Lot",
        unitPrice: 0,
        materialRate: 0,
        serviceRate: 0,
        salesPrice: 0,
        mrValue: null,
        gct: 15,
    },
];

const getCurrentDateTime = (): string => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(
        now.getMonth() + 1
    ).padStart(2, "0");
    const day = String(
        now.getDate()
    ).padStart(2, "0");
    const hours = String(
        now.getHours()
    ).padStart(2, "0");
    const minutes = String(
        now.getMinutes()
    ).padStart(2, "0");
    return `${year}-${month}-${day} ${hours}:${minutes}`;
};

const normalizeStatus = (
    status?: string
): string => {
    return (
        status
            ?.trim()
            .toLowerCase()
            .replace(/\s+/g, " ") || ""
    );
};

const formatCurrency = (
    value: number
): string => {
    const safeValue = Number.isFinite(value)
        ? value
        : 0;
    return `$${safeValue.toLocaleString(
        "en-US",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }
    )}`;
};

const getSafeNumber = (
    value: number
): number => {
    return Number.isFinite(value)
        ? value
        : 0;
};

interface BOQSectionTableProps {
    section: BOQSection;
    sectionIndex: number;
    rows: BOQRow[];
    onAddRow: (
        sectionId: number
    ) => void;
    onUpdateRow: (
        rowId: number,
        field: keyof BOQRow,
        value: string | number | null
    ) => void;
    onRemoveRow: (
        rowId: number
    ) => void;
    getSectionTotal: (
        sectionId: number
    ) => number;
}

const BOQSectionTable = ({
    section,
    sectionIndex,
    rows,
    onAddRow,
    onUpdateRow,
    onRemoveRow,
    getSectionTotal,
}: BOQSectionTableProps) => {
    const [
        isOpen,
        setIsOpen,
    ] = useState(true);

    const [
        isMasterRateDrawerOpen,
        setIsMasterRateDrawerOpen,
    ] = useState(false);

    const [
        selectedMrRow,
        setSelectedMrRow,
    ] = useState<BOQRow | null>(null);

    const [
        masterRateValue,
        setMasterRateValue,
    ] = useState("");

    const sectionRows = rows.filter(
        (row) =>
            row.sectionId ===
            section.id
    );

    const categoryOptions =
        CATEGORY_OPTIONS[
            section.id
        ] ?? [];

    const openMasterRateDrawer = (
        row: BOQRow
    ) => {
        setSelectedMrRow(row);
        setMasterRateValue(
            row.mrValue !== undefined &&
                row.mrValue !== null
                ? String(row.mrValue)
                : ""
        );
        setIsMasterRateDrawerOpen(true);
    };

    const closeMasterRateDrawer = () => {
        setIsMasterRateDrawerOpen(false);
        setSelectedMrRow(null);
        setMasterRateValue("");
    };

    const confirmMasterRateUpdate = () => {
        if (!selectedMrRow) {
            return;
        }
        const value =
            Number(masterRateValue);
        if (
            masterRateValue.trim() === "" ||
            !Number.isFinite(value) ||
            value < 0
        ) {
            return;
        }
        onUpdateRow(
            selectedMrRow.id,
            "mrValue",
            value
        );
        closeMasterRateDrawer();
    };

    const categorySelectStyles = {
        container: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            width: "100%",
        }),

        control: (
            base: Record<string, unknown>,
            state: {
                isFocused: boolean;
            }
        ) => ({
            ...base,
            minHeight: "32px",
            height: "32px",
            width: "90%",
            border: state.isFocused
                ? "1px solid #dc2626"
                : "1px solid #e2e8f0",
            borderRadius: "6px",
            boxShadow: state.isFocused
                ? "0 0 0 1px #dc2626"
                : "none",
            backgroundColor: "#ffffff",
            cursor: "pointer",
            "&:hover": {
                borderColor: "#cbd5e1",
            },
        }),

        valueContainer: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            padding: "0 8px",
            height: "30px",
        }),

        input: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            margin: 0,
            padding: 0,
            fontSize: "11px",
            color: "#334155",
        }),

        singleValue: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            margin: 0,
            fontSize: "11px",
            fontWeight: 600,
            color: "#334155",
        }),

        placeholder: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            margin: 0,
            fontSize: "11px",
            color: "#94a3b8",
        }),

        indicatorsContainer: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            height: "30px",
        }),

        dropdownIndicator: (
            base: Record<string, unknown>,
            state: {
                isFocused: boolean;
            }
        ) => ({
            ...base,
            padding: "4px",
            color: state.isFocused
                ? "#dc2626"
                : "#94a3b8",
        }),

        indicatorSeparator: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            display: "none",
        }),

        menu: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            zIndex: 99999,
            marginTop: "4px",
            border: "1px solid #e2e8f0",
            borderRadius: "6px",
            overflow: "hidden",
            boxShadow:
                "0 10px 25px rgba(15, 23, 42, 0.12)",
            backgroundColor: "#ffffff",
        }),

        menuPortal: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            zIndex: 99999,
        }),

        menuList: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            padding: "4px",
            maxHeight: "220px",
        }),

        option: (
            base: Record<string, unknown>,
            state: {
                isSelected: boolean;
                isFocused: boolean;
            }
        ) => ({
            ...base,
            fontSize: "11px",
            fontWeight: state.isSelected
                ? 600
                : 500,
            padding: "8px 10px",
            borderRadius: "4px",
            cursor: "pointer",
            backgroundColor:
                state.isSelected
                    ? "#fee2e2"
                    : state.isFocused
                        ? "#fef2f2"
                        : "#ffffff",
            color:
                state.isSelected
                    ? "#dc2626"
                    : "#334155",
            "&:active": {
                backgroundColor:
                    "#fee2e2",
            },
        }),

        noOptionsMessage: (
            base: Record<string, unknown>
        ) => ({
            ...base,
            fontSize: "11px",
            color: "#94a3b8",
            padding: "10px",
        }),
    };

const boqColumns: DataTableColumn<BOQRow>[] = [
    {
        key: "module",
        label: "Module",
        width: "15%",
        sortable: true,
        render: (row) => (
            <div className="w-full min-w-0">
                <span className="text-[11px] font-medium text-slate-800">
                    {row.module || "-"}
                </span>
            </div>
        ),
    },

    {
        key: "category",
        label: "Category",
        width: "14%",
        sortable: true,
        render: (row) => {
            const selectedCategory =
                categoryOptions.find(
                    (option) =>
                        option.value === row.category
                );

            return (
                <div className="w-full min-w-0">
                    <span className="text-[11px] font-medium text-slate-700">
                        {selectedCategory?.label ||
                            row.category ||
                            "-"}
                    </span>
                </div>
            );
        },
    },

    {
        key: "description",
        label: "Description",
        width: "25%",
        sortable: true,
        render: (row) => (
            <div className="w-full min-w-0">
                <div className="text-[11px] leading-relaxed text-slate-800">
                    {row.description || "-"}
                </div>

                <div className="mt-1.5 flex flex-wrap gap-1">
                    {row.materialRate != null && (
                        <span
                            className="
                                inline-flex
                                whitespace-nowrap
                                rounded
                                border
                                border-emerald-200
                                bg-emerald-50
                                px-1.5
                                py-0.5
                                text-[10px]
                                font-medium
                                text-emerald-600
                            "
                        >
                            Mat:{" "}
                            {formatCurrency(
                                row.materialRate
                            )}
                        </span>
                    )}

                    {row.serviceRate != null && (
                        <span
                            className="
                                inline-flex
                                whitespace-nowrap
                                rounded
                                border
                                border-sky-200
                                bg-sky-50
                                px-1.5
                                py-0.5
                                text-[10px]
                                font-medium
                                text-sky-600
                            "
                        >
                            Srv:{" "}
                            {formatCurrency(
                                row.serviceRate
                            )}
                        </span>
                    )}
                </div>
            </div>
        ),
    },

    {
        key: "qty",
        label: "Qty",
        width: "8%",
        align: "center",
        sortable: true,
        render: (row) => (
            <div className="flex w-full items-center justify-center">
                <span className="text-[11px] font-semibold text-slate-800">
                    {row.qty ?? 0}
                </span>
            </div>
        ),
    },

    {
        key: "uom",
        label: "UOM",
        width: "8%",
        sortable: true,
        render: (row) => (
            <div className="w-full min-w-0">
                <span className="text-[11px] font-medium text-slate-700">
                    {row.uom || "-"}
                </span>
            </div>
        ),
    },

    {
        key: "unitPrice",
        label: "Unit Price",
        width: "12%",
        align: "right",
        sortable: true,
        render: (row) => {
            const calculatedUnitPrice =
                (row.materialRate ?? 0) +
                (row.serviceRate ?? 0);

            const unitPrice =
                Number.isFinite(row.unitPrice)
                    ? row.unitPrice
                    : calculatedUnitPrice;

            return (
                <div className="flex w-full items-center justify-end">
                    <span className="whitespace-nowrap text-[11px] font-bold text-slate-800">
                        $
                        {Number(unitPrice).toFixed(2)}
                    </span>
                </div>
            );
        },
    },

    {
        key: "total",
        label: "Total (USD)",
        width: "10%",
        align: "right",
        sortable: false,
        render: (row) => {
            const unitPrice =
                getSafeNumber(row.unitPrice);

            const quantity =
                getSafeNumber(row.qty);

            const total =
                quantity * unitPrice;

            return (
                <div className="flex w-full items-center justify-end">
                    <span className="whitespace-nowrap text-right text-[10px] font-bold text-slate-900">
                        {formatCurrency(total)}
                    </span>
                </div>
            );
        },
    },

    {
        key: "actions",
        label: "",
        width: "4%",
        align: "center",
        sortable: false,
        render: (row) => (
            <button
                type="button"
                onClick={() =>
                    onRemoveRow(row.id)
                }
                title="Remove item"
                aria-label="Remove item"
                className="
                    flex
                    h-6
                    w-6
                    items-center
                    justify-center
                    rounded-md
                    text-slate-400
                    transition
                    hover:bg-red-50
                    hover:text-red-600
                "
            >
                <TrashIcon
                    size={13}
                    weight="duotone"
                />
            </button>
        ),
    },
];




    const sectionColors = [
        {
            number: "bg-red-600",
            icon: "text-slate-400",
        },
        {
            number: "bg-emerald-600",
            icon: "text-slate-400",
        },
        {
            number: "bg-sky-600",
            icon: "text-slate-400",
        },
    ];

    const colors =
        sectionColors[
            sectionIndex %
                sectionColors.length
        ];




    return (
        <>
            <div className="px-5 pb-7 pt-5">
                <div
                    className="flex cursor-pointer items-center justify-between border-b border-slate-200 pb-3"
                    onClick={() =>
                        setIsOpen(
                            (value) =>
                                !value
                        )
                    }
                >
                    <div className="flex min-w-0 items-center gap-3">
                        <div
                            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white ${colors.number}`}
                        >
                            {sectionIndex +
                                1}
                        </div>

                        <div className="flex min-w-0 items-center gap-2">
                            <StackIcon
                                size={15}
                                weight="duotone"
                                className={
                                    colors.icon
                                }
                            />

                            <h3 className="truncate text-[12px] font-bold uppercase tracking-tight text-slate-900">
                                {
                                    section.title
                                }
                            </h3>
                        </div>
                    </div>

                    <div className="flex shrink-0 items-center gap-5">
                        <div className="text-right">
                            <p className="text-[7px] font-bold uppercase tracking-widest text-slate-400">
                                Section Total
                            </p>

                            <p className="mt-1 text-[10px] font-bold text-slate-900">
                                {formatCurrency(
                                    getSectionTotal(
                                        section.id
                                    )
                                )}
                            </p>
                        </div>

                        <CaretDownIcon
                            size={14}
                            weight="bold"
                            className={`text-slate-400 transition-transform ${
                                isOpen
                                    ? ""
                                    : "-rotate-90"
                            }`}
                        />
                    </div>
                </div>

                {isOpen && (
                    <div className="mt-3 overflow-visible">
                        <DataTable<BOQRow>
                            columns={
                                boqColumns
                            }
                            data={
                                sectionRows
                            }
                            rowKey={(
                                row
                            ) =>
                                row.id
                            }
                            emptyMessage="No BOQ items found."
                            minWidth="1050px"
                            className="w-full"
                        />

                        <div className="flex items-center justify-between border-x border-b border-slate-200 bg-slate-50/50 px-3 py-2">
                            <p className="text-[7px] text-slate-400">
                                {
                                    sectionRows.length
                                }{" "}
                                {sectionRows.length ===
                                1
                                    ? "line item"
                                    : "line items"}
                            </p>
                        </div>
                    </div>
                )}
            </div>

            <AddMrValue
                isOpen={
                    isMasterRateDrawerOpen
                }
                onClose={
                    closeMasterRateDrawer
                }
                row={
                    selectedMrRow
                }
                value={
                    masterRateValue
                }
                onValueChange={
                    setMasterRateValue
                }
                onConfirm={
                    confirmMasterRateUpdate
                }
            />
        </>
    );
};

interface RevisionHistoryEntry {
    version: number;
    date: string;
    status: string;
    comment: string;
    performedBy: string;
}

const getDummyPaymentInstallments = (grandTotal: number): PaymentInstallment[] => {
    if (grandTotal <= 0) return [];

    return [
    {
        id: "inst-1",
        name: "Mobilization Fee",
        installmentName: "Mobilization Fee",
        amount: grandTotal * 0.15,
        type: "advance" as const,
        modules: ["mobilization"],
        days: [7],
    },
    {
        id: "inst-2",
        name: "Material Procurement",
        installmentName: "Material Procurement",
        amount: grandTotal * 0.35,
        type: "advance" as const,
        modules: ["material_supply"],
        days: [14],
    },
    {
        id: "inst-3",
        name: "Site Installation",
        installmentName: "Site Installation",
        amount: grandTotal * 0.30,
        type: "balance" as const,
        modules: ["plumbing_works"],
        days: [43],
    },
    {
        id: "inst-4",
        name: "Final Completion",
        installmentName: "Final Completion",
        amount: grandTotal * 0.20,
        type: "balance" as const,
        modules: ["final_handover"],
        days: [60],
    },
];

};

const QuotationDetails = ({
    quotation: quotationProp,
    onBack: onBackProp,
    onStatusChange,
}: QuotationDetailsProps) => {
    const location = useLocation();
    const navigate = useNavigate();

    const quotation =
        quotationProp ??
        (location.state?.quotation as
            | Quotation
            | undefined);

    const [
        currentStatus,
        setCurrentStatus,
    ] = useState<QuotationStatus | undefined>(
        quotation?.status
    );

    const [
        reviewComment,
        setReviewComment,
    ] = useState("");

    const [
        workflowComments,
        setWorkflowComments,
    ] = useState<
        Record<number, string>
    >({});

    const [
        workflowDates,
        setWorkflowDates,
    ] = useState<
        Record<number, string>
    >({});

    const [
        showDecisionModal,
        setShowDecisionModal,
    ] = useState(false);

    const [
        decisionType,
        setDecisionType,
    ] = useState<DecisionType>(null);

    const [
        boqRows,
        setBoqRows,
    ] = useState<BOQRow[]>(
        INITIAL_BOQ_ROWS
    );

    const [
        revisionHistory,
        setRevisionHistory,
    ] = useState<RevisionHistoryEntry[]>([]);

    const [paymentInstallments, setPaymentInstallments] = useState<PaymentInstallment[]>([]);

    useEffect(() => {
        if (!quotation) {
            return;
        }

        setCurrentStatus(
            quotation.status
        );

        setReviewComment("");
        setWorkflowComments({});
        setWorkflowDates({});
        setShowDecisionModal(false);
        setDecisionType(null);

        setBoqRows(
            INITIAL_BOQ_ROWS.map(
                (row) => ({
                    ...row,
                })
            )
        );

        const storedRevisions = localStorage.getItem(
            `revision_history_${quotation.id}`
        );

        if (storedRevisions) {
            try {
                setRevisionHistory(
                    JSON.parse(storedRevisions)
                );
            } catch {
                setRevisionHistory([
                    {
                        version: 1,
                        date: quotation.date || getCurrentDateTime(),
                        status: quotation.status,
                        comment: "Initial draft created",
                        performedBy: "Sarah Johnson",
                    },
                ]);
            }
        } else {
            setRevisionHistory([
                {
                    version: 1,
                    date: quotation.date || getCurrentDateTime(),
                    status: quotation.status,
                    comment: "Initial draft created",
                    performedBy: "Sarah Johnson",
                },
            ]);
        }

        const dummyInstallments = getDummyPaymentInstallments(quotation.grandTotal);
        setPaymentInstallments(dummyInstallments);
    }, [
        quotation?.id,
        quotation?.status,
        quotation?.date,
        quotation?.grandTotal,
    ]);

    const addRevisionHistoryEntry = (
        status: string,
        comment: string,
        performedBy: string = "Sarah Johnson"
    ) => {
        if (!quotation) return;

        const newEntry: RevisionHistoryEntry = {
            version: revisionHistory.length + 1,
            date: getCurrentDateTime(),
            status: status,
            comment: comment,
            performedBy: performedBy,
        };

        const updatedHistory = [
            ...revisionHistory,
            newEntry,
        ];

        setRevisionHistory(updatedHistory);

        localStorage.setItem(
            `revision_history_${quotation.id}`,
            JSON.stringify(updatedHistory)
        );
    };

const normalizedStatus = normalizeStatus(currentStatus);

const isApproved = normalizedStatus === "awarded";
const isRejected = normalizedStatus === "rejected";
const isPendingApproval = normalizedStatus === "submitted";

const approvalStatus = 
    normalizedStatus === "awarded" ? "Approved" : 
    normalizedStatus === "not responded" ? "Not responded" : 
    normalizedStatus === "draft" ? "Draft" : 
    normalizedStatus === "submitted" ? "Pending Approval" : 
    currentStatus || "";



    const workflow = useMemo<
        WorkflowStep[]
    >(() => {
        if (!quotation) {
            return [];
        }

        const baseStep = {
            level: "Level 1",
            title: WORKFLOW_TITLES[0],
            person: WORKFLOW_PEOPLE[0].person,
            role: WORKFLOW_PEOPLE[0].role,
            comment: "",
            date: quotation.date || "",
        };

       if (
        isApproved ||
        normalizedStatus === "awarded"
    ) {
            return [
                {
                    ...baseStep,
                    status: "Approved",
                    comment:
                        workflowComments[0] ||
                        "Quotation approved.",
                    date:
                        workflowDates[0] ||
                        quotation.date ||
                        "",
                },
            ];
        }

        if (isRejected) {
            return [
                {
                    ...baseStep,
                    status: "Rejected",
                    comment:
                        workflowComments[0] ||
                        `${WORKFLOW_TITLES[0]} rejected the quotation.`,
                    date:
                        workflowDates[0] ||
                        quotation.date ||
                        "",
                },
            ];
        }

        return [
            {
                ...baseStep,
                status: "Pending",
                comment: "",
                date: "",
            },
        ];
    }, [
    isApproved,
    isRejected,
    workflowComments,
    workflowDates,
    quotation,
]);

    const activeStepIndex = 0;
    const activeStep =
        workflow[0] || null;

    const quotedGrandTotal =
        getSafeNumber(
            quotation?.grandTotal ?? 0
        );

    const estimatedInternalCost =
        quotedGrandTotal *
        0.604;

    const profit =
        quotedGrandTotal -
        estimatedInternalCost;

    const margin = getSafeNumber(
        quotation?.margin ?? 0
    );

    const getSectionTotal = (
        sectionId: number
    ): number => {
        return boqRows
            .filter(
                (row) =>
                    row.sectionId ===
                    sectionId
            )
            .reduce(
                (
                    total,
                    row
                ) => {
                    const qty =
                        getSafeNumber(
                            row.qty
                        );

                    const unitPrice =
                        getSafeNumber(
                            row.unitPrice
                        );

                    return (
                        total +
                        qty *
                            unitPrice
                    );
                },
                0
            );
    };

    const milestoneTotal =
        getSectionTotal(1);

    const materialTotal =
        getSectionTotal(2);

    const serviceTotal =
        getSectionTotal(3);

    const boqSubtotal =
        milestoneTotal +
        materialTotal +
        serviceTotal;

    const gctRate = 0.15;

    const gctAmount =
        boqSubtotal *
        gctRate;

    const boqGrandTotal =
        boqSubtotal +
        gctAmount;

    const addBOQRow = (
        sectionId: number
    ) => {
        const categoryOptions =
            CATEGORY_OPTIONS[
                sectionId
            ] ?? [];

        const defaultCategory =
            categoryOptions[0]?.value ??
            "";

        const newRow: BOQRow = {
            id:
                Date.now() +
                Math.floor(
                    Math.random() *
                        1000
                ),
            sectionId,
            category:
                defaultCategory,
            module: "",
            description: "",
            qty: 1,
            uom: "Units",
            unitPrice: 0,
            materialRate: 0,
            serviceRate: 0,
            salesPrice: 0,
            mrValue: null,
            gct: 15,
        };

        setBoqRows(
            (previous) => [
                ...previous,
                newRow,
            ]
        );
    };

    const updateBOQRow = (
        rowId: number,
        field: keyof BOQRow,
        value:
            | string
            | number
            | null
    ) => {
        setBoqRows(
            (previous) =>
                previous.map(
                    (row) =>
                        row.id ===
                        rowId
                            ? {
                                ...row,
                                [field]:
                                    value,
                            }
                            : row
                )
        );
    };

    const removeBOQRow = (
        rowId: number
    ) => {
        setBoqRows(
            (previous) =>
                previous.filter(
                    (row) =>
                        row.id !==
                        rowId
                )
        );
    };

    const notifyStatusChange = (
        status: QuotationStatus
    ) => {
        if (
            onStatusChange &&
            quotation
        ) {
            onStatusChange(
                quotation.id,
                status
            );
        }
    };

const updateQuotationInStorage = (
    status: QuotationStatus,
    comment: string
) => {
    if (!quotation) {
        return;
    }

    try {
        const existingQuotations: Quotation[] =
            JSON.parse(
                localStorage.getItem(
                    "quotations"
                ) || "[]"
            );

        const updatedQuotations =
            existingQuotations.map(
                (q) => {
                    if (
                        q.id ===
                        quotation.id
                    ) {
                        return {
                            ...q,
                            status,
                        };
                    }

                    return q;
                }
            );

            localStorage.setItem(
                "quotations",
                JSON.stringify(
                    updatedQuotations
                )
            );

            addRevisionHistoryEntry(
                status,
                comment
            );
        } catch (error) {
            console.error(
                "Error updating quotation in storage:",
                error
            );
        }
    };

    const handleApprove = () => {
        if (!activeStep) {
            return;
        }

        const now =
            getCurrentDateTime();

        const comment =
            reviewComment.trim() ||
            `${activeStep.title} approved.`;

        setWorkflowComments(
            (previous) => ({
                ...previous,
                [activeStepIndex]:
                    comment,
            })
        );

        setWorkflowDates(
            (previous) => ({
                ...previous,
                [activeStepIndex]:
                    now,
            })
        );

        const finalStatus =
            "Approved" as QuotationStatus;

        setCurrentStatus(
            finalStatus
        );

        updateQuotationInStorage(
            finalStatus,
            comment
        );

        notifyStatusChange(
            finalStatus
        );

        setReviewComment("");
    };

    const openDecisionModal = (
        type: "reject"
    ) => {
        if (!activeStep) {
            return;
        }

        setDecisionType(type);
        setShowDecisionModal(true);
    };

    const closeDecisionModal =
        () => {
            setShowDecisionModal(false);
            setDecisionType(null);
        };

    const confirmDecision = () => {
        if (
            !activeStep ||
            !decisionType
        ) {
            return;
        }

        const now =
            getCurrentDateTime();

        const comment =
            reviewComment.trim();

        const rejectionComment =
            comment ||
            `${activeStep.title} rejected the quotation.`;

        setWorkflowComments(
            (previous) => ({
                ...previous,
                [activeStepIndex]:
                    rejectionComment,
            })
        );

        setWorkflowDates(
            (previous) => ({
                ...previous,
                [activeStepIndex]:
                    now,
            })
        );

        const rejectionStatus =
            "Rejected" as QuotationStatus;

        setCurrentStatus(
            rejectionStatus
        );

        updateQuotationInStorage(
            rejectionStatus,
            rejectionComment
        );

        notifyStatusChange(
            rejectionStatus
        );

        setReviewComment("");
        closeDecisionModal();
    };

    const decisionComment =
        workflowComments[0];

    const modalMessage =
        "Please provide a reason comment for rejecting this quotation.";

    const handleBack = () => {
        if (onBackProp) {
            onBackProp();
            return;
        }

        navigate("/quotation");
    };

    const remainingBalance = useMemo(() => {
        const totalPaid = paymentInstallments.reduce((sum, inst) => sum + inst.amount, 0);
        return Math.max(quotedGrandTotal - totalPaid, 0);
    }, [paymentInstallments, quotedGrandTotal]);

    if (!quotation) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-slate-50">
                <div className="rounded-xl border border-slate-200 bg-white p-6 text-center shadow-sm">
                    <h2 className="text-sm font-bold text-slate-900">
                        Quotation not found
                    </h2>

                    <p className="mt-2 text-xs text-slate-500">
                        The quotation details could not
                        be loaded.
                    </p>

                    <button
                        type="button"
                        onClick={() =>
                            navigate(
                                "/quotation"
                            )
                        }
                        className="mt-4 rounded-lg bg-red-600 px-4 py-2 text-xs font-bold text-white transition hover:bg-red-700"
                    >
                        Back to Quotations
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50">
            <div className="mb-5 rounded-xl border border-slate-200 bg-white shadow-sm">
                <div className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center lg:justify-between">
                    <div className="flex min-w-0 items-start gap-3">
                        <button
                            type="button"
                            onClick={
                                handleBack
                            }
                            title="Back to quotations"
                            aria-label="Back to quotations"
                            className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:bg-slate-50 hover:text-slate-800"
                        >
                            <ArrowLeftIcon
                                size={18}
                                weight="bold"
                            />
                        </button>

                        <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                                <h1 className="text-xl font-bold text-slate-900">
                                    {
                                        quotation.quotationNo
                                    }
                                </h1>

                              
                                <span
                                        className={`inline-flex rounded-full px-2.5 py-1 text-[10px] font-bold ${
                                            approvalStatus === "Approved"
                                                ? "bg-emerald-50 text-emerald-700"
                                                : approvalStatus === "Not responded"
                                                    ? "bg-slate-100 text-slate-600"
                                                    : approvalStatus === "Draft"
                                                        ? "bg-slate-100 text-slate-600"
                                                        : approvalStatus === "Pending Approval"
                                                            ? "bg-amber-50 text-amber-700"
                                                            : isRejected
                                                                ? "bg-red-50 text-red-700"
                                                                : "bg-amber-50 text-amber-700"
                                        }`}
                                    >
                                        {approvalStatus}
                                    </span>


                            </div>

                            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1">
                                <p className="text-sm text-slate-600">
                                    <span className="font-semibold text-slate-800">
                                        Vendor:
                                    </span>{" "}
                                    {
                                        quotation.vendorName ||
                                        quotation.vendor
                                    }
                                </p>
                            </div>
                        </div>
                    </div>

                    <button
                        type="button"
                        className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 hover:text-red-600"
                    >
                        <FilePdfIcon
                            size={17}
                            weight="duotone"
                        />
                        Preview Official PDF
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 items-start gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
                <div className="min-w-0 space-y-5">
                    {/* <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex items-center gap-2 border-b border-slate-200 px-5 py-3.5">
                            <ShieldCheckIcon
                                size={15}
                                weight="duotone"
                                className="text-red-500"
                            />

                            <h2 className="text-[11px] font-bold uppercase tracking-wide text-slate-900">
                                Approval Status
                            </h2>
                        </div>

                        <div className="p-5">
                            <div className="grid grid-cols-1 gap-3">
                                {workflow.map(
                                    (step) => {const approved = step.status === "Approved";
                                        const rejected = step.status === "Rejected";
                                        const revisionRequested = step.status === "Revision Requested";

                                        return (
                                            <div
                                                key={
                                                    step.level
                                                }
                                                className={`min-h-[134px] rounded-xl border p-4 ${
                                                    approved
                                                        ? "border-emerald-300 bg-emerald-50/40"
                                                        : rejected
                                                            ? "border-red-300 bg-red-50/40"
                                                            : revisionRequested
                                                                ? "border-amber-300 bg-amber-50/40"
                                                                : "border-slate-200 bg-slate-50"
                                                }`}
                                            >
                                                <div className="flex items-start justify-between gap-2">
                                                    <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">
                                                        {
                                                            step.level
                                                        }{" "}
                                                        :{" "}
                                                        {
                                                            step.title
                                                        }
                                                    </p>

                                                    <span
                                                        className={`inline-flex shrink-0 rounded px-3 py-0.5 text-[9px] font-bold ${
                                                            approved
                                                                ? "bg-emerald-100 text-emerald-700"
                                                                : rejected
                                                                    ? "bg-red-100 text-red-700"
                                                                    : revisionRequested
                                                                        ? "bg-amber-100 text-amber-700"
                                                                        : "bg-slate-200 text-slate-600"
                                                        }`}
                                                    >
                                                        {
                                                            step.status
                                                        }
                                                    </span>
                                                </div>

                                                <div className="mt-3 flex items-center gap-3">
                                                    <div
                                                        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                                                            approved
                                                                ? "bg-emerald-100 text-emerald-600"
                                                                : rejected
                                                                    ? "bg-red-100 text-red-600"
                                                                    : revisionRequested
                                                                        ? "bg-amber-100 text-amber-600"
                                                                        : "bg-slate-100 text-slate-400"
                                                        }`}
                                                    >
                                                        {approved ? (
                                                            <CheckCircleIcon
                                                                size={18}
                                                                weight="fill"
                                                            />
                                                        ) : rejected ? (
                                                        <XCircleIcon size={18}
                                                                weight="fill"
                                                            />
                                                        ) : revisionRequested ? (
                                                            <ArrowClockwiseIcon
                                                                size={18}
                                                                weight="bold"
                                                            />
                                                        ) : (
                                                            <ClockIcon
                                                                size={18}
                                                                weight="duotone"
                                                            />
                                                        )}
                                                    </div>

                                                    <div className="min-w-0">
                                                        <p className="truncate text-[11px] font-bold text-slate-800">
                                                            {step.person}
                                                        </p>

                                                        <p className="truncate text-[10px] text-slate-500">
                                                            {step.role}
                                                        </p>
                                                    </div>
                                                </div>

                                                {step.comment && (
                                                    <div className="mt-3 rounded border border-slate-200 bg-white px-3 py-2">
                                                        <p className="text-[10px] italic leading-relaxed text-slate-600">
                                                            "
                                                            {step.comment}
                                                            "
                                                        </p>
                                                    </div>
                                                )}

                                                {step.date && (
                                                    <p className="mt-2 text-[9px] text-slate-400">
                                                        {
                                                            step.date
                                                        }
                                                    </p>
                                                )}
                                            </div>
                                        );
                                    }
                                )}
                            </div>
                        </div>
                    </section> */}
     
                    <section className="overflow-hidden rounded-xl bg-slate-900 shadow-lg">
                        <div className="grid grid-cols-1 sm:grid-cols-3">
                            <div className="border-b border-slate-800 p-5 sm:border-b-0 sm:border-r">
                                <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">
                                    Quoted Grand Total
                                </p>

                                <p className="mt-1.5 text-lg font-bold text-red-500">
                                    {
                                        quotation.currency
                                    }{" "}
                                    {quotedGrandTotal.toLocaleString(
                                        "en-US",
                                        {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2,
                                        }
                                    )}{" "}
                                    USD
                                </p>

                                <p className="mt-1 text-[8px] text-slate-500">
                                    Includes GCT (15%)
                                </p>
                            </div>

                            <div className="border-b border-slate-800 p-5 sm:border-b-0 sm:border-r">
                                <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">
                                    Estimated Internal Cost
                                </p>

                                <p className="mt-1.5 text-lg font-bold text-white">
                                    {
                                        quotation.currency
                                    }{" "}
                                    {estimatedInternalCost.toLocaleString(
                                        "en-US",
                                        {
                                            maximumFractionDigits: 0,
                                        }
                                    )}{" "}
                                    USD
                                </p>

                                <p className="mt-1 text-[8px] text-slate-500">
                                    Direct Materials + Labor
                                </p>
                            </div>

                            <div className="p-5">
                                <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">
                                    Calculated Profit Margin
                                </p>

                                <p className="mt-1.5 text-lg font-bold text-emerald-400">
                                    {margin.toFixed(
                                        1
                                    )}
                                    %
                                </p>

                                <p className="mt-1 text-[8px] text-emerald-400">
                                    Est. Profit:{" "}
                                    {
                                        quotation.currency
                                    }{" "}
                                    {profit.toLocaleString(
                                        "en-US",
                                        {
                                            maximumFractionDigits: 0,
                                        }
                                    )}
                                </p>
                            </div>
                        </div>
                    </section>

                    <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex items-center gap-2 border-b border-slate-200 px-5 py-3.5">
                            <h2 className="text-[11px] font-bold uppercase tracking-wide text-slate-900">
                                Vendor &amp; Project Overview
                            </h2>
                        </div>

                        <div className="grid grid-cols-1 gap-x-8 gap-y-4 p-5 sm:grid-cols-2">
                            <div>
                                <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                    Project Title
                                </p>

                                <p className="mt-1 text-[10px] font-semibold text-slate-800">
                                    {
                                        quotation.projectTitle
                                    }
                                </p>
                            </div>

                            <div>
                                <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                    Vendor Account
                                </p>

                                <p className="mt-1 text-[10px] font-semibold text-slate-800">
                                    {
                                        quotation.vendorName ||
                                        quotation.vendor
                                    }
                                </p>

                                <p className="mt-0.5 text-[8px] text-slate-400">
                                    TRN:
                                    102-394-881
                                </p>
                            </div>

                            <div>
                                <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                    Project Site Location
                                </p>

                                <p className="mt-1 text-[10px] font-semibold text-slate-800">
                                    Spalding to Christiana Corridor, Manchester
                                </p>
                            </div>

                            <div className="rounded-lg bg-slate-50 px-3 py-2.5 sm:col-span-2">
                                <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                    Scope of Work
                                </p>

                                <p className="mt-1 text-[9px] leading-relaxed text-slate-700">
                                    Construction of 18.5 km 144-core aerial ADSS fiber cable, pole hardware attachment, 24 mid-span splice enclosures, and OTDR testing certification.
                                </p>
                            </div>
                        </div>
                    </section>

                    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4">
                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                <FileTextIcon
                                    size={18}
                                    weight="duotone"
                                />
                            </div>

                            <div>
                                <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                    Structured Bill of Quantities Review
                                </h2>

                                <p className="mt-1 text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                    {
                                        boqRows.length
                                    }{" "}
                                    Total Line Items
                                </p>
                            </div>
                        </div>

                        <div>
                            {BOQ_SECTIONS.map(
                                (
                                    section,
                                    sectionIndex
                                ) => (
                                    <BOQSectionTable
                                        key={section.id}
                                        section={section}
                                        sectionIndex={sectionIndex}
                                        rows={boqRows}
                                        onAddRow={addBOQRow}
                                        onUpdateRow={updateBOQRow}
                                        onRemoveRow={removeBOQRow}
                                        getSectionTotal={getSectionTotal}
                                    />
                                )
                            )}
                        </div>

                        <div className="flex justify-end border-t border-slate-200 bg-white px-5 py-6">
                            <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-slate-50/70 p-4">
                                <h3 className="text-[10px] font-bold uppercase tracking-wide text-slate-500">
                                    BOQ Value Contribution
                                </h3>

                                <div className="mt-3 space-y-2">
                                    <div className="flex items-center justify-between border-l-2 border-blue-500 pl-2">
                                        <span className="text-[10px] text-slate-600">
                                            1. Milestones:
                                        </span>

                                        <span className="text-[10px] font-semibold text-slate-700">
                                            {formatCurrency(
                                                milestoneTotal
                                            )}
                                        </span>
                                    </div>

                                    <div className="flex items-center justify-between border-l-2 border-emerald-500 pl-2">
                                        <span className="text-[10px] text-slate-600">
                                            2. Materials:
                                        </span>

                                        <span className="text-[10px] font-semibold text-slate-700">
                                            {formatCurrency(
                                                materialTotal
                                            )}
                                        </span>
                                    </div>

                                    <div className="flex items-center justify-between border-l-2 border-sky-500 pl-2">
                                        <span className="text-[10px] text-slate-600">
                                            3. Services:
                                        </span>

                                        <span className="text-[10px] font-semibold text-slate-700">
                                            {formatCurrency(
                                                serviceTotal
                                            )}
                                        </span>
                                    </div>
                                </div>

                                <div className="my-3 border-t border-slate-200" />

                                <div className="flex items-center justify-between">
                                    <span className="text-[10px] font-medium text-slate-600">
                                        Subtotal:
                                    </span>

                                    <span className="text-[10px] font-bold text-slate-800">
                                        {formatCurrency(
                                            boqSubtotal
                                        )}
                                    </span>
                                </div>

                                <div className="mt-1.5 flex items-center justify-between">
                                    <span className="text-[10px] font-medium text-slate-600">
                                        GCT (15%):
                                    </span>

                                    <span className="text-[10px] font-semibold text-slate-700">
                                        {formatCurrency(
                                            gctAmount
                                        )}
                                    </span>
                                </div>

                                <div className="mt-2 flex items-center justify-between">
                                    <span className="text-[11px] font-bold text-slate-900">
                                        Grand Total:
                                    </span>

                                    <span className="text-[11px] font-bold text-red-600">
                                        {formatCurrency(
                                            boqGrandTotal
                                        )}{" "}
                                        USD
                                    </span>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>

                <aside className="space-y-5 xl:sticky xl:top-5">
                    <section
                            className={`rounded-xl border bg-white shadow-sm ${
                                isApproved
                                    ? "border-emerald-300"
                                    : isRejected
                                        ? "border-red-300"
                                        : "border-amber-300"
                            }`}
                        >
                        {/* <div className="border-b border-slate-200 px-5 py-3.5">
                            <div className="flex items-center gap-2">
                                {isApproved ? (
                                    <CheckCircleIcon
                                        size={15}
                                        weight="fill"
                                        className="text-emerald-600"
                                    />
                                ) : isRejected ? (
                                    <XCircleIcon
                                        size={15}
                                        weight="fill"
                                        className="text-red-600"
                                    />
                                ) :  (
                                    <ClockIcon
                                        size={15}
                                        weight="duotone"
                                        className="text-amber-600"
                                    />
                                )}

                                <h2 className="text-[11px] font-bold uppercase tracking-wide text-slate-900">
                                    {isApproved
                                        ? "Workflow Status Summary"
                                        : "Reviewer Decision Box"}
                                </h2>
                            </div>

                           <p
                                className={`mt-1 text-[8px] font-bold uppercase tracking-wide ${
                                    isApproved
                                        ? "text-emerald-600"
                                        : isRejected
                                            ? "text-red-600"
                                            : "text-amber-600"
                                }`}
                            >
                                {isApproved
                                    ? "Workflow Completed"
                                    : isRejected
                                        ? "Workflow Rejected"
                                        : activeStep?.title || "Pending"}
                            </p>
                        </div> */}

                        {isApproved && (
                            <div className="p-5">
                                <div className="rounded-lg bg-emerald-50 px-3 py-3">
                                    <p className="text-[9px] font-bold uppercase tracking-wide text-emerald-700">
                                        Current Status
                                    </p>

                                    <p className="mt-1 text-sm font-bold text-emerald-800">
                                        Approved
                                    </p>
                                </div>

                                <p className="mt-4 text-[10px] leading-relaxed text-slate-600">
                                    Workflow concluded for version 1.
                                </p>

                                {/* <div className="mt-4">
                                    <p className="text-[9px] font-bold text-slate-800">
                                        Next Post-Approval Steps:
                                    </p>

                                    <div className="mt-3 space-y-2">
                                        <button
                                            type="button"
                                            className="flex w-full items-center justify-center rounded-lg border border-red-600 bg-red-600 px-3 py-2.5 text-center transition hover:bg-red-700"
                                        >
                                            <div className="flex items-center gap-2.5">
                                                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white text-[9px] font-bold text-red-600">
                                                    1
                                                </span>

                                                <span className="text-[12px] font-bold text-white">
                                                    Convert to Active Project
                                                </span>
                                            </div>
                                        </button>

                                        <button
                                            type="button"
                                            className="flex w-full items-center justify-center rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-left transition hover:border-red-200 hover:bg-red-50"
                                        >
                                            <div className="flex items-center gap-2.5">
                                                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-50 text-[9px] font-bold text-red-600">
                                                    1
                                                </span>

                                                <span className="text-[12px] font-bold text-slate-700">
                                                    Generate Contract
                                                </span>
                                            </div>
                                        </button>

                                        <button
                                            type="button"
                                            className="flex w-full items-center justify-center rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-center transition hover:border-red-200 hover:bg-red-50"
                                        >
                                            <div className="flex items-center gap-2.5">
                                                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-50 text-[9px] font-bold text-red-600">
                                                    1
                                                </span>

                                                <span className="text-[12px] font-bold text-slate-700">
                                                    Vendor Onboarding
                                                </span>
                                            </div>
                                        </button>
                                    </div>
                                </div> */}
                            </div>
                        )}

                        {isRejected && (
                            <div className="p-5">
                                <div className="rounded-lg bg-red-50 px-3 py-3">
                                    <p className="text-[9px] font-bold uppercase tracking-wide text-red-700">
                                        Current Status
                                    </p>

                                    <p className="mt-1 text-sm font-bold text-red-800">
                                        Rejected
                                    </p>
                                </div>

                                <div className="mt-4">
                                    <p className="text-[9px] font-semibold text-slate-700">
                                        Rejected Workflow Level
                                    </p>

                                    <p className="mt-1 text-[10px] font-bold text-slate-800">
                                        {activeStep?.title || "Technical Review"}
                                    </p>
                                </div>

                                {decisionComment && (
                                    <div className="mt-4 rounded-lg bg-slate-50 px-3 py-3">
                                        <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                            Reviewer Feedback
                                        </p>

                                        <p className="mt-1 text-[9px] italic leading-relaxed text-slate-600">
                                            "
                                            {
                                                decisionComment
                                            }
                                            "
                                        </p>
                                    </div>
                                )}

                                <p className="mt-3 text-[9px] leading-relaxed text-slate-500">
                                    This quotation was rejected during the{" "}
                                    <span className="font-semibold text-slate-700">
                                        {activeStep?.title || "Technical Review"}
                                    </span>{" "}
                                    stage.
                                </p>
                            </div>
                        )}

                        {isPendingApproval &&
                            activeStep && (
                                <div className="p-5">
                                    <p className="text-[10px] leading-relaxed text-slate-600">
                                        You are performing the{" "}
                                        <span className="font-bold text-slate-800">
                                            {
                                                activeStep.title
                                            }
                                        </span>{" "}
                                        for this quotation. Enter comments below before confirming.
                                    </p>

                                    <div className="mt-4 rounded-lg bg-slate-50 px-3 py-2.5">
                                        <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">
                                            Assigned Reviewer
                                        </p>

                                        <p className="mt-1 text-[10px] font-bold text-slate-800">
                                            {
                                                activeStep.person
                                            }
                                        </p>

                                        <p className="text-[9px] text-slate-500">
                                            {
                                                activeStep.role
                                            }
                                        </p>
                                    </div>

                                    <label className="mt-4 block">
                                        <span className="text-[9px] font-semibold text-slate-700">
                                            Reviewer Feedback &amp; Audit Comments
                                        </span>

                                        <textarea
                                            value={
                                                reviewComment
                                            }
                                            onChange={(
                                                event
                                            ) =>
                                                setReviewComment(
                                                    event
                                                        .target
                                                        .value
                                                )
                                            }
                                            rows={
                                                4
                                            }
                                            placeholder="Enter technical or financial approval notes..."
                                            className="mt-2 w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-[10px] text-slate-700 outline-none placeholder:text-slate-400 focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
                                        />
                                    </label>

                                    <button
                                        type="button"
                                        onClick={
                                            handleApprove
                                        }
                                        className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-[10px] font-bold text-white shadow-sm transition hover:bg-emerald-700"
                                    >
                                        <CheckCircleIcon
                                            size={14}
                                            weight="fill"
                                        />
                                        Approve &amp; Advance Workflow
                                    </button>

                                    <div className="mt-1.5">
                                        <button
                                            type="button"
                                            onClick={() =>
                                                openDecisionModal(
                                                    "reject"
                                                )
                                            }
                                            className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-red-100 px-3 py-2 text-[9px] font-bold text-red-700 transition hover:bg-red-200"
                                        >
                                            <XCircleIcon
                                                size={12}
                                            />
                                            Reject Bid
                                        </button>
                                    </div>
                                </div>
                            )}
                    </section>

                    <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                        <div className="border-b border-slate-200 px-5 py-3.5">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h2 className="text-[11px] font-bold uppercase tracking-wide text-slate-900">
                                        Payment Schedule
                                    </h2>
                                    <p className="mt-0.5 text-[9px] text-slate-500">
                                        Payment installments for this quotation
                                    </p>
                                </div>
                                <span className="text-[8px] font-medium text-slate-400">
                                    {paymentInstallments.length} Installments
                                </span>
                            </div>
                        </div>

                       <div className="p-4">
                        {paymentInstallments.length > 0 ? (
                            <div className="space-y-2.5">
                                {paymentInstallments.map((installment, index) => (
                                    <div
                                        key={installment.id}
                                        className="rounded-lg border border-slate-200 bg-slate-50 p-3"
                                    >
                                        <div className="flex items-center justify-between gap-3">
                                            <div className="min-w-0">
                                                <p className="text-[10px] font-bold text-slate-700">
                                                    Payment Schedule {index + 1}
                                                </p>

                                                <p className="mt-0.5 text-[8px] text-slate-400">
                                                    1 Installment • Saved 09/09/2026, 18:42:40
                                                </p>
                                            </div>

                                            {/* <button
                                                type="button"
                                                className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-[9px] font-semibold text-slate-600 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                                            >
                                                Edit
                                            </button> */}
                                        </div>

                                        <div className="mt-3">
                                            <div className="rounded-md border border-slate-200 bg-white px-3 py-2">
                                                <div className="flex items-center justify-between gap-3">
                                                    <div className="min-w-0">
                                                        <p className="text-[9px] font-semibold text-slate-700">
                                                            {index + 1}.{" "}
                                                            {installment.installmentName}
                                                        </p>

                                                        <p className="mt-0.5 text-[8px] text-slate-400">
                                                            {installment.modules.join(", ")}
                                                        </p>
                                                    </div>

                                                    <div className="shrink-0 text-right">
                                                        <p className="text-[9px] font-bold text-slate-700">
                                                            {quotation.currency}{" "}
                                                            {installment.amount.toFixed(2)}
                                                        </p>

                                                        <p className="text-[8px] text-slate-400">
                                                            {installment.days[0]} Days
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 text-center">
                                <p className="text-[9px] text-slate-400">
                                    No payment schedule configured
                                </p>
                            </div>
                        )}
                    </div>

                    </section>

                    <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                        <div className="border-b border-slate-200 px-5 py-3.5">
                            <h2 className="text-[11px] font-bold uppercase tracking-wide text-slate-900">
                                Revision History
                            </h2>
                        </div>

                        <div className="p-5">
                            {revisionHistory.length > 0 ? (
                                <div className="space-y-3">
                                    {revisionHistory.map((entry, index) => (
                                        <div
                                            key={index}
                                            className={`rounded-lg border p-3 ${
                                                index === 0
                                                    ? "border-emerald-200 bg-emerald-50/40"
                                                    : "border-slate-200 bg-slate-50"
                                            }`}
                                        >
                                            <div className="flex items-start justify-between gap-3">
                                                <div>
                                                    <div className="flex items-center gap-2 flex-wrap">
                                                        <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-red-600 text-[8px] font-bold text-white">
                                                            {entry.version}
                                                        </span>
                                                        <p className="text-[10px] font-bold text-slate-800">
                                                            Version {entry.version}
                                                        </p>
                                                        <span
                                                            className={`inline-flex rounded-full px-2 py-0.5 text-[8px] font-bold ${
                                                                entry.status === "Approved"
                                                                    ? "bg-emerald-100 text-emerald-700"
                                                                    : entry.status === "Rejected"
                                                                    ? "bg-red-100 text-red-700"
                                                                    : entry.status === "Revision Requested"
                                                                    ? "bg-amber-100 text-amber-700"
                                                                    : entry.status === "Pending Approval"
                                                                    ? "bg-amber-50 text-amber-700"
                                                                    : "bg-slate-100 text-slate-600"
                                                            }`}
                                                        >
                                                            {entry.status}
                                                        </span>
                                                        {index === 0 && (
                                                            <span className="inline-flex rounded-full bg-red-100 px-2 py-0.5 text-[8px] font-bold text-red-600">
                                                                Latest
                                                            </span>
                                                        )}
                                                    </div>
                                                    <p className="mt-1 text-[9px] leading-relaxed text-slate-600">
                                                        {entry.comment}
                                                    </p>
                                                    <p className="mt-1 text-[8px] text-slate-400">
                                                        {entry.performedBy} • {entry.date}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="rounded-lg bg-slate-50 px-3 py-3">
                                    <div className="flex items-start justify-between gap-3">
                                        <div>
                                            <p className="text-[9px] font-bold text-slate-800">
                                                Version 1
                                            </p>
                                            <p className="mt-1 text-[9px] leading-relaxed text-slate-500">
                                                Initial draft created from survey findings and BOQ engineering template.
                                            </p>
                                        </div>
                                    </div>
                                    <p className="mt-2 text-[8px] text-slate-400">
                                        Sarah Johnson • {quotation.date}
                                    </p>
                                </div>
                            )}
                        </div>
                    </section>
                </aside>
            </div>

            {showDecisionModal &&
                decisionType && (
                    <div
                        className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-[2px]"
                        onMouseDown={(
                            event
                        ) => {
                            if (
                                event.target ===
                                event.currentTarget
                            ) {
                                closeDecisionModal();
                            }
                        }}
                    >
                        <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white shadow-2xl">
                            <div className="p-5">
                                <div
                                    className="flex h-10 w-10 items-center justify-center rounded-full bg-red-50 text-red-600"
                                >
                                    <XCircleIcon
                                        size={20}
                                        weight="fill"
                                    />
                                </div>

                                <h3 className="mt-4 text-sm font-bold text-slate-900">
                                    Reject Bid
                                </h3>

                                <p className="mt-2 text-[11px] leading-relaxed text-slate-600">
                                    {modalMessage}
                                </p>

                                <label className="mt-4 block">
                                    <span className="text-[9px] font-semibold text-slate-700">
                                        Comment
                                    </span>

                                    <textarea
                                        value={
                                            reviewComment
                                        }
                                        onChange={(
                                            event
                                        ) =>
                                            setReviewComment(
                                                event
                                                    .target
                                                    .value
                                            )
                                        }
                                        rows={
                                            4
                                        }
                                        placeholder="Enter the rejection reason..."
                                        className="mt-2 w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-[10px] text-slate-700 outline-none placeholder:text-slate-400 focus:border-slate-400 focus:bg-white focus:ring-2 focus:ring-slate-100"
                                    />
                                </label>

                                <div className="mt-5 flex gap-2">
                                    <button
                                        type="button"
                                        onClick={
                                            closeDecisionModal
                                        }
                                        className="flex-1 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-[10px] font-bold text-slate-600 transition hover:bg-slate-50"
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        type="button"
                                        onClick={
                                            confirmDecision
                                        }
                                        className="flex-1 rounded-lg px-4 py-2.5 text-[10px] font-bold text-white transition bg-red-600 hover:bg-red-700"
                                    >
                                        Confirm Rejection
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
        </div>
    );
};

export default QuotationDetails;