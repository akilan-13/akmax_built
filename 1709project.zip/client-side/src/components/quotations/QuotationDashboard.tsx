import {
    CheckCircleIcon,
    CurrencyDollarSimpleIcon,
    FileTextIcon,
    ClockIcon,
} from "@phosphor-icons/react";

import StatCard from "../../components/StatCard";

interface QuotationDashboardProps {
    total: number;
    pending: number;
    approved: number;
    approvedValue: number;
}

const QuotationDashboard = ({
    total,
    pending,
    approved,
    approvedValue,
}: QuotationDashboardProps) => {
    return (
        <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">

            <StatCard
                label="Total Bids & Quotes"
                value={total}
                icon={FileTextIcon}
                tone="red"
            />

            <StatCard
                label="Pending Review"
                value={pending}
                icon={ClockIcon}
                tone="amber"
            />

            <StatCard
                label="Approved Bids"
                value={approved}
                icon={CheckCircleIcon}
                tone="green"
            />

            <StatCard
                label="Approved Value"
                value={`$${approvedValue.toLocaleString()}`}
                icon={CurrencyDollarSimpleIcon}
                tone="blue"
            />

        </div>
    );
};

export default QuotationDashboard;
