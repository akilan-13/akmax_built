import { TeamMember } from "../types/user";

export const MOCK_MEMBERS: TeamMember[] = [
  {
      id: "u1",
      name: "Sarah Johnson",
      email: "sarah.j@projectflow.com",
      role: "Super Admin",
      department: "Operations",
      location: "Regional Operations HQ",
      privileges: [
          "View Dashboard",
          "Manage Projects",
          "Manage Vendors",
          "Manage Quotations",
          "Manage Invoices",
          "Manage Users",
          "Approve Quotations",
          "View Financials",
          "Edit Settings",
      ],
      status: "Active",
      password: "",
      hourlyrate: "$ 35"
  },
  {
      id: "u2",
      name: "Michael Chen",
      email: "m.chen@projectflow.com",
      role: "Project Manager",
      department: "Engineering",
      location: "Regional Operations HQ",
      privileges: [
          "View Dashboard",
          "Manage Projects",
          "Manage Vendors",
          "Manage Quotations",
          "Manage Invoices",
          "View Financials",
      ],
      status: "Active",
      password: "",
      hourlyrate: "$ 30"
  },
  {
      id: "u3",
      name: "Jessica Williams",
      email: "j.williams@projectflow.com",
      role: "Project Manager",
      department: "Creative",
      location: "Downtown Studio",
      privileges: ["View Dashboard", "Manage Projects", "Manage Vendors"],
      status: "Active",
      password: "",
      hourlyrate: "$ 30"
  },
  {
      id: "u4",
      name: "David Miller",
      email: "d.miller@projectflow.com",
      role: "Project Manager",
      department: "Engineering",
      location: "Remote",
      privileges: ["View Dashboard"],
      status: "Inactive",
      password: "",
      hourlyrate: "$ 30"
  },
];
