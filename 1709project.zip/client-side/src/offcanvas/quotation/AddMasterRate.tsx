import React from "react";

interface AddMasterRateRow {
    description: string;
    category: string;
    uom: string;
}

interface AddMasterRateProps {
    row: AddMasterRateRow;
    proposedMasterRate: string;
    onProposedMasterRateChange: (
        value: string
    ) => void;
    onCancel: () => void;
    onConfirm: () => void;
}

const AddMasterRate = ({
    row,
    proposedMasterRate,
    onProposedMasterRateChange,
    onCancel,
    onConfirm,
}: AddMasterRateProps) => {
    return (
        <div className="flex h-full flex-col">
            <div className="space-y-5">

                {/* DESCRIPTION */}
                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Description
                    </label>

                    <textarea
                        value={row.description}
                        readOnly
                        rows={4}
                        className="w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm leading-relaxed text-slate-700 outline-none"
                    />
                </div>

                {/* CATEGORY */}
                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Category
                    </label>

                    <input
                        type="text"
                        value={row.category}
                        readOnly
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-700 outline-none"
                    />
                </div>

                {/* UOM */}
                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Unit (UOM)
                    </label>

                    <input
                        type="text"
                        value={row.uom}
                        readOnly
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-700 outline-none"
                    />
                </div>

                {/* PROPOSED MASTER RATE */}
                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Proposed Master Rate (USD)
                    </label>

                    <div className="relative">
                        <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-700">
                            $
                        </span>

                        <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={proposedMasterRate}
                            onChange={(event) =>
                                onProposedMasterRateChange(
                                    event.target.value
                                )
                            }
                            className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-8 pr-3.5 text-sm font-semibold text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
                        />
                    </div>

                    <p className="mt-2 text-[10px] leading-relaxed text-slate-400">
                        * This rate will be added to the corporate
                        Master Rate Schedule and used as a benchmark
                        for future quotations.
                    </p>
                </div>
            </div>

            {/* FOOTER */}
            <div className="mt-auto flex gap-2 border-t border-slate-200 pt-5">
                <button
                    type="button"
                    onClick={onCancel}
                    className="flex-1 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-bold text-slate-600 transition hover:bg-slate-50"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    onClick={onConfirm}
                    className="flex-1 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-red-700"
                >
                    Confirm &amp; Update
                </button>
            </div>
        </div>
    );
};

export default AddMasterRate;
