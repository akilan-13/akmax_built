import { useEffect, useMemo, useState } from "react";
import Select, {
  SingleValue,
} from "react-select";
import Field from "../../components/Field";
import Button from "../../components/Button";
import { getSelectStyles } from "../../utils/selectStyles";
import {
  EyeIcon,
  EyeSlashIcon,
  WarningCircleIcon,
} from "@phosphor-icons/react";
import api, {
  getApiErrorMessage,
} from "../../api/axios";
import {
  TeamMember,
  UserRole,
} from "../../types/user";

interface AddMemberFormProps {
  member?: TeamMember | null;
  onSubmit: (member: TeamMember) => void;
  onCancel: () => void;
}

interface ApiRole {
  id?: string;
  _id?: string;
  key?: string;
  code?: string;
  name?: string;
  userType?: string;
  realm?: string;
  status?: string;
  active?: boolean;
  isSystem?: boolean;
  system?: boolean;
}

interface RolesResponse {
  data?: ApiRole[];
}

interface RoleOption {
  value: string;
  label: string;
  id: string;
}

const EMPTY_FORM = {
  name: "",
  email: "",
  password: "",
  role: "",
  status: "Active" as const,
  hourlyrate: "",
};

function getRoleId(role: ApiRole): string {
  return String(
    role.id ||
      role._id ||
      "",
  );
}

function getRoleName(role: ApiRole): string {
  return String(
    role.name ||
      role.key ||
      role.code ||
      "",
  ).trim();
}

function isUsableRole(
  role: ApiRole,
): boolean {
  const roleStatus =
    String(
      role.status ||
        "",
    ).toLowerCase();

  const roleType =
    String(
      role.userType ||
        role.realm ||
        "",
    ).toLowerCase();

  return (
    Boolean(
      getRoleId(role) &&
        getRoleName(role),
    ) &&
    role.active !== false &&
    roleStatus !== "inactive" &&
    (!roleType ||
      roleType === "admin" ||
      roleType === "internal")
  );
}

function isValidEmail(
  value: string,
): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    value.trim(),
  );
}

export default function AddMemberForm({
  member,
  onSubmit,
  onCancel,
}: AddMemberFormProps) {
  const isEditMode =
    Boolean(member);

  const [name, setName] =
    useState(
      member?.name || "",
    );

  const [hourlyrate, setHourlyRate] =
    useState(
      member?.hourlyrate || "",
    );

  const [showPassword, setShowPassword] =
    useState(false);

  const [email, setEmail] =
    useState(
      member?.email || "",
    );

  const [password, setPassword] =
    useState("");

  const [role, setRole] =
    useState<string>(
      member?.role || "",
    );

  const [status, setStatus] =
    useState<
      "Active" | "Inactive"
    >(
      member?.status ||
        "Active",
    );

  const [roles, setRoles] =
    useState<
      RoleOption[]
    >([]);

  const [loadingRoles, setLoadingRoles] =
    useState(true);

  const [rolesError, setRolesError] =
    useState("");

  const [validationError, setValidationError] =
    useState("");

  useEffect(() => {
    let cancelled = false;

    const loadRoles =
      async () => {
        setLoadingRoles(true);
        setRolesError("");

        try {
          const response =
            await api.get<RolesResponse>(
              "/settings/roles",
            );

          const apiRoles =
            Array.isArray(
              response.data?.data,
            )
              ? response.data.data
              : [];

          const options =
            apiRoles
              .filter(
                isUsableRole,
              )
              .map(
                (item) => ({
                  id: getRoleId(
                    item,
                  ),
                  value: getRoleName(
                    item,
                  ),
                  label: getRoleName(
                    item,
                  ),
                }),
              )
              .sort(
                (a, b) =>
                  a.label.localeCompare(
                    b.label,
                  ),
              );

          if (
            !cancelled
          ) {
            setRoles(
              options,
            );

            setRole(
              (
                current,
              ) => {
                if (
                  current &&
                  options.some(
                    (
                      option,
                    ) =>
                      option.value ===
                      current,
                  )
                ) {
                  return current;
                }

                if (
                  member?.role &&
                  options.some(
                    (
                      option,
                    ) =>
                      option.value ===
                      member.role,
                  )
                ) {
                  return member.role;
                }

                return (
                  options[0]
                    ?.value ||
                  ""
                );
              },
            );
          }
        } catch (error) {
          if (
            !cancelled
          ) {
            setRolesError(
              getApiErrorMessage(
                error,
                "Unable to load available roles.",
              ),
            );
          }
        } finally {
          if (
            !cancelled
          ) {
            setLoadingRoles(
              false,
            );
          }
        }
      };

    void loadRoles();

    return () => {
      cancelled = true;
    };
  }, [member?.role]);

  useEffect(() => {
    setName(
      member?.name || "",
    );
    setHourlyRate(
      member?.hourlyrate ||
        "",
    );
    setEmail(
      member?.email || "",
    );
    setPassword("");
    setRole(
      member?.role || "",
    );
    setStatus(
      member?.status ||
        "Active",
    );
    setShowPassword(false);
    setValidationError("");
  }, [member]);

  const selectedRole =
    useMemo(
      () =>
        roles.find(
          (
            option,
          ) =>
            option.value ===
            role,
        ) || null,
      [
        roles,
        role,
      ],
    );

  const handleRoleChange =
    (
      option: SingleValue<RoleOption>,
    ) => {
      setRole(
        option?.value ||
          "",
      );
      setValidationError("");
    };

  const handleSubmit = (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();
    setValidationError("");

    const trimmedName =
      name.trim();

    const trimmedEmail =
      email.trim();

    const trimmedPassword =
      password.trim();

    if (
      !trimmedName
    ) {
      setValidationError(
        "Full name is required.",
      );
      return;
    }

    if (
      !isValidEmail(
        trimmedEmail,
      )
    ) {
      setValidationError(
        "Enter a valid email address.",
      );
      return;
    }

    if (!role) {
      setValidationError(
        "Please select an active role.",
      );
      return;
    }

    if (
      !isEditMode &&
      !trimmedPassword
    ) {
      setValidationError(
        "Password is required when creating a user.",
      );
      return;
    }

    if (
      trimmedPassword &&
      trimmedPassword.length <
        8
    ) {
      setValidationError(
        "Password must contain at least 8 characters.",
      );
      return;
    }

    const updatedMember: TeamMember =
      {
        id:
          member?.id ?? "",
        name:
          trimmedName,
        email:
          trimmedEmail,
        password:
          trimmedPassword,
        role:
          role as UserRole,
        status,
        hourlyrate:
          hourlyrate.trim(),
        department:
          member?.department ||
          "",
        location:
          member?.location ||
          "",
        privileges:
          member?.privileges ||
          [],
      };

    onSubmit(
      updatedMember,
    );
  };

  const hasNoRoles =
    !loadingRoles &&
    roles.length === 0 &&
    !rolesError;

  return (
    <form
      onSubmit={
        handleSubmit
      }
      className="flex h-full flex-col"
      noValidate
    >
      <div className="flex-1 space-y-5 overflow-y-auto pr-1">
        {validationError && (
          <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-semibold text-red-700">
            <WarningCircleIcon
              size={16}
              className="mt-0.5 shrink-0"
            />
            <span>
              {
                validationError
              }
            </span>
          </div>
        )}

        {rolesError && (
          <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-semibold text-red-700">
            <WarningCircleIcon
              size={16}
              className="mt-0.5 shrink-0"
            />
            <span>
              {rolesError}
            </span>
          </div>
        )}

        {hasNoRoles && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs font-semibold text-amber-700">
            No active internal/admin roles are currently available. Create or activate a role from Roles &amp; Permissions first.
          </div>
        )}

        <Field
          label="Full Name"
          type="text"
          value={name}
          onChange={(
            event,
          ) =>
            setName(
              event.target.value,
            )
          }
          placeholder="e.g. Priya Nair"
          required
        />

        <Field
          label="Email Address"
          type="email"
          value={email}
          onChange={(
            event,
          ) =>
            setEmail(
              event.target.value,
            )
          }
          placeholder="name@projectflow.com"
          required
          disabled={
            false
          }
        />

        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            {isEditMode
              ? "Password"
              : "Default Password"}
          </label>

          <div className="relative">
            <Field
              label=""
              type={
                showPassword
                  ? "text"
                  : "password"
              }
              value={
                password
              }
              onChange={(
                event,
              ) =>
                setPassword(
                  event.target
                    .value,
                )
              }
              placeholder={
                isEditMode
                  ? "Leave blank to keep current password"
                  : "Enter default password"
              }
              autoComplete={
                isEditMode
                  ? "new-password"
                  : "new-password"
              }
            />

            <button
              type="button"
              onClick={() =>
                setShowPassword(
                  (
                    previous,
                  ) =>
                    !previous,
                )
              }
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition-colors hover:text-slate-600"
              aria-label={
                showPassword
                  ? "Hide password"
                  : "Show password"
              }
            >
              {showPassword ? (
                <EyeSlashIcon
                  size={18}
                />
              ) : (
                <EyeIcon
                  size={18}
                />
              )}
            </button>
          </div>

          {isEditMode && (
            <p className="mt-1.5 text-[11px] text-slate-400">
              Leave blank to keep the current password.
            </p>
          )}
        </div>

        <Field
          label="Hourly Rate"
          type="text"
          value={hourlyrate}
          onChange={(
            event,
          ) =>
            setHourlyRate(
              event.target.value,
            )
          }
          placeholder="e.g. $ 25"
        />

        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Role
          </label>

          <Select<RoleOption>
            options={
              roles
            }
            value={
              selectedRole
            }
            onChange={
              handleRoleChange
            }
            isLoading={
              loadingRoles
            }
            isDisabled={
              loadingRoles ||
              roles.length ===
                0
            }
            isSearchable
            isClearable
            placeholder={
              loadingRoles
                ? "Loading roles..."
                : "Select a role..."
            }
            noOptionsMessage={() =>
              "No active roles available"
            }
            className="text-sm"
            styles={
              getSelectStyles()
            }
            menuPortalTarget={
              typeof document !==
              "undefined"
                ? document.body
                : undefined
            }
            menuPosition="fixed"
          />
        </div>

        <div>
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Status
          </label>

          <div className="flex gap-2 rounded-lg border border-slate-200 bg-slate-50 p-1">
            {(
              [
                "Active",
                "Inactive",
              ] as const
            ).map(
              (item) => (
                <button
                  key={
                    item
                  }
                  type="button"
                  onClick={() =>
                    setStatus(
                      item,
                    )
                  }
                  className={`flex-1 rounded-md py-1.5 text-xs font-bold uppercase transition-colors ${
                    status ===
                    item
                      ? "bg-white text-red-600 shadow-sm"
                      : "text-slate-400 hover:text-slate-600"
                  }`}
                >
                  {item}
                </button>
              ),
            )}
          </div>
        </div>
      </div>

      <div className="mt-6 flex gap-3 border-t border-slate-100 pt-5">
        <Button
          type="button"
          variant="outline"
          onClick={
            onCancel
          }
          className="flex-1"
        >
          Cancel
        </Button>

        <Button
          type="submit"
          variant="primary"
          className="flex-1"
          disabled={
            loadingRoles ||
            roles.length ===
              0
          }
        >
          {isEditMode
            ? "Update Member"
            : "Add Member"}
        </Button>
      </div>
    </form>
  );
}
https://chatgpt.com/share/6aab114b-d95c-83ee-af7b-096f8cbfbabb