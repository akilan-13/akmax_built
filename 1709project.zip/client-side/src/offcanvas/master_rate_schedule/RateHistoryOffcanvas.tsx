import OffCanvas from "../../components/OffCanvas";
import { RateItem } from "../../types/rateSchedule";
import { fmtJmd } from "../../data/seedRateSchedule";

interface RateHistoryOffCanvasProps {
    row: RateItem | null;
    onClose: () => void;
}

export default function RateHistoryOffCanvas({ row, onClose }: RateHistoryOffCanvasProps) {
    return (
        <OffCanvas
            isOpen={!!row}
            onClose={onClose}
            title="Rate History"
            subtitle={row ? `${row.code} · ${row.description}` : ""}
        >
            {row && (
                <div className="space-y-3">
                    {row.history.map((h, i) => (
                        <div key={i} className="rounded-xl border border-slate-100 bg-slate-50/60 p-4">
                            <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-900">{fmtJmd(h.rate)}</span>
                                {i === 0 && (
                                    <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-black uppercase tracking-wide text-red-600">
                                        Current
                                    </span>
                                )}
                            </div>
                            <div className="mt-1.5 flex items-center justify-between text-xs text-slate-400">
                                <span>Effective {h.effectiveDate}</span>
                                <span>
                                    Logged {h.updatedAt} {h.updatedBy ? `· ${h.updatedBy}` : ""}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </OffCanvas>
    );
}