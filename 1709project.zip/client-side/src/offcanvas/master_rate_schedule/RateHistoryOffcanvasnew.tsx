import OffCanvas from "../../components/OffCanvas";
import {
    RateItem,
} from "../../types/rateSchedule";
import {
    fmtJmd,
} from "../../data/seedRateSchedule";

interface RateHistoryItem {
    rate: number;
    effectiveDate: string;
    updatedAt: string;
    updatedBy?: string;
}

interface RateHistoryOffCanvasProps {
    row:
        | (RateItem & {
              history?: RateHistoryItem[];
          })
        | null;

    onClose: () => void;
}

function formatLoggedAt(
    value: string,
): string {
    if (!value) {
        return "";
    }

    const parsed =
        new Date(value);

    if (
        Number.isNaN(
            parsed.getTime(),
        )
    ) {
        return value;
    }

    return parsed.toLocaleString(
        undefined,
        {
            year: "numeric",
            month: "short",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
        },
    );
}

function normalizeHistory(
    row:
        | (RateItem & {
              history?: RateHistoryItem[];
          })
        | null,
): RateHistoryItem[] {
    if (!row) {
        return [];
    }

    if (
        !Array.isArray(
            row.history,
        )
    ) {
        return [];
    }

    return [...row.history].sort(
        (a, b) => {
            const dateA =
                new Date(
                    a.effectiveDate,
                ).getTime();

            const dateB =
                new Date(
                    b.effectiveDate,
                ).getTime();

            if (
                Number.isFinite(
                    dateA,
                ) &&
                Number.isFinite(
                    dateB,
                ) &&
                dateA !== dateB
            ) {
                return (
                    dateB -
                    dateA
                );
            }

            const loggedA =
                new Date(
                    a.updatedAt,
                ).getTime();

            const loggedB =
                new Date(
                    b.updatedAt,
                ).getTime();

            if (
                Number.isFinite(
                    loggedA,
                ) &&
                Number.isFinite(
                    loggedB,
                )
            ) {
                return (
                    loggedB -
                    loggedA
                );
            }

            return 0;
        },
    );
}

export default function RateHistoryOffCanvas({
    row,
    onClose,
}: RateHistoryOffCanvasProps) {
    const history =
        normalizeHistory(
            row,
        );

    return (
        <OffCanvas
            isOpen={!!row}
            onClose={onClose}
            title="Rate History"
            subtitle={
                row
                    ? `${row.code} · ${row.description}`
                    : ""
            }
        >
            {row && (
                <div className="space-y-3">
                    {history.length >
                    0 ? (
                        history.map(
                            (
                                item,
                                index,
                            ) => (
                                <div
                                    key={`${item.effectiveDate}-${item.updatedAt}-${index}`}
                                    className="rounded-xl border border-slate-100 bg-slate-50/60 p-4"
                                >
                                    <div className="flex items-center justify-between gap-3">
                                        <span className="font-bold text-slate-900">
                                            {fmtJmd(
                                                item.rate,
                                            )}
                                        </span>

                                        {index ===
                                            0 && (
                                            <span className="shrink-0 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-black uppercase tracking-wide text-red-600">
                                                Current
                                            </span>
                                        )}
                                    </div>

                                    <div className="mt-1.5 flex flex-col gap-1 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
                                        <span>
                                            Effective{" "}
                                            {
                                                item.effectiveDate
                                            }
                                        </span>

                                        <span>
                                            Logged{" "}
                                            {formatLoggedAt(
                                                item.updatedAt,
                                            )}

                                            {item.updatedBy ? (
                                                <>
                                                    {" "}
                                                    ·{" "}
                                                    {
                                                        item.updatedBy
                                                    }
                                                </>
                                            ) : null}
                                        </span>
                                    </div>
                                </div>
                            ),
                        )
                    ) : (
                        <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center">
                            <p className="text-sm font-semibold text-slate-600">
                                No rate
                                history
                                available.
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Historical
                                entries
                                will
                                appear
                                here after
                                the rate
                                is created
                                or
                                changed.
                            </p>
                        </div>
                    )}
                </div>
            )}
        </OffCanvas>
    );
}