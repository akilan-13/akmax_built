@extends('layouts/layoutMaster')

@section('title', 'Interview Staging')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
    .emoji-box {
        background: #fff;
        border: 1.5px solid #e2e5ea;
        border-radius: 12px;
        padding: 18px 10px;
        text-align: center;
        cursor: pointer;
        transition: all 0.25s ease;
        width: 130px;
        height: 150px;
    }

</style>

<!-- Lead List Table -->
<div class="card card-action mb-3">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Interview Staging</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Recruitment
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="card p-4" style="box-shadow: none;">
    @if(isset($jobRequest))
    @foreach($jobRequest as $request)
        @if($request->job_request_count>0)
        @php
            $logoPath = $request->entity_logo ? '/Entity_logos/'.$request->company_id.'/'.$request->entity_logo : '/assets/common/logo_small.png';
        @endphp
        <div class="accordian mb-2">
            <div class="accordion-item mb-3 rounded p-4">
                <h2 class="accordion-header d-flex align-items-center justify-content-between gap-6" id="headingOne">
                    <button type="button" class="accordion-button collapsed"
                        data-bs-toggle="collapse" data-bs-target="#accordionOne" aria-expanded="false"
                        aria-controls="accordionOne">
                        <div class="d-flex align-items-center justify-content-start gap-2">
                            <img src="{{ asset($logoPath) }}" alt="" class="w-10 h-10 bg-gray-300 px-2 py-2 rounded">
                            <label class="text-black fs-6 fw-semibold">{{$request->entity_name}}</label>
                        </div>
                    </button>
                    <span class="badge py-2 bg-label-danger text-primary rounded-pill fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Roles">{{$request->job_request_count}}</span>
                </h2>
                <div id="accordionOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        <div class="row g-1 p-2 px-2">
                            @foreach($request->job_request_list as $list)
                            <div class="col-lg-12 mb-2 border border-gray-200 bg-gray-100 rounded p-2">
                                <div class="d-flex align-items-center justify-content-between gap-5 mb-4 flex-wrap">
                                    <div class="d-flex align-items-center justify-content-start gap-2">
                                        <label class="fs-4 text-black fw-semibold">{{$list->job_role_name}}</label>
                                        <span class="badge bg-label-success text-success fs-8 fw-semibold">
                                            Active
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-start gap-2">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                <img src="{{ asset('assets/egc_images/auth/user_6.png') }}"
                                                    alt="user-avatar"  class="w-40px h-40px rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-start justify-content-start gap-0 flex-column">
                                            <span class="text-dark fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Created By">Madhavi S</span>
                                            <span class="d-block text-danger fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Created Date">18-Dec-2025</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-start gap-2 flex-wrap">
                                    <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">{{$list->applicant_count}}</span>
                                            <div class="fw-semibold fs-7 text-dark">Candidates</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100">100%</div>
                                        </div>
                                    </div>
                                    <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">{{$list->shortlist_count}}</span>
                                            <div class="fw-semibold fs-7 text-dark">Shortlisted</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                                        </div>
                                    </div>
                                    <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">00</span>
                                            <div class="fw-semibold fs-7 text-dark">Preliminary Interview</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100">0%</div>
                                        </div>
                                    </div>
                                    <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">05</span>
                                            <div class="fw-semibold fs-7 text-dark">Technical Interview</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100">0%</div>
                                        </div>
                                    </div>
                                    <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">00</span>
                                            <div class="fw-semibold fs-7 text-dark">Confirmation Interview</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100">0%</div>
                                        </div>
                                    </div>
                                    <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">00</span>
                                            <div class="fw-semibold fs-7 text-dark">Final Agreement</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100">0%</div>
                                        </div>
                                    </div>
                                        <div class="emoji-box d-flex align-items-center justify-content-center flex-column gap-3" data-value="5">
                                        <div class="d-flex align-items-center justify-content-center flex-column">
                                            <span class="fs-4 fw-semibold text-black">00</span>
                                            <div class="fw-semibold fs-7 text-dark">Hired</div>
                                        </div>
                                        <div class="progress bg-lighter w-80px rounded">
                                            <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="0">0%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    @endforeach
    @else
    <div class="text-light text-center">No Request Found</div>
    @endif
    
</div>


@endsection
