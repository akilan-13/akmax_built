@extends('layouts/layoutMaster')

@section('title', 'Resource Request')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection


@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .tagify__dropdown {
        z-index: 999999 !important;
    }
    .tagify__dropdown__wrapper {
        z-index: 999999 !important;
    }

     #aiBtn.ai-loading {
        opacity: 0.7;
        pointer-events: none;
    }
     #aiBtnEdit.ai-loading {
        opacity: 0.7;
        pointer-events: none;
    }

    .count_badge {
        /* top: 0; */
        position: absolute;
        right: -18px;
        bottom: 10%;
    }

   
</style>

    

<!-- Lead List Table -->
 @php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<div class="card">
     <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Resource Request</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Recruitment
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a>
        </div>
    </div>
    <a href="#" id="downloadPng" aria-label="Download as PNG" class="max-md:mb-4! max-md:mt-8! group flex-none max-md:order-last" aria-label="Hugging Face">
    </a>
    <div class="card-body">
        <div class="branch_filter mb-4" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Job Role</label>
                    <input type="text" class="form-control" id="job_role_fill" name="job_role_fill"  placeholder="Enter Job Role" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Experience</label>
                    <select id="exp_type_filt" name="exp_type_filt" class="select3 form-select">
                        <option value="">All</option>
                        <option value="2">Fresher</option>
                        <option value="3">Experience</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Closing Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="closing_date_filt" name="closing_date_filt" placeholder="Select Date" class="form-control common_datepicker" value="" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <button type="button" class="btn btn-sm btn-primary fw-semibold fs-6 me-2" class="filterSubmit" id="filterSubmit">Go</button>
                <a href="{{ url('/hr_recruitment/job_request') }}" class="btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Job Role Name..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold text-primary"  ></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold text-primary" ></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                    <thead>
                        <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">Job Role</th>
                            <th class="min-w-100px">Company / Entity</th>
                            <th class="min-w-100px">Vacancy</th>
                            <th class="min-w-150px">Closing Date </th>
                            <th class="min-w-100px">Salary</th>
                            <th class="min-w-100px">Status</th>
                            <th class="min-w-80px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                        <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                               <div class="skeleton"></div>
                            </td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Create Campaign-->
<div class="modal fade" id="kt_modal_create_job_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Create Job Request</h3>
                </div>
                <form id="jobRequestform" method="POST" action="{{ route('add_job_request') }}" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="job_role_name" name="job_role_name" placeholder="Enter Job Role Name" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                        <div class="text-danger" id="job_role_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Experience Type<span class="text-danger">*</span></label>
                        <select id="exp_type" name="exp_type[]" class="select3 form-select" multiple data-placeholder="Select Type">
                            <option value="">Select Type</option>
                            <option value="1">Fresher</option>
                            <option value="2">Experience</option>
                        </select>
                         <div class="text-danger" id="exp_type_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Years of Experience<span class="text-danger">*</span></label>
                        <input type="text" id="experience_year" name="experience_year" class="form-control" placeholder="Enter Years of Experience"  value="0" maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="experience_year_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">No Of Vacancy<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="vacancy_count" name="vacancy_count" placeholder="Enter No Of Vacancy" value="" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="vacancy_count_err"></div>
                    </div>
                    <div class="col-lg-4 mb-2" id="">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Closing Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="closing_date" name="closing_date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" readonly/>
                        </div>
                        <div class="text-danger" id="closing_date_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Minimum Salary</label>
                        <input type="text" id="min_salary" name="min_salary" class="form-control" placeholder="Enter Minimum Salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="min_salary_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Maximum Salary</label>
                        <input type="text" id="max_salary" name="max_salary" class="form-control" placeholder="Enter Maximum Salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="max_salary_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Skills Required<span class="text-danger">*</span></label>
                        <div class="form-floating form-floating-outline">
                            <input id="skill_KnowledgeTag" name="skill_KnowledgeTag" class="form-control h-auto" placeholder="Select Skills Required" value="">
                            
                        </div>
                        <div class="text-danger" id="skill_KnowledgeTag_err"></div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex justify-content-between">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Job Description<span class="text-danger">*</span></label>
                            <button type="button" id="aiBtn" 
                                class="btn btn-sm btn-light-primary border rounded-pill px-3 fw-bold shadow-sm"
                                onclick="generateAiDescription()">
                                <span class="d-flex justify-content-center align-items-center gap-1">
                                    <i class="mdi mdi-robot-outline"></i>
                                    <span>AI</span>
                                </span>
                                
                            </button>
                        </div>
                        <input type="hidden" name="job_description_generate" id="edit_text">
                        <div class="col-lg-12 mb-3" id="show_text_edit">
                            <div id="create_job_description"
                                    class="scroll-y max-h-300px border-top-none p-3 bg-white"></div>
                                <div class="error_msg text-danger fw-semibold mt-2 fs-7"></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4 mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="submitRequsetBtn" class="btn btn-primary" onclick="validation_func()">
                        <span id="yesBtnText">Create Job Request</span>
                        <span id="yesBtnLoader" style="display: none;" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    </button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Campaign-->

<!--begin::Modal - Update Job Request-->
<div class="modal fade" id="kt_modal_update_job_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Update Job Request</h3>
                </div>
                <form id="UpdateJobRequestform" method="POST" action="{{ route('update_job_request') }}" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="row mt-4">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="job_role_name_edit" name="job_role_name" placeholder="Enter Job Role Name" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                        <div class="text-danger" id="job_role_name_edit_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Experience Type<span class="text-danger">*</span></label>
                        <select id="exp_type_edit" name="exp_type[]" class="select3 form-select" multiple data-placeholder="Select Type">
                            <option value="">Select Type</option>
                            <option value="1">Fresher</option>
                            <option value="2">Experience</option>
                        </select>
                         <div class="text-danger" id="exp_type_edit_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Years of Experience<span class="text-danger">*</span></label>
                        <input type="text" id="experience_year_edit" name="experience_year" class="form-control" placeholder="Enter Years of Experience"  value="0" maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="experience_year_edit_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">No Of Vacancy<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="vacancy_count_edit" name="vacancy_count" placeholder="Enter No Of Vacancy" value="" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="vacancy_count_edit_err"></div>
                    </div>
                    <div class="col-lg-4 mb-2" id="">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Closing Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="closing_date_edit" name="closing_date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" readonly/>
                        </div>
                        <div class="text-danger" id="closing_date_edit_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Minimum Salary</label>
                        <input type="text" id="min_salary_edit" name="min_salary" class="form-control" placeholder="Enter Minimum Salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="min_salary_edit_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Maximum Salary</label>
                        <input type="text" id="max_salary_edit" name="max_salary" class="form-control" placeholder="Enter Maximum Salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="max_salary_edit_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Skills Required<span class="text-danger">*</span></label>
                        <div class="form-floating form-floating-outline">
                            <input id="skill_KnowledgeTag_edit" name="skill_KnowledgeTag" class="form-control h-auto" placeholder="Select Skills Required" value="">
                            
                        </div>
                        <div class="text-danger" id="skill_KnowledgeTag_edit_err"></div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex justify-content-between">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Job Description<span class="text-danger">*</span></label>
                            <button type="button" id="aiBtnEdit" 
                                class="btn btn-sm btn-light-primary border rounded-pill px-3 fw-bold shadow-sm"
                                onclick="generateAiDescriptionEdit()">
                                <span class="d-flex justify-content-center align-items-center gap-1">
                                    <i class="mdi mdi-robot-outline"></i>
                                    <span>AI</span>
                                </span>
                                
                            </button>
                        </div>
                        <input type="hidden" name="job_description_generate" id="job_description_edit_text">
                        <div class="col-lg-12 mb-3" id="job_description_show_text_edit">
                            <div id="create_job_description_edit"
                                    class="scroll-y max-h-300px border-top-none p-3 bg-white"></div>
                                <div class="error_msg text-danger fw-semibold mt-2 fs-7"></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4 mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="submitRequsetBtnEdit" class="btn btn-primary" onclick="validation_func_edit()">
                        <span id="yesBtnTextEdit">Update Job Request</span>
                        <span id="yesBtnLoaderEdit" style="display: none;" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    </button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Job Request-->

<!--begin::Modal - Delete Campaign-->
<div class=" modal fade" id="kt_modal_delete_job_request" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">React Developer </b> Job Request ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Campaign-->

<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                    <label class="fs-6 fw-semibold text-black">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#contact_info" aria-controls="contact_info" aria-selected="false">
                                    Contact Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#work_info" aria-controls="work_info" aria-selected="false">
                                    Work Type
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_info" aria-controls="edu_info" aria-selected="false">
                                    Education Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Application" aria-controls="Application" aria-selected="false">
                                    Application Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#StaffCheckList" aria-controls="StaffCheckList" aria-selected="false">
                                    Staff Checklist
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Orientation" aria-controls="Orientation" aria-selected="false">
                                    Orientation
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602@gmail.com</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Birth</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">09-Jan-2001</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Gender</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Male</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Saravanen</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Bank Manager</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Nila</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Tongue</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Tamil</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Languages Known</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Tamil , English</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Married</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Children</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes, Studying 5th Grade</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Siblings</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">No</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Hobby</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Drawing , Shooting ,Story Writing </label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-px-150 h-auto rounded-circle"
                                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                  <div class="row">

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Company Details</div>
                                    </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Details</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>


                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Operation</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>

                                  <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Designation Details</div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Nick</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-Oct-2025</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 20,000</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                     <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 100</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Leadership , Management , Postive</label>
                                    </div>
                                  </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Login Credentials</div>
                                    </div>


                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                    </div>
                                    </div>
                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                    </div>
                                    </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Other Credentials</div>
                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">Teams Credentials</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                      </div>

                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">Firewall Credentials</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                      </div>

                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">Firewall Credentials</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                      </div>

                                    </div>


                                  </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sibi Kumar</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile Number</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">7485196785</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Residential Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">18I Gandhi Nagar Happy Street Madurai</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Permanent Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">122K K K Nagar D-block Madurai</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">7584967821</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number 1</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">7721869435</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number 2</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9978428965</label>
                                      </div>
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Experience</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Shifted Company Count</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">2</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Total Years Of Experience</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                           <span class="badge bg-primary text-white px-3 fs-7">3</span>
                                        </label>
                                      </div>
                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">1st Company</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-primary text-white px-3 fs-7">1</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">TCS</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 20,000 /-</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">01-Oct-2021</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">18-Jul-2022</label>
                                      </div>
                                    </div>



                                    <h5 class="title fw-bold mt-2 text-warning">2nd Company</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-primary text-white px-3 fs-7">2</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">CTS</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 15,000 /-</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">27-Nov-2023</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">12-Feb-2024</label>
                                      </div>
                                    </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Attachment Details</div>
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_info" role="tabpanel">
                            <div class="row mb-2">

                              <div class="col-lg-12">
                                  <div class="row mb-2">
                                        <label class="col-3 fw-semibold fs-7 text-dark">Course Completed</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes, Java , Python , C++ , C# , HTML , JS , CSS , REACT , SQL and Ruby</label>
                                    </div>
                                </div>


                                <div class="divider text-start-center">
                                  <div class="divider-text fs-5 text-primary fw-semibold my-2">Educational Details</div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning text-warning">UG</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Under Graduate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                           <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">BBA</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">MKU</label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">PG</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Post Graduate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 ">
                                           <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">MBA</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance And Application</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">SRM</label>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="Application" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Technical Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Java , C# , .Net ,FullStack</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Non Technical Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sales Management , SEO Analyst</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Interview Attended Company</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-label-primary text-primary fw-semibold fs-6 rounded">EIBS</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Already Attended Interview In Elysium Groups</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Attended Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-10-2024 , 04-11-2024 , 12-01-2025</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Submit Original Certificate</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Travel For Official Purpose</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Joining Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Immediate Joining</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Joining Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-10-2025</label>
                                      </div>
                                    </div>


                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="StaffCheckList" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check1">
                                        <label class="fw-semibold fs-6 text-black" for="check1">Educational certificates verified (Degree, Diploma, Transcripts), experience/resume checked (previous employment verification)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check2" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check2">Identity proof verified (Aadhaar, Passport, Driving License), address proof verified (Ration Card, Utility Bill),</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check3" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check3">Official documents submitted (Joining Letter, Form 16)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check4"checked>
                                        <label class="fw-semibold fs-6 text-black" for="check4">and alternate contact/emergency details provided (alternate mobile number, emergency contact).</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check5">
                                        <label class="fw-semibold fs-6 text-black" for="check5">Verify identity proof, address proof, and educational certificates.</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check6">
                                        <label class="fw-semibold fs-6 text-black" for="check6">Check previous experience/resume, submission of official documents, and provide alternate/emergency contact details.</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Orientation" role="tabpanel">
                            <div class="row mb-2">
                                <h5 class="title fw-bold mt-2 text-warning">Staff Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Company Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>

                                  <h5 class="title fw-bold mt-2 text-warning">Department Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->


<div class="modal fade" id="kt_modal_qr_generate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-black mb-4">Generate Application QR</h3>
          <div id="qrcode" class="d-flex justify-content-center align-items-center" title="">
            <canvas width="256" height="256" style="display: none;"></canvas>
            <img id="qrImage" src="{{ asset('assets/egc_images/qr_code.png') }}" style="display:block;" class="p-2">
          </div>

          <div class="mb-1">
            <label class="text-black fs-6 fw-semibold me-3" id="download_qr_code_name"></label>
            <a href="javascript:;" 
            class="cpy-btn btn btn-sm btn-label-primary px-2 py-1" 
            data-target="download_qr_code_name"
            onclick="copyText(this)">
                <i class="mdi mdi-content-copy fs-4 text-black"></i>
            </a>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>

<!--begin::Modal - Approve Job Posting-->
<div class=" modal fade" id="kt_modal_approve_job" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-check text-success" style="font-size: 35px;"></i>
                </div>
            </div>
           <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to Start the Resource <br>
                <span class="text-success fw-bold" id="update_status_name">Content Writer </span>
                 Job Posting ?</span>
            </div>
            <div class="row px-8">
                <div class="col-12" id="">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Last Apply Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="last_apply_date" name="last_apply_date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y', strtotime('+7 days'));?>" />
                    </div>
                </div>
            </div>
            <input type="hidden" id="update_status_id">
            <input type="hidden" id="update_status">
          
            <div class="d-flex justify-content-center align-items-center py-8 mb-4">
                <button type="submit" class="btn btn-success me-3" onclick ="updateStatus()">Yes,Start!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Approve Job Posting-->

<!--begin::Modal - Reject Job Posting-->
<div class=" modal fade" id="kt_modal_reject_job" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-xmark text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to Hold the Resource <br>
                <span class="text-danger" id="update_status_onhold_name">Content Writer </span> Job Posting ?</span>
                
            </div>
            <div class="d-flex justify-content-center align-items-center py-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,Hold!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Reject Job Posting-->


    <div class="modal fade" id="kt_modal_shortlist_candidate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">   
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">Shortlisted Candidates 
                            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Job Role</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="shortlist_job_role_name">-</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Vacancy Count</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="shortlist_vacancy_count">00</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Entity</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="shortlist_company_name">-</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Applied Count</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="shortlist_applied_count">00</label>
                            </div>
                           
                        </div>
                        <input type="hidden" id="shortlist_job_request_id" >
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 std_list_page" id="studs_table_event_attendance">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                            <th class="w-200px"><input type="checkbox" id="checkAll" class="form-check-input border-white me-1" checked/>Applicant</th>
                                            <th class="min-w-100px">Mobile No</th>
                                            <th class="min-w-100px">Email ID</th>
                                            <!-- <th class="w-150px  "> Shortlist </th> -->
                                            <th class="min-w-100px">Ai Summary</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7" style="scrollbar-width: thin; max-height:400px; overflow-y:auto;" id="shortlist_candidate_tbody">
                                        <tr>
                                            <td colspan="5" class="text-center"> No Data Available </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end my-1">
                            <button type="button" id="updateShortlistBtn" class="btn btn-primary">Update Shortlist</button>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>

<style>
  /* Customize Toastr container */
  .toast {
      background-color: #39484f;
  }

  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: red;
  }

</style>
<script>
  // Display Toastr messages
      @if (Session::has('toastr'))
          var type = "{{ Session::get('toastr')['type'] }}";
          var message = "{{ Session::get('toastr')['message'] }}";
          toastr[type](message);
      @endif
</script>

<script>
    $('#branch_filter').click(function() {
        $('.branch_filter').slideToggle('slow');
    });
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#lead_week_st_dt_fill').val(firstday);
            $('#lead_week_ed_dt_fill').val(lastday);

        }
        // else if (dt_fill_issue_rpt == "week") {
        //     today_dt_iss_rpt.style.display = "none";
        //     week_from_dt_iss_rpt.style.display = "block";
        //     week_to_dt_iss_rpt.style.display = "block";
        //     monthly_dt_iss_rpt.style.display = "none";
        //     from_dt_iss_rpt.style.display = "none";
        //     to_dt_iss_rpt.style.display = "none";

        //     var curr = new Date; // get current date
        //     var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
        //     var last = first + 6; // last day is the first day + 6

        //     var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
        //     firstday = firstday.split("-").reverse().join("-");
        //     var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
        //     lastday = lastday.split("-").reverse().join("-");
        //     $('#week_from_date_fil').val(firstday);
        //     $('#week_to_date_fil').val(lastday);

        // } 
        else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function safeJsonParse(str) {
        try { return JSON.parse(str); }
        catch(e) { return str; }
    }

        var pusher = new Pusher('9996b96e908059a0d53f', {
            cluster: 'ap2',
            encrypted: true
        });

        var channel = pusher.subscribe('jobrequests');

        channel.bind('JobRequestEvent', function(e) {
            console.log('Pusher Event:', e);

            const id = e.sno || e.id;
            if (!id) return;

            const tableBody = document.getElementById('list-table-body');

            // Remove "No Data Found" row if exists
            const noDataRow = tableBody.querySelector('.no-data-found');
            if (noDataRow) noDataRow.remove();

            let row = document.getElementById('webhook-' + id);

            if (row) {
                // -----------------------------
                // UPDATE EXISTING ROW
                // -----------------------------

                // Column 1 → Job Role
                row.querySelector('td:nth-child(1) label').innerText = e.job_role_name ?? '-';

                // Column 2 → Company Name + Entity Name
                const companyBlock = row.querySelector('td:nth-child(2)');
                companyBlock.querySelector('label:nth-child(1)').innerText = e.company_name ?? "-";
                companyBlock.querySelector('label:nth-child(2)').innerText = e.entity_name ?? "-";

                // Column 3 → Location (STATIC: always Madurai)
                row.querySelector('td:nth-child(3) label').innerText = "Madurai";

                // Column 4 → Vacancy
                row.querySelector('td:nth-child(4) label').innerText = e.vacancy_count ?? '00';

                // Column 5 → Closing Date
                row.querySelector('td:nth-child(5) label').innerText =
                    e.closing_date ? formatDate(e.closing_date) : '-';

                // Column 6 → Salary
                row.querySelector('td:nth-child(6) span.fs-7').innerText =
                    `${e.min_salary ?? 0} - ${e.max_salary ?? 0}`;

                // Column 7 → Status
                let statusCol = row.querySelector('td:nth-child(7)');
                statusCol.innerHTML = getStatusBadge(e.status,e);

            } else {
                // -----------------------------
                // INSERT NEW ROW
                // -----------------------------
                tableBody.insertAdjacentHTML("afterbegin", buildRow(e, 1));
            }
        });


        // Helper: Status Badge Renderer  -------------------------
        function getStatusBadge(status,e) {
            if (status == 0) {
                return `
                    <span class="badge border border-warning rounded bg-white text-black fw-semibold fs-7" data-bs-toggle="dropdown">
                        Waiting For Resource Start
                    </span>
                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_job"onclick="updatelevelStatus('${e.job_role_name}','${e.sno}',1)">Resource Start</a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_reject_job"onclick="updatelevelStatus('${e.job_role_name}','${e.sno}',3)">On Hold</a>
                    </div>
                    
                `;
            }else if (status == 1) {
                return `<span class="badge rounded bg-success text-white fs-7 fw-semibold position-relative">Resource Started
                
                </span>`;
                
            }
            else if (status == 3) {
                return `<span class="badge rounded bg-danger text-white fs-7 fw-semibold position-relative">On Hold </span>`;
            }
            else if (status == 4) {
                return `<span class="badge rounded bg-info text-black fs-7 fw-semibold position-relative">Shortlisted</span>`;
            }
            else if (status == 5) {
                return `<span class="badge rounded bg-warning text-black fs-7 fw-semibold position-relative">Processing</span>`;
            }
             else if (status == 6) {
                return `<span class="badge rounded bg-success text-white fs-7 fw-semibold position-relative">Completed</span>`;
            }
            else{
                return `
                <span class="badge border border-warning rounded bg-white text-black fw-semibold fs-7" data-bs-toggle="dropdown">
                        Waiting For Approval
                    </span>
                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_job"onclick="updatelevelStatus('${e.job_role_name}','${e.sno}',1)">Resource Start</a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_reject_job"onclick="updatelevelStatus('${e.job_role_name}','${e.sno}',3)">On Hold</a>
                    </div>
                `;
            }
           
        }
   
    function buildRow(item,index) {    
        let skillsJson = safeJsonParse(item.skill_required); 
        let skillsArray = safeJsonParse(skillsJson);  
        let skillNames = Array.isArray(skillsArray)
            ? skillsArray.map(s => s.value)
            : [];

        let displaySkills = skillNames.join(", ");

            let exp_types = JSON.parse(item.exp_type_ids);   
            let exp_years = item.experience;   
            let labels = {
                "1": "Fresher",
                "2": "Experienced"
            };
            let displayList = exp_types.map(type => {
                if (type == "2") {
                    return `${labels[type]} (${exp_years} Years)`;
                }
                return labels[type];
            });
            let displayText = displayList.join(", ");
           
            var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
            let statuBadge = '';
            let status = item.status;
            if (status == 0) {
                statuBadge= `
                    <span class="badge border border-warning rounded bg-white text-black fw-semibold fs-7" data-bs-toggle="dropdown">
                        Waiting For Resource Start
                    </span>
                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_job"onclick="updatelevelStatus('${item.job_role_name}','${item.sno}',1)">Resource Start</a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_reject_job"onclick="updatelevelStatus('${item.job_role_name}','${item.sno}',3)">On Hold</a>
                    </div>
                    
                `;
            }else if (status == 1) {
                statuBadge=  item.applicants_count > 0 ? 
                `<a href="javascript:;" class="position-relative" data-bs-toggle="dropdown">
                    <span class="badge rounded bg-success text-white fs-7 fw-semibold">Resource Started
                        <span class="badge bg-danger badge-pill position-absolute count_badge translate-middle animate__animated animate__pulse animate__infinite rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Applied Counts">
                        ${item.applicants_count > 0 ? item.applicants_count : ''}
                        </span>
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_shortlist_candidate"onclick="candidateList('${item.job_role_name}','${item.vacancy_count}','${item.entity_name}','${item.applicants_count}','${item.sno}','${item.short_encrypt_id}')">Shortlist</a>
                </div>
                ` 
                :
                `<a href="javascript:;" class="position-relative">
                    <span class="badge rounded bg-success text-white fs-7 fw-semibold">Resource Started</span>
                </a>`;
                
            }
            else if (status == 3) {
                statuBadge= `<span class="badge rounded bg-danger text-white fs-7 fw-semibold position-relative">On Hold </span>`;
            }
            else if (status == 4) {
                statuBadge=`<span class="badge rounded bg-info text-black fs-7 fw-semibold position-relative">Shortlisted</span>`;
            }
            else if (status == 5) {
                statuBadge= `<span class="badge rounded bg-warning text-black fs-7 fw-semibold position-relative">Processing</span>`;
            }
             else if (status == 6) {
                statuBadge=`<span class="badge rounded bg-success text-white fs-7 fw-semibold position-relative">Completed</span>`;
            }
            else{
               statuBadge=`
                <span class="badge border border-warning rounded bg-white text-black fw-semibold fs-7" data-bs-toggle="dropdown">
                        Waiting For Approval
                    </span>
                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_job"onclick="updatelevelStatus('${item.job_role_name}','${item.sno}',1)">Resource Start</a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_reject_job"onclick="updatelevelStatus('${item.job_role_name}','${item.sno}',3)">On Hold</a>
                    </div>
                `;
            }
            
        return `
            <tr id="webhook-${item.sno}">
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <label class="fs-7 fw-semibold text-black">${item.job_role_name}</label>
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${item.company_name}">
                            ${item.company_name}
                        </label>

                        <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${item.entity_name}">
                            ${item.entity_name}
                        </label>
                    </div>
                </td>
                <td class="text-center">
                    <label class="fw-semibold text-center text-white fs-7 rounded-circle py-2 badge bg-google-plus">${item.vacancy_count >=10 ? item.vacancy_count :'0'+item.vacancy_count}</label>
                </td>
                <td>
                    <label class="fs-7 text-black fw-semibold d-flex align-items-center justify-content-start gap-1 text-nowrap">
                        <span><i class="mdi mdi-calendar"></i></span>
                        ${item.closing_date ? formatDate(item.closing_date) : '-'}
                    </label>
                    <label class="fs-7 d-block text-danger fw-semibold d-flex align-items-center justify-content-start gap-1 text-nowrap " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Last Apply Date">
                        <span><i class="mdi mdi-calendar"></i></span>
                        ${item.last_apply_date ? formatDate(item.last_apply_date) : '-'}
                    </label>

                </td>

                <td>
                    <label class="badge bg-warning text-black fw-bold mb-2">
                        <span class="mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                        <span class="fs-7">${item.min_salary} - ${item.max_salary}</span>
                    </label>
                </td>
               
                <td class ="position-relative">
                    ${statuBadge}
                    
                </td>
                <td>
                    ${
                        item.status == 4?
                        ` <a href="/hr_recruitment/interview_schedule/${item.short_encrypt_id}" class="btn btn-icon btn-sm" id="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Interview Schedule">
                            <i class="mdi mdi-account-clock-outline fs-3 text-black"></i>
                        </a>`
                        :
                        ``
                    }
                    <span class="text-end">
                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                            <a href="{{ url('/apply_job/${item.short_encrypt_id}') }}" class="dropdown-item" >
                                <span> <i class="mdi mdi-briefcase-check-outline fs-3 text-black me-1"></i>Job Application</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_qr_generate" class="generate-qr-btn" onclick="generateQr('${item.sno}', '${item.job_role_name}')">
                                <span> <i class="mdi mdi-qrcode-scan fs-3 text-black me-1"></i>QR Download</span>
                            </a>
                            
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const closing_date_filt = document.getElementById('closing_date_filt').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const exp_type_filt = document.getElementById('exp_type_filt').value;

        const url = `/hr_recruitment/job_request?page=${page}&sorting_filter=${perpage}&search_filter=${search}&closing_date_filt=${closing_date_filt}&exp_type_filt=${exp_type_filt}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
             <tr class="no-data-found">
                <td colspan="6" class="text-center">No Data Found</td>
            </tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

    <script>
       
        $(document).ready(function () {
            $('.common_datepicker').datepicker({
                todayHighlight: true,
                autoclose: true,
                format: 'dd-M-yyyy'
            });
        });
     
    </script>

    <!-- status Change -->
 <script>
  function updatelevelStatus(name,Id, isChecked) {
    console.log(name)
        $('#update_status_name').text(name)
        $('#update_status_onhold_name').text(name)
        $('#update_status_id').val(Id)
        $('#update_status').val(isChecked)
    }
    function updateStatus() {
         var Id = $('#update_status_id').val()
         const status =$('#update_status').val()
         const last_apply_date =$('#last_apply_date').val()
        // const status = isChecked ? 0 : 1;
        fetch(`/job_request_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status,
                    last_apply_date: last_apply_date,
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                       window.location.href = '/hr_recruitment/job_request';
                }
            })
            .catch(error => {});
    }

    
</script>

<script>
    function EditModal(id){
        $('#edit_id').val(id);
        fetch(`/job_request_edit/${id}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const job = data.data;
                    $('#job_role_name_edit').val(job.job_role_name);
                    $('#vacancy_count_edit').val(job.vacancy_count);
                    $('#experience_year_edit').val(job.experience);
                    $('#min_salary_edit').val(job.min_salary);
                    $('#max_salary_edit').val(job.max_salary);
                    if (job.closing_date) {
                        $('#closing_date_edit').val(formatDate(job.closing_date));
                    }
                    let expTypes = JSON.parse(job.exp_type_ids);
                    $('#exp_type_edit').val(expTypes).trigger('change'); 
                    let skillRaw = job.skill_required;
                    let skill1 = safeJsonParse(skillRaw);
                    let skill2 = safeJsonParse(skill1);      // second decode

                let skillsText = "";

                if (Array.isArray(skill2)) {
                    skillsText = skill2.map(s => s.value).join(", "); 
                }
                    $('#skill_KnowledgeTag_edit').val(skill1);

                    
                    $('#job_description_edit_text').val(job.job_description);


                } else {
                    console.error('Error fetching Job Request:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching Job Request:', error);
            });
    }
</script>

<script>
  function generateQr(id, event_name) {
    if (id) {
      console.log("Working");
      fetch(`/gen_job_qr/${id}/generate-qr`)
        .then(res => res.json())
        .then(data => {
          if (data.status === 200) {
            const qrImage = document.getElementById('qrImage');
            qrImage.src = data.qr_base64;
            qrImage.style.display = "block";

            document.querySelector('#download_qr_code_name').textContent = data.link;

            setTimeout(() => {
              if (data.qr_base64) {
                const dataUrl = data.qr_base64 || "";
                const link = document.createElement("a");
                link.href = dataUrl;
                link.download = `${event_name}-qr-code.png`;
                link.click();
              }
            }, 500);
          } else {
            console.error("QR generation failed");
          }
        })
        .catch(err => console.error(err));
    }
  }

    function copyText(element) {
       
    }

    document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.cpy-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const text = document.getElementById(targetId).textContent;
             console.log(text)
            // Copy text to clipboard
            navigator.clipboard.writeText(text).then(() => {
                // ✅ Optional: show toast/alert
                toastr.success('Copied: ' + text);
            }).catch(err => {
                console.error('Failed to copy text: ', err);
            });
        });
    });
});

</script>

<script>
    function candidateList(role_name,vacancy_count,entity_name,applied_count,request_id,encrypt_id) {

        $('#shortlist_job_request_id').val(request_id);
        $("#shortlist_job_role_name").text(role_name || '-');
        $('#shortlist_vacancy_count').text(vacancy_count || '0');
        $('#shortlist_applied_count').text(applied_count || '0');
        $('#shortlist_company_name').text(entity_name || '-');
        $('#updateShortlistBtn').prop('disabled', true);

        $.ajax({
            url: '/applicant_list_by_job_request/',
            type: 'GET',
            data: { request_id: encrypt_id },
            success: function (response) {

                let tbody = $('#studs_table_event_attendance tbody');
                tbody.empty();

                if (response.status === 200 && response.data.length > 0) {

                    $('#updateShortlistBtn').prop('disabled', false);

                    response.data.forEach((student, index) => {

                        /* AI Match Score */
                        let matchScore = parseInt(student.match_score || 0);
                        let rowClass = '';
                        let defaultCheck = '';

                        if (matchScore >= 80) rowClass = 'table-success';
                        else if (matchScore >= 60) rowClass = 'table-info';
                        else if (matchScore >= 40) rowClass = 'table-warning';
                        else rowClass = '';

                        if (matchScore >= 80) defaultCheck = 'checked';
                        else if (matchScore >= 60) defaultCheck = 'checked';
                        else if (matchScore >= 40) defaultCheck = '';
                        else defaultCheck = '';

                        /* AI Summary */
                        let aiSummary = student.ai_summary
                            ? student.ai_summary
                            : 'AI analysis not available';

                        let row = `
                            <tr class="${rowClass}">
                                <td>
                                    <div class="d-flex gap-2 align-items-center">
                                        <div>
                                            <input class="form-check-input"
                                                type="checkbox"
                                            ${defaultCheck}
                                                name="shortlist_check_${student.sno}"
                                                id="shortlist_check_${student.sno}"
                                                value="1">
                                        </div>
                                        <div>
                                            <div class="fw-semibold">${student.applicant_name}</div>
                                            <small class="text-muted">Match: ${matchScore}%</small>
                                            <div>
                                            ${defaultCheck == 'checked' ? 
                                            `<label class="form-check-label text-success shortlistcheckbox-label">
                                                Eligible
                                            </label>`
                                            :
                                            ` <label class="form-check-label text-danger shortlistcheckbox-label">
                                                Not Eligible
                                            </label>
                                            `
                                            }  
                                            </div> 
                                        </div>
                                    </div>
                                </td>

                                <td>${student.mobile || '-'}</td>

                                <td class="text-truncate max-w-150px" 
                                    title="${student.email || '-'}">
                                    ${student.email || '-'}
                                </td>
                                <td>
                                    <div class="p-2 rounded bg-light">
                                        <strong>AI Insight:</strong>
                                        <p class="mb-0 small text-muted">
                                            ${aiSummary}
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        `;

                        tbody.append(row);
                    });

                } else {
                    tbody.append(`
                        <tr>
                            <td colspan="5" class="text-center text-muted">
                                No candidates found
                            </td>
                        </tr>
                    `);
                }
            },
            error: function () {
                console.error('Failed to fetch applicant list');
            }
        });
    }


    $(document).ready(function() {
    // Handle the "Check All" checkbox
    $('#checkAll').on('change', function() {
        let isChecked = $(this).prop('checked');
        $('#studs_table_event_attendance tbody input[type="checkbox"]').each(function() {
        $(this).prop('checked', isChecked);
            toggleCheckboxText($(this)); // Update color for each checkbox
        });
    });

    // Handle individual checkboxes
    $('#studs_table_event_attendance tbody').on('change', 'input[type="checkbox"]', function() {
        let isChecked = $(this).prop('checked');
        toggleCheckboxText($(this));  // Update color for the changed checkbox

        // Check if all checkboxes are checked to toggle the "Check All" checkbox
        let allChecked = $('#studs_table_event_attendance tbody input[type="checkbox"]').length === $('#studs_table_event_attendance tbody input[type="checkbox"]:checked').length;
        $('#checkAll').prop('checked', allChecked);
    });

    // Function to toggle the checkbox color
    function toggleCheckboxText(checkbox) {
        let label = checkbox.closest('td').find('.shortlistcheckbox-label'); // Find the span that contains the text (Present/Absent)
        if (checkbox.prop('checked')) {
        label.text('Eligible').removeClass('text-danger').addClass('text-success');
        } else {
        label.text('No Eligible').removeClass('text-success').addClass('text-danger');
        }
    }

     $('#updateShortlistBtn').on('click', function() {
        $(this).prop('disabled', true); // Disable button to prevent multiple clicks
        let shortlistData = [];
        $('#studs_table_event_attendance tbody input[type="checkbox"]').each(function() {
        let studentSno = $(this).attr('id').split('_')[2];  // Extract student sno from checkbox id
        let shortListStatus = $(this).prop('checked') ? 1 : 0;
        shortlistData.push({
            sno: studentSno,
            shortListStatus: shortListStatus
        });
        });
        
        var shortlist_job_request_id = $('#shortlist_job_request_id').val();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        // Send updated shortlist data to the backend
        $.ajax({
        url: '/update_shortlist_candidate',  // Your API endpoint
        type: 'POST',
        headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
        data: JSON.stringify({ shortlist_data: shortlistData , job_request_id:shortlist_job_request_id }),
        contentType: 'application/json',
        success: function(response) {
            if (response.success) {
                window.location.reload();
            toastr.success('Shortlist updated successfully!');
            } else {
            toastr.error('Error updating shortlist.');
            $('#updateShortlistBtn').prop('disabled', false);
            }
        },
        error: function(xhr, status, error) {
            console.error('Error updating shortlist:', error);
            $('#updateShortlistBtn').prop('disabled', false);
        }
        });
    });
    }); 
</script>

<script>
document.getElementById("downloadPng").addEventListener("click", function (e) {
  e.preventDefault();

  const svg = document.querySelector("#downloadPng svg");
  const serializer = new XMLSerializer();
  const svgStr = serializer.serializeToString(svg);

  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  const img = new Image();
  const svgBlob = new Blob([svgStr], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svgBlob);

  img.onload = function () {
    canvas.width = img.width;
    canvas.height = img.height;

    // 🔹 NO background fill → transparent PNG
    ctx.drawImage(img, 0, 0);

    URL.revokeObjectURL(url);

    const pngUrl = canvas.toDataURL("image/png");

    const a = document.createElement("a");
    a.href = pngUrl;
    a.download = "huggingface-logo.png";
    a.click();
  };

  img.src = url;
});
</script>



@endsection