<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailTemplateModel extends Model
{
  use HasFactory;
  public $table      = 'egc_email_template';
  public $primaryKey = 'sno';

  protected $fillable = [
    'email_template_id',
    'branch_id',
    'email_name',
    'email_subject',
    'created_at',
    'created_by',
    'updated_at',
    'updated_by',
    'status',
  ];
}