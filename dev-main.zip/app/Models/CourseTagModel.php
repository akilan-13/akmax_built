<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseTagModel extends Model
{
    use HasFactory;
    public $table      = "egc_course_tag";
    public $primaryKey = 'sno';


    protected $fillable = [
        'course_tag_name',
        'course_tag_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}