<?php

namespace App\Http\Controllers\settings\interview;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InteviewCategoryModel;
use Illuminate\Support\Facades\Validator;

class InterviewCategory extends Controller
{
    
     public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = InteviewCategoryModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('interview_category_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('interview_category_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'interview_category_name' => $item->interview_category_name,
                    'category_icon' => $item->category_icon,
                    'interview_category_desc' => $item->interview_category_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.interview.interview_category.interview_category_list',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = InteviewCategoryModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {
        $validator = Validator::make( $request->all(), [
            'interview_category_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $interview_category_name       = $request->interview_category_name;
            $category_icon       = $request->category_icon;
            $interview_category_desc          = $request->interview_category_desc;
            $user_id                    = 1;
            $chk = InteviewCategoryModel::where( 'interview_category_name', $interview_category_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Interview Category is exist!'
                ] );
                return redirect()->back();
            } else {
                $add_branchtype = new InteviewCategoryModel();
                $add_branchtype->interview_category_name       = $interview_category_name;
                $add_branchtype->category_icon       = $category_icon;
                $add_branchtype->interview_category_desc       = $interview_category_desc;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => ' Interview Category added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the  Interview Category!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'interview_category_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $interview_category_name       = $request->interview_category_name;
            $category_icon       = $request->category_icon;
            $interview_category_desc       = $request->interview_category_desc;
            $document_id       = $request->edit_id;

            $upd_InteviewCategoryModel =  InteviewCategoryModel::where( 'sno', $document_id )->first();

            $chk = InteviewCategoryModel::where( 'interview_category_name', $interview_category_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already  Interview Category is exist!'
                ] );
                return redirect()->back();
            }

            $upd_InteviewCategoryModel->interview_category_name  = $interview_category_name;
            $upd_InteviewCategoryModel->category_icon  = $category_icon;
            $upd_InteviewCategoryModel->interview_category_desc  = $interview_category_desc;
            $upd_InteviewCategoryModel->update();

            if ( $upd_InteviewCategoryModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => ' Interview Category Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the  Interview Category!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_InteviewCategoryModel = InteviewCategoryModel::where( 'sno', $id )->first();
        $upd_InteviewCategoryModel->status  = 2;
        $upd_InteviewCategoryModel->Update();

        return response( [
            'status'    => 200,
            'message'   => ' Interview Category Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_InteviewCategoryModel =  InteviewCategoryModel::where( 'sno', $id )->first();
        $upd_InteviewCategoryModel->status = $request->input( 'status', 0 );
        $upd_InteviewCategoryModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

}
