<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class Experience extends Controller
{
    public function index()
    {
        return view(
            'content.settings.recruitment.experience.experience_list');
    }

}
