<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WebhookDispatchModel;
use App\Models\IntegrationModel;
use App\Jobs\SendWebhookJob;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class ApiConfig extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('perpage', 25);  // Default perpage value
        $search_filter = $request->input('search_filter', '');

        // Fetch the data with pagination
        $integrations = IntegrationModel::where('status', '!=', 2)
            ->when($search_filter, function($query) use ($search_filter) {
                return $query->where('api_name', 'like', '%' . $search_filter . '%');
            })
            ->paginate($perpage);

        if ($request->ajax()) {
            $data = $integrations->map(function ($int) {
                return [
                    'sno' => $int->sno,
                    'api_name' => $int->api_name,
                    'api_key' => $int->api_key,
                    'developer_link' => $int->developer_link,
                    'status' => $int->status,
                    'image' => asset('settings/integrations/' . $int->image),  // Assuming the image URL is stored correctly
                    'branches' => json_decode($int->branch_id, true)  // Assuming branch_id is a JSON array
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $integrations->currentPage(),
                'last_page' => $integrations->lastPage(),
                'total' => $integrations->total(),
            ]);
        }

        return view('content.admin.api_config.api_config_list', [
            'integrations' => $integrations,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
        ]);
    }
    public function Create(Request $request)
    {
        // return $request;
        // Validate the input fields
        $validator = Validator::make($request->all(), [
            'api_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        // Create integration in the database
        $integration = new IntegrationModel();
        $integration->api_name = $request->api_name;
        $integration->api_key = $request->api_key;
        $integration->developer_link = $request->developer_link;
        $integration->created_by = 0;
        $integration->updated_by = 0;

        // Store API fields (key-value pairs) as JSON
        $integration->api_fields = json_encode($request->config_fields);

        // Image Upload
        if ($request->hasFile('api_image')) {
            $file = $request->file('api_image');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('settings/integrations/'), $fileName);
            $integration->image = $fileName;
        }

        $integration->save();

        return response([
            'status' => 200,
            'message' => 'Integration Created Successfully',
            'data' => $integration,
        ], 200);
    }


    public function Status($id, Request $request)
    {

        $integrations =  IntegrationModel::where('sno', $id)->first();
        $integrations->status = $request->input('status', 0);
        $integrations->update();

        if ($integrations) {
            return response([
                'status'    => 200,
                'message'   => 'Integration  Status Successfully Updated!',
                'error_msg' => 'Could not, update  Integration  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Integration  Status!',
                'error_msg' => 'Could not, update  Integration  Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $del_integration = IntegrationModel::where('sno', $id)->first();
        $del_integration->status = 2;
        $del_integration->update();



        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
    {
        // Fetch integration by ID
        $integration = IntegrationModel::where('sno', $id)->where('status', '!=', 2)->first();

        if (!$integration) {
            return response([
                'status' => 404,
                'message' => 'Integration not found',
                'error_msg' => 'No record found with the given ID.',
                'data' => null,
            ], 404);
        }

        return response([
            'status' => 200,
            'message' => 'Integration fetched successfully',
            'data' => $integration,
        ], 200);
    }

    public function Update(Request $request)
    {
        // return $request;
        // Validate the input data
        $validator = Validator::make($request->all(), [
            'api_name_edit' => 'required|string',
            'api_key_edit' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $sno = $request->edit_id;

        // Find the integration to update
        $integration = IntegrationModel::where('sno', $sno)->where('status', '!=', 2)->first();

        if (!$integration) {
            return response([
                'status' => 404,
                'message' => 'Integration not found',
                'error_msg' => 'No record found with the given ID.',
                'data' => null,
            ], 404);
        }

        // Update fields
        $integration->api_name = $request->api_name_edit;
        $integration->api_key = $request->api_key_edit;
        $integration->developer_link = $request->developer_link_edit;

        // Handle dynamic fields (key-value pairs)
        $api_fields = [];
        if ($request->has('config_fields') && is_array($request->config_fields)) {
            $api_fields = $request->config_fields;
        }
        $integration->api_fields = json_encode($api_fields); // Store it as JSON

        // Handle image upload
        if ($request->hasFile('image_upload_edit')) {
            $file = $request->file('image_upload_edit');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $path = 'settings/integrations/';
            $file->move(public_path($path), $fileName);
            $integration->image = $fileName;
        }

        // Save the updated integration
        $integration->updated_by = auth()->user()->user_id;
        $integration->save();

        return response([
            'status' => 200,
            'message' => 'Integration Updated Successfully!',
            'data' => $integration,
        ], 200);
    }





    
}
