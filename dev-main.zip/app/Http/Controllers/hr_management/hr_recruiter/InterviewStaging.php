<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class InterviewStaging extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest=ManageEntityModel::where('status','!=',2)->orderBy('sno', 'asc')->get();
     
        foreach($jobRequest as $request){
          $jobRequestData = JobRequestModel::where('egc_job_request.status','!=',2)
            ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->where('egc_job_request.entity_id',$request->sno)
            ->select('egc_job_request.*',
            'egc_job_role.job_position_name as job_role_name'
            )
            ->orderBy('egc_job_request.sno','desc')
            ->get();
            foreach($jobRequestData as $list){
              $appicants=DB::table('egc_applicant')->where('job_request_id',$list->sno)->where('status','!=',2)->count();
              $appicantShorlist=DB::table('egc_applicant')->where('job_request_id',$list->sno)->where('shortlist_check',1)->where('status','!=',2)->count();
              $list->applicant_count=$appicants;
              $list->shortlist_count=$appicantShorlist;
            }

            $request->job_request_list=$jobRequestData;          
            $request->job_request_count=count($jobRequestData);          
        }

      $helper = new \App\Helpers\Helpers();

    
      return view('content.hr_management.hr_recruiter.interview_staging.staging_list', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
      ]);
  }

  public function InterviewSchedule($id, Request $request){
        $decodeId = base64_decode($id);

        return view('content.hr_management.hr_recruiter.job_request.interview_schedule', [
          // 'jobRequest' => $jobRequest,
          // 'perpage' => $perpage,
          // 'search_filter' => $search_filter,
      ]);
  }

   public function interviewFeedback()
  {
    return view('content.hr_management.hr_recruitment.job_request.feedback_form');
  }


  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  
    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
  {
      $payload = $dispatch->payload ?? [];
      $bodyString = json_encode($payload);

      $dispatch->increment('attempts');
      $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

      $timestamp = now()->getTimestamp();
      $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

      $headers = array_merge(
          is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
          [
              'X-WEBHOOK-TIMESTAMP' => $timestamp,
              'X-WEBHOOK-SIGNATURE' => $signature,
              'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
              'Accept' => 'application/json',
          ]
      );

      try {
          $response = Http::withHeaders($headers)
              ->timeout(15)
              ->post($hook->url, $payload);

          WebhookDispatchAttemptModel::create([
              'webhook_dispatch_sno' => $dispatch->sno,
              'http_status' => $response->status(),
              'request_headers' => json_encode($headers),
              'request_body' => $bodyString,
              'response_body' => $response->body(),
          ]);

          if ($response->successful()) {
              $dispatch->update([
                  'status' => 2,
                  'http_status' => $response->status(),
                  'last_response' => $response->body(),
                  'next_attempt_at' => null
              ]);
              
              return ['success' => true];
          } else {
              $dispatch->update([
                  'status' => 3,
                  'last_response' => 'Webhook failed. Will retry automatically.'
              ]);
              
              return ['success' => false];
          }
      } catch (\Throwable $e) {
          \Log::error("Immediate webhook send failed: " . $e->getMessage());
          $dispatch->update([
              'status' => 3,
              'last_response' => 'Webhook failed. Will retry automatically.'
          ]);
          return ['success' => false];
      }
  }
      
}
