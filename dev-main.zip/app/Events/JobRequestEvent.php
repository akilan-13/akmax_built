<?php
namespace App\Events;

use App\Models\JobRequestModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class JobRequestEvent implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $dispatch;

    public function __construct(JobRequestModel $dispatch)
    {
        $this->dispatch = $dispatch;
    }

    public function broadcastAs()
    {
        return 'JobRequestEvent';
    }

    public function broadcastOn()
    {
       return new Channel('jobrequests'); 
    }

   public function broadcastWith()
    {
        $webhook = $this->dispatch->webhook;

         $company = $this->dispatch->company;
         $entity = $this->dispatch->entity; 
        return [
            'id' => $this->dispatch->sno,
            'erp_job_request_id' => $this->dispatch->erp_job_request_id,
            'company_type' => $this->dispatch->company_type,
            'company_id' => $this->dispatch->company_id,
            'entity_id' => $this->dispatch->entity_id,
            'branch_id' => $this->dispatch->branch_id,
            'job_request_id' => $this->dispatch->job_request_id,
            'job_role_name' => $this->dispatch->job_role_name,
            'min_salary' => $this->dispatch->min_salary,
            'max_salary' => $this->dispatch->max_salary,
            'vacancy_count' => $this->dispatch->vacancy_count,
            'exp_type_ids' => $this->dispatch->exp_type_ids,
            'experience' => $this->dispatch->experience,
            'closing_date' => $this->dispatch->closing_date,
            'skill_required' => $this->dispatch->skill_required,
            'job_description' => $this->dispatch->job_description,
            'status' => $this->dispatch->status,
            'created_by' => $this->dispatch->created_by,
            'created_at' => $this->dispatch->created_at,
            'updated_by' => $this->dispatch->updated_by,
            'updated_at' => $this->dispatch->updated_at,
            'company_name' => $company ? $company->company_name : null, 
            'company_base_color' => $company ? $company->company_base_color : null, 
            'entity_name' => $entity ? $entity->entity_name : null, 
            'entity_short_name' => $entity ? $entity->entity_short_name : null, 
        ];

    }
}
